<?php
/**
 * WC_Stripe_Metadata_Customizer class.
 *
 * Provides Stripe metadata masking, custom store branding, Level 3 product cloaking,
 * customer PII anonymization, shipping address stripping, and statement description formatting.
 *
 * @package WooCommerce_Stripe
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class WC_Stripe_Metadata_Customizer {

	/**
	 * Option key for storing customizer settings.
	 */
	const OPTION_KEY = 'wc_stripe_metadata_customizer_settings';

	/**
	 * Singleton instance.
	 *
	 * @var WC_Stripe_Metadata_Customizer|null
	 */
	private static $instance = null;

	/**
	 * Returns singleton instance.
	 *
	 * @return WC_Stripe_Metadata_Customizer
	 */
	public static function get_instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Constructor.
	 */
	public function __construct() {
		// Filter hooks for outgoing Stripe requests
		add_filter( 'wc_stripe_request_body', [ $this, 'filter_stripe_request_body' ], 20, 2 );
		add_filter( 'wc_stripe_generate_payment_request', [ $this, 'filter_payment_request_args' ], 20, 3 );
		add_filter( 'wc_stripe_payment_metadata', [ $this, 'filter_payment_metadata' ], 20, 3 );
		add_filter( 'wc_stripe_intent_metadata', [ $this, 'filter_payment_metadata' ], 20, 2 );
		add_filter( 'wc_stripe_payment_request_payment_args', [ $this, 'filter_express_checkout_payment_args' ], 20, 2 );

		// AJAX endpoints for admin settings
		add_action( 'wp_ajax_wc_stripe_save_metadata_customizer_settings', [ $this, 'ajax_save_settings' ] );
		add_action( 'wp_ajax_wc_stripe_get_metadata_customizer_settings', [ $this, 'ajax_get_settings' ] );
	}

	/**
	 * Get default settings (Default is OFF for all features).
	 *
	 * @return array
	 */
	public static function get_default_settings() {
		return [
			'enabled'                     => 'no', // Default is OFF
			'site_url'                    => 'hidden',
			'store_name'                  => get_bloginfo( 'name' ),
			'order_description_template'  => '{store_name} - order {order_number}',
			'mask_level3'                 => 'no', // Strip itemized products/SKUs
			'mask_customer_pii'           => 'no', // Anonymize Customer name & email
			'strip_shipping'              => 'no', // Remove physical shipping address
			'statement_descriptor_suffix' => '',   // Custom statement descriptor suffix
		];
	}

	/**
	 * Retrieve current settings with fallback to defaults.
	 *
	 * @return array
	 */
	public static function get_settings() {
		$defaults = self::get_default_settings();
		$settings = get_option( self::OPTION_KEY, [] );

		// Fallback to legacy options if saved previously
		if ( empty( $settings ) ) {
			$legacy_site_url   = get_option( 'smh_site_url', null );
			$legacy_store_name = get_option( 'smh_store_name', null );
			$legacy_template   = get_option( 'smh_order_description_template', null );

			if ( null !== $legacy_site_url || null !== $legacy_store_name || null !== $legacy_template ) {
				$settings = [
					'enabled'                     => 'no',
					'site_url'                    => $legacy_site_url ?: $defaults['site_url'],
					'store_name'                  => $legacy_store_name ?: $defaults['store_name'],
					'order_description_template'  => $legacy_template ?: $defaults['order_description_template'],
					'mask_level3'                 => 'no',
					'mask_customer_pii'           => 'no',
					'strip_shipping'              => 'no',
					'statement_descriptor_suffix' => '',
				];
			}
		}

		return wp_parse_args( $settings, $defaults );
	}

	/**
	 * Check if the customizer is currently enabled.
	 *
	 * @return bool
	 */
	public static function is_enabled() {
		$settings = self::get_settings();
		return 'yes' === $settings['enabled'] || true === $settings['enabled'] || '1' === $settings['enabled'];
	}

	/**
	 * Format order description using template and order details.
	 *
	 * @param string        $template Template string.
	 * @param WC_Order|null $order Order object if available.
	 * @param string|int    $order_number Order number.
	 * @param string        $store_name Store name.
	 * @return string
	 */
	public function format_description( $template, $order = null, $order_number = '', $store_name = '' ) {
		$customer_name = '';
		$order_date    = '';
		$order_total   = '';

		if ( $order instanceof WC_Order ) {
			$customer_name = trim( $order->get_billing_first_name() . ' ' . $order->get_billing_last_name() );
			if ( empty( $customer_name ) ) {
				$customer_name = __( 'Guest', 'woocommerce-gateway-stripe' );
			}
			$order_date  = $order->get_date_created() ? $order->get_date_created()->date_i18n( get_option( 'date_format', 'Y-m-d' ) ) : date_i18n( get_option( 'date_format', 'Y-m-d' ) );
			$order_total = html_entity_decode( strip_tags( wc_price( $order->get_total(), [ 'currency' => $order->get_currency() ] ) ) );
			if ( empty( $order_number ) ) {
				$order_number = $order->get_order_number();
			}
		} else {
			$customer_name = __( 'Guest', 'woocommerce-gateway-stripe' );
			$order_date    = date_i18n( get_option( 'date_format', 'Y-m-d' ) );
			$order_total   = '$0.00';
			if ( empty( $order_number ) ) {
				$order_number = '1001';
			}
		}

		$search = [
			'{store_name}',
			'{order_number}',
			'{customer_name}',
			'{order_date}',
			'{order_total}',
		];

		$replace = [
			$store_name,
			$order_number,
			$customer_name,
			$order_date,
			$order_total,
		];

		return str_replace( $search, $replace, $template );
	}

	/**
	 * Filter raw request body sent to Stripe API.
	 *
	 * @param array  $request API Request payload.
	 * @param string $api Endpoint.
	 * @return array
	 */
	public function filter_stripe_request_body( $request, $api = '' ) {
		if ( ! self::is_enabled() || ! is_array( $request ) ) {
			return $request;
		}

		$settings           = self::get_settings();
		$site_url           = $settings['site_url'];
		$store_name         = $settings['store_name'];
		$desc_template      = $settings['order_description_template'];
		$mask_level3        = 'yes' === $settings['mask_level3'];
		$mask_customer_pii  = 'yes' === $settings['mask_customer_pii'];
		$strip_shipping     = 'yes' === $settings['strip_shipping'];
		$statement_suffix   = trim( $settings['statement_descriptor_suffix'] ?? '' );

		// 1. Strip Level 3 product details if enabled
		if ( $mask_level3 && isset( $request['level3'] ) ) {
			unset( $request['level3'] );
		}

		// 2. Strip physical shipping address if enabled
		if ( $strip_shipping && isset( $request['shipping'] ) ) {
			unset( $request['shipping'] );
		}

		// 3. Custom statement descriptor suffix if specified
		if ( ! empty( $statement_suffix ) ) {
			$clean_suffix = substr( trim( preg_replace( '/[^a-zA-Z0-9 ]/', '', $statement_suffix ) ), 0, 22 );
			if ( ! empty( $clean_suffix ) ) {
				$request['statement_descriptor_suffix'] = $clean_suffix;
			}
		}

		// 4. Update metadata dictionary if present
		if ( isset( $request['metadata'] ) && is_array( $request['metadata'] ) ) {
			if ( isset( $request['metadata']['site_url'] ) ) {
				$request['metadata']['site_url'] = $site_url;
			}
			if ( isset( $request['metadata']['site_name'] ) ) {
				$request['metadata']['site_name'] = $store_name;
			}

			// PII Anonymization
			if ( $mask_customer_pii ) {
				$order_id = $request['metadata']['order_id'] ?? 'Order';
				if ( isset( $request['metadata']['customer_name'] ) ) {
					$request['metadata']['customer_name'] = 'Customer #' . $order_id;
				}
				if ( isset( $request['metadata']['customer_email'] ) ) {
					$request['metadata']['customer_email'] = 'customer' . $order_id . '@hidden.local';
				}
			}
		}

		// 5. Filter any root keys matching site_url or site_name
		foreach ( $request as $key => $value ) {
			if ( ( stripos( $key, 'site_url' ) !== false || stripos( $key, 'site_name' ) !== false ) && is_string( $value ) ) {
				$request[ $key ] = ( false !== stripos( $key, 'site_url' ) ) ? $site_url : $store_name;
			}

			// Format description if matching order pattern
			if ( 'description' === $key && is_string( $value ) && preg_match( '/order\s*#?(\d+)/i', $value, $matches ) ) {
				$order_number    = $matches[1];
				$order           = wc_get_order( $order_number );
				$request[ $key ] = $this->format_description( $desc_template, $order, $order_number, $store_name );
			}
		}

		return $request;
	}

	/**
	 * Filter payment request arguments.
	 *
	 * @param array $args Payment request post data.
	 * @param WC_Order|null $order Order.
	 * @param mixed $prepared_payment_method Payment method.
	 * @return array
	 */
	public function filter_payment_request_args( $args, $order = null, $prepared_payment_method = null ) {
		if ( ! self::is_enabled() || ! is_array( $args ) ) {
			return $args;
		}

		$settings           = self::get_settings();
		$site_url           = $settings['site_url'];
		$store_name         = $settings['store_name'];
		$desc_template      = $settings['order_description_template'];
		$mask_level3        = 'yes' === $settings['mask_level3'];
		$mask_customer_pii  = 'yes' === $settings['mask_customer_pii'];
		$strip_shipping     = 'yes' === $settings['strip_shipping'];
		$statement_suffix   = trim( $settings['statement_descriptor_suffix'] ?? '' );

		if ( $mask_level3 && isset( $args['level3'] ) ) {
			unset( $args['level3'] );
		}

		if ( $strip_shipping && isset( $args['shipping'] ) ) {
			unset( $args['shipping'] );
		}

		if ( ! empty( $statement_suffix ) ) {
			$clean_suffix = substr( trim( preg_replace( '/[^a-zA-Z0-9 ]/', '', $statement_suffix ) ), 0, 22 );
			if ( ! empty( $clean_suffix ) ) {
				$args['statement_descriptor_suffix'] = $clean_suffix;
			}
		}

		if ( isset( $args['metadata'] ) && is_array( $args['metadata'] ) ) {
			if ( isset( $args['metadata']['site_url'] ) ) {
				$args['metadata']['site_url'] = $site_url;
			}
			if ( isset( $args['metadata']['site_name'] ) ) {
				$args['metadata']['site_name'] = $store_name;
			}

			if ( $mask_customer_pii ) {
				$order_id = $order instanceof WC_Order ? $order->get_order_number() : ( $args['metadata']['order_id'] ?? 'Order' );
				if ( isset( $args['metadata']['customer_name'] ) ) {
					$args['metadata']['customer_name'] = 'Customer #' . $order_id;
				}
				if ( isset( $args['metadata']['customer_email'] ) ) {
					$args['metadata']['customer_email'] = 'customer' . $order_id . '@hidden.local';
				}
			}
		}

		if ( isset( $args['description'] ) && is_string( $args['description'] ) ) {
			$order_number        = $order instanceof WC_Order ? $order->get_order_number() : '';
			$args['description'] = $this->format_description( $desc_template, $order, $order_number, $store_name );
		}

		return $args;
	}

	/**
	 * Filter metadata array for payment intent creation.
	 *
	 * @param array $metadata Metadata array.
	 * @param WC_Order|null $order Order.
	 * @param mixed $source Source.
	 * @return array
	 */
	public function filter_payment_metadata( $metadata, $order = null, $source = null ) {
		if ( ! self::is_enabled() || ! is_array( $metadata ) ) {
			return $metadata;
		}

		$settings          = self::get_settings();
		$site_url          = $settings['site_url'];
		$store_name        = $settings['store_name'];
		$mask_customer_pii = 'yes' === $settings['mask_customer_pii'];

		if ( isset( $metadata['site_url'] ) ) {
			$metadata['site_url'] = $site_url;
		}
		if ( isset( $metadata['site_name'] ) ) {
			$metadata['site_name'] = $store_name;
		}

		if ( $mask_customer_pii ) {
			$order_id = $order instanceof WC_Order ? $order->get_order_number() : ( $metadata['order_id'] ?? 'Order' );
			if ( isset( $metadata['customer_name'] ) ) {
				$metadata['customer_name'] = 'Customer #' . $order_id;
			}
			if ( isset( $metadata['customer_email'] ) ) {
				$metadata['customer_email'] = 'customer' . $order_id . '@hidden.local';
			}
		}

		return $metadata;
	}

	/**
	 * Filter express checkout payment args.
	 *
	 * @param array $args Express checkout args.
	 * @param mixed $request Request object.
	 * @return array
	 */
	public function filter_express_checkout_payment_args( $args, $request = null ) {
		return $this->filter_stripe_request_body( $args );
	}

	/**
	 * AJAX handler to save customizer settings.
	 */
	public function ajax_save_settings() {
		check_ajax_referer( 'wc_stripe_metadata_customizer_nonce', 'security' );

		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_send_json_error( [ 'message' => __( 'Permission denied.', 'woocommerce-gateway-stripe' ) ] );
		}

		$enabled                     = isset( $_POST['enabled'] ) && ( 'yes' === $_POST['enabled'] || '1' === $_POST['enabled'] || 'true' === $_POST['enabled'] ) ? 'yes' : 'no';
		$site_url                    = isset( $_POST['site_url'] ) ? sanitize_text_field( wp_unslash( $_POST['site_url'] ) ) : 'hidden';
		$store_name                  = isset( $_POST['store_name'] ) ? sanitize_text_field( wp_unslash( $_POST['store_name'] ) ) : get_bloginfo( 'name' );
		$order_description_template  = isset( $_POST['order_description_template'] ) ? sanitize_text_field( wp_unslash( $_POST['order_description_template'] ) ) : '{store_name} - order {order_number}';
		$mask_level3                 = isset( $_POST['mask_level3'] ) && ( 'yes' === $_POST['mask_level3'] || '1' === $_POST['mask_level3'] || 'true' === $_POST['mask_level3'] ) ? 'yes' : 'no';
		$mask_customer_pii           = isset( $_POST['mask_customer_pii'] ) && ( 'yes' === $_POST['mask_customer_pii'] || '1' === $_POST['mask_customer_pii'] || 'true' === $_POST['mask_customer_pii'] ) ? 'yes' : 'no';
		$strip_shipping              = isset( $_POST['strip_shipping'] ) && ( 'yes' === $_POST['strip_shipping'] || '1' === $_POST['strip_shipping'] || 'true' === $_POST['strip_shipping'] ) ? 'yes' : 'no';
		$statement_descriptor_suffix = isset( $_POST['statement_descriptor_suffix'] ) ? sanitize_text_field( wp_unslash( $_POST['statement_descriptor_suffix'] ) ) : '';

		$new_settings = [
			'enabled'                     => $enabled,
			'site_url'                    => $site_url,
			'store_name'                  => $store_name,
			'order_description_template'  => $order_description_template,
			'mask_level3'                 => $mask_level3,
			'mask_customer_pii'           => $mask_customer_pii,
			'strip_shipping'              => $strip_shipping,
			'statement_descriptor_suffix' => $statement_descriptor_suffix,
		];

		update_option( self::OPTION_KEY, $new_settings );

		// Sync legacy options for backwards compatibility
		update_option( 'smh_site_url', $site_url );
		update_option( 'smh_store_name', $store_name );
		update_option( 'smh_order_description_template', $order_description_template );

		wp_send_json_success( [
			'message'  => __( 'Privacy & cloaking settings saved successfully.', 'woocommerce-gateway-stripe' ),
			'settings' => $new_settings,
		] );
	}

	/**
	 * AJAX handler to get customizer settings.
	 */
	public function ajax_get_settings() {
		check_ajax_referer( 'wc_stripe_metadata_customizer_nonce', 'security' );

		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_send_json_error( [ 'message' => __( 'Permission denied.', 'woocommerce-gateway-stripe' ) ] );
		}

		wp_send_json_success( [
			'settings' => self::get_settings(),
		] );
	}
}
