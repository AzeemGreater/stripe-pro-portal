const fs = require('fs');
const path = require('path');

const jsPath = path.join(__dirname, '../build/upe-settings.js');
const cssPath = path.join(__dirname, '../build/upe-settings.css');
const rtlCssPath = path.join(__dirname, '../build/upe-settings-rtl.css');

let jsContent = fs.readFileSync(jsPath, 'utf8');

// Find renderDashboardView definition in build/upe-settings.js
const startMarker = 'const renderDashboardView=()=>(0,y.createElement)("div",{className:"wc-stripe-tab-view-container wc-stripe-dashboard-view"},';
const startIdx = jsContent.indexOf(startMarker);

if (startIdx === -1) {
    console.error('Could not find renderDashboardView in upe-settings.js');
    process.exit(1);
}

const endMarker = 'const MetadataCustomizerTool=()=>{';
const endIdx = jsContent.indexOf(endMarker, startIdx);

if (endIdx === -1) {
    console.error('Could not find endMarker for renderDashboardView in upe-settings.js');
    process.exit(1);
}

const dashboardComponent = `const StripeAnalyticsDashboard=()=>{
    const initialData=(typeof wc_stripe_settings_params!=="undefined"&&wc_stripe_settings_params.analytics_data)||{
        range:"30d",
        currency:"USD",
        account:{account_id:"acct_connected",country:"US",default_currency:"USD",payout_schedule:"Daily (Automatic)",payout_method:"Bank Account (•••• 4242)",statement_descriptor:"Store Name"},
        balance:{available:14250.80,pending:2840.50,currency:"USD",available_formatted:"$14,250.80",pending_formatted:"$2,840.50"},
        summary:{gross_volume:48920.00,gross_volume_fmt:"$48,920.00",net_volume:47312.40,net_volume_fmt:"$47,312.40",total_fees_fmt:"$1,607.60",success_count:342,failed_count:6,total_count:348,success_rate:98.3},
        transactions:[
            {id:"ch_3N192aFkz84",amount:129.00,amount_fmt:"$129.00",net_fmt:"$124.96",fee_fmt:"$4.04",customer:"Sarah Jenkins",email:"sarah@example.com",payment_method:"Visa •••• 4242",status:"succeeded",created:"Today, 14:15",order_id:"#1042",stripe_url:"https://dashboard.stripe.com"},
            {id:"ch_3N185zFkz82",amount:85.50,amount_fmt:"$85.50",net_fmt:"$82.72",fee_fmt:"$2.78",customer:"David Miller",email:"david.m@example.com",payment_method:"Apple Pay",status:"succeeded",created:"Today, 12:40",order_id:"#1041",stripe_url:"https://dashboard.stripe.com"},
            {id:"ch_3N172mFkz89",amount:240.00,amount_fmt:"$240.00",net_fmt:"$232.74",fee_fmt:"$7.26",customer:"Elena Rostova",email:"elena@example.com",payment_method:"Mastercard •••• 8812",status:"succeeded",created:"Today, 10:12",order_id:"#1040",stripe_url:"https://dashboard.stripe.com"},
            {id:"ch_3N161kFkz77",amount:45.00,amount_fmt:"$45.00",net_fmt:"$43.40",fee_fmt:"$1.60",customer:"Guest Customer",email:"guest@example.com",payment_method:"Google Pay",status:"succeeded",created:"Yesterday",order_id:"#1039",stripe_url:"https://dashboard.stripe.com"},
            {id:"ch_3N150aFkz66",amount:310.00,amount_fmt:"$310.00",net_fmt:"$0.00",fee_fmt:"$0.00",customer:"Michael Brown",email:"michael@example.com",payment_method:"Visa •••• 1111",status:"failed",created:"Yesterday",order_id:"#1038",stripe_url:"https://dashboard.stripe.com"}
        ],
        payouts:{
            total_paid:38500.00,
            total_paid_fmt:"$38,500.00",
            next_payout:{amount:4250.00,amount_fmt:"$4,250.00",arrival_date:"Tomorrow, Sep 22"},
            list:[
                {id:"po_1N1800Fkz84",amount:12450.00,amount_fmt:"$12,450.00",status:"paid",destination:"Chase Bank (•••• 4242)",arrival:"Sep 18, 2026",created:"Sep 16, 2026",stripe_url:"https://dashboard.stripe.com"},
                {id:"po_1N1500Fkz82",amount:14200.00,amount_fmt:"$14,200.00",status:"paid",destination:"Chase Bank (•••• 4242)",arrival:"Sep 11, 2026",created:"Sep 09, 2026",stripe_url:"https://dashboard.stripe.com"},
                {id:"po_1N1200Fkz81",amount:11850.00,amount_fmt:"$11,850.00",status:"paid",destination:"Chase Bank (•••• 4242)",arrival:"Sep 04, 2026",created:"Sep 02, 2026",stripe_url:"https://dashboard.stripe.com"}
            ]
        },
        disputes:{
            total_disputed:129.00,
            total_disputed_fmt:"$129.00",
            active_count:0,
            won_count:3,
            lost_count:1,
            list:[
                {id:"dp_1N144aFkz84",charge_id:"ch_3N192a",amount:129.00,amount_fmt:"$129.00",status:"won",reason:"Fraudulent claim",due_by:"Resolved",created:"Sep 12, 2026",stripe_url:"https://dashboard.stripe.com"}
            ]
        },
        customers:{
            total_count:4,
            list:[
                {id:"cus_N192aFkz",name:"Sarah Jenkins",email:"sarah@example.com",created:"Sep 10, 2026",stripe_url:"https://dashboard.stripe.com"},
                {id:"cus_N185zFkz",name:"David Miller",email:"david.m@example.com",created:"Sep 08, 2026",stripe_url:"https://dashboard.stripe.com"},
                {id:"cus_N172mFkz",name:"Elena Rostova",email:"elena@example.com",created:"Aug 29, 2026",stripe_url:"https://dashboard.stripe.com"},
                {id:"cus_N150aFkz",name:"Michael Brown",email:"michael@example.com",created:"Aug 15, 2026",stripe_url:"https://dashboard.stripe.com"}
            ]
        }
    };

    const [data,setData]=(0,h.useState)(initialData);
    const [range,setRange]=(0,h.useState)(initialData.range||"30d");
    const [subTab,setSubTab]=(0,h.useState)("transactions");
    const [isLoading,setIsLoading]=(0,h.useState)(!1);
    const [searchTerm,setSearchTerm]=(0,h.useState)("");

    const fetchAnalytics=(newRange,force=false)=>{
        setIsLoading(!0);
        const ajaxUrl=(typeof ajaxurl!=="undefined"?ajaxurl:(typeof wc_stripe_settings_params!=="undefined"?wc_stripe_settings_params.ajax_url:"admin-ajax.php"));
        const nonce=(typeof wc_stripe_settings_params!=="undefined"&&wc_stripe_settings_params.analytics_nonce)||"";
        const formData=new URLSearchParams();
        formData.append("action","wc_stripe_get_dashboard_analytics");
        formData.append("security",nonce);
        formData.append("range",newRange);
        if(force) formData.append("force_refresh","1");

        fetch(ajaxUrl,{
            method:"POST",
            headers:{"Content-Type":"application/x-www-form-urlencoded"},
            body:formData.toString()
        }).then(r=>r.json()).then(res=>{
            setIsLoading(!1);
            if(res.success&&res.data){
                setData(res.data);
            }
        }).catch(()=>{
            setIsLoading(!1);
        });
    };

    const handleRangeChange=(newRange)=>{
        setRange(newRange);
        fetchAnalytics(newRange,false);
    };

    const handleRefresh=()=>{
        fetchAnalytics(range,true);
    };

    const account=data.account||{};
    const balance=data.balance||{};
    const summary=data.summary||{};
    const payouts=data.payouts||{list:[]};
    const disputes=data.disputes||{list:[]};
    const customers=data.customers||{list:[]};
    const transactions=data.transactions||[];

    const filteredTransactions=transactions.filter(t=>{
        if(!searchTerm) return true;
        const q=searchTerm.toLowerCase();
        return (t.id&&t.id.toLowerCase().includes(q))||(t.customer&&t.customer.toLowerCase().includes(q))||(t.email&&t.email.toLowerCase().includes(q))||(t.order_id&&t.order_id.toLowerCase().includes(q));
    });

    return (0,y.createElement)("div",{className:"wc-stripe-analytics-container"},
        (0,y.createElement)("div",{className:"wc-stripe-account-overview-bar"},
            (0,y.createElement)("div",{className:"wc-stripe-account-info-group"},
                (0,y.createElement)("div",{className:"wc-stripe-account-badge"},
                    (0,y.createElement)("span",{className:"dashicons dashicons-admin-generic"}),
                    (0,y.createElement)("span",null,account.account_id||"acct_connected")
                ),
                (0,y.createElement)("div",{className:"wc-stripe-account-detail-pill"},
                    (0,y.createElement)("span",{className:"wc-stripe-detail-label"},(0,He.__)("Country:","woocommerce-gateway-stripe")),
                    (0,y.createElement)("span",{className:"wc-stripe-detail-value"},account.country||"US")
                ),
                (0,y.createElement)("div",{className:"wc-stripe-account-detail-pill"},
                    (0,y.createElement)("span",{className:"wc-stripe-detail-label"},(0,He.__)("Currency:","woocommerce-gateway-stripe")),
                    (0,y.createElement)("span",{className:"wc-stripe-detail-value"},account.default_currency||"USD")
                ),
                (0,y.createElement)("div",{className:"wc-stripe-account-detail-pill"},
                    (0,y.createElement)("span",{className:"wc-stripe-detail-label"},(0,He.__)("Payout Schedule:","woocommerce-gateway-stripe")),
                    (0,y.createElement)("span",{className:"wc-stripe-detail-value"},account.payout_schedule||"Daily (Automatic)")
                ),
                (0,y.createElement)("div",{className:"wc-stripe-account-detail-pill"},
                    (0,y.createElement)("span",{className:"wc-stripe-detail-label"},(0,He.__)("Payout Method:","woocommerce-gateway-stripe")),
                    (0,y.createElement)("span",{className:"wc-stripe-detail-value is-bank"},account.payout_method||"Bank Account")
                )
            ),
            (0,y.createElement)("div",{className:"wc-stripe-account-actions-group"},
                (0,y.createElement)("div",{className:"wc-stripe-date-range-pills"},
                    ["24h","7d","30d","90d","ytd"].map(r=>(0,y.createElement)("button",{
                        key:r,
                        type:"button",
                        className:\`wc-stripe-range-btn \${range===r?"is-selected":""}\`,
                        onClick:()=>handleRangeChange(r)
                    },r.toUpperCase()))
                ),
                (0,y.createElement)("button",{
                    type:"button",
                    className:\`button button-secondary wc-stripe-refresh-btn \${isLoading?"is-loading":""}\`,
                    disabled:isLoading,
                    onClick:handleRefresh
                },
                    (0,y.createElement)("span",{className:"dashicons dashicons-update"}),
                    isLoading?(0,He.__)("Refreshing...","woocommerce-gateway-stripe"):(0,He.__)("Refresh Now","woocommerce-gateway-stripe")
                )
            )
        ),
        (0,y.createElement)("div",{className:"wc-stripe-kpi-grid"},
            (0,y.createElement)("div",{className:"wc-stripe-kpi-card is-volume"},
                (0,y.createElement)("div",{className:"wc-stripe-kpi-header"},
                    (0,y.createElement)("span",{className:"wc-stripe-kpi-title"},(0,He.__)("Gross Volume","woocommerce-gateway-stripe")),
                    (0,y.createElement)("span",{className:"dashicons dashicons-chart-area wc-stripe-kpi-icon"})
                ),
                (0,y.createElement)("div",{className:"wc-stripe-kpi-value"},summary.gross_volume_fmt||"$0.00"),
                (0,y.createElement)("div",{className:"wc-stripe-kpi-meta"},
                    (0,y.createElement)("span",{className:"wc-stripe-kpi-badge is-success"},(summary.success_rate||100)+"% "+(0,He.__)("Success Rate","woocommerce-gateway-stripe")),
                    (0,y.createElement)("span",{className:"wc-stripe-kpi-subtext"},(0,He.__)("Net: ","woocommerce-gateway-stripe")+(summary.net_volume_fmt||"$0.00"))
                )
            ),
            (0,y.createElement)("div",{className:"wc-stripe-kpi-card is-balance"},
                (0,y.createElement)("div",{className:"wc-stripe-kpi-header"},
                    (0,y.createElement)("span",{className:"wc-stripe-kpi-title"},(0,He.__)("Live Stripe Balance","woocommerce-gateway-stripe")),
                    (0,y.createElement)("span",{className:"dashicons dashicons-money-alt wc-stripe-kpi-icon"})
                ),
                (0,y.createElement)("div",{className:"wc-stripe-kpi-value"},balance.available_formatted||"$0.00"),
                (0,y.createElement)("div",{className:"wc-stripe-kpi-meta"},
                    (0,y.createElement)("span",{className:"wc-stripe-kpi-subtext"},(0,He.__)("Pending: ","woocommerce-gateway-stripe")+(balance.pending_formatted||"$0.00")),
                    (0,y.createElement)("span",{className:"wc-stripe-kpi-badge is-info"},(0,He.__)("Ready to Payout","woocommerce-gateway-stripe"))
                )
            ),
            (0,y.createElement)("div",{className:"wc-stripe-kpi-card is-payouts"},
                (0,y.createElement)("div",{className:"wc-stripe-kpi-header"},
                    (0,y.createElement)("span",{className:"wc-stripe-kpi-title"},(0,He.__)("Settled Payouts","woocommerce-gateway-stripe")),
                    (0,y.createElement)("span",{className:"dashicons dashicons-vault wc-stripe-kpi-icon"})
                ),
                (0,y.createElement)("div",{className:"wc-stripe-kpi-value"},payouts.total_paid_fmt||"$0.00"),
                (0,y.createElement)("div",{className:"wc-stripe-kpi-meta"},
                    (0,y.createElement)("span",{className:"wc-stripe-kpi-subtext"},(0,He.__)("Next: ","woocommerce-gateway-stripe")+((payouts.next_payout&&payouts.next_payout.amount_fmt)||"$0.00")),
                    (0,y.createElement)("span",{className:"wc-stripe-kpi-badge is-arrival"},(payouts.next_payout&&payouts.next_payout.arrival_date)||"Estimated 1-2d")
                )
            ),
            (0,y.createElement)("div",{className:"wc-stripe-kpi-card is-disputes"},
                (0,y.createElement)("div",{className:"wc-stripe-kpi-header"},
                    (0,y.createElement)("span",{className:"wc-stripe-kpi-title"},(0,He.__)("Disputes & Risk","woocommerce-gateway-stripe")),
                    (0,y.createElement)("span",{className:"dashicons dashicons-shield wc-stripe-kpi-icon"})
                ),
                (0,y.createElement)("div",{className:"wc-stripe-kpi-value"},disputes.total_disputed_fmt||"$0.00"),
                (0,y.createElement)("div",{className:"wc-stripe-kpi-meta"},
                    (0,y.createElement)("span",{className:\`wc-stripe-kpi-badge \${(disputes.active_count||0)>0?"is-alert":"is-clean"}\`},
                        (disputes.active_count||0)+" "+(0,He.__)("Active Disputes","woocommerce-gateway-stripe")
                    ),
                    (0,y.createElement)("span",{className:"wc-stripe-kpi-subtext"},(disputes.won_count||0)+" "+(0,He.__)("Won","woocommerce-gateway-stripe"))
                )
            )
        ),
        (0,y.createElement)("div",{className:"wc-stripe-analytics-table-card"},
            (0,y.createElement)("div",{className:"wc-stripe-table-nav-bar"},
                (0,y.createElement)("div",{className:"wc-stripe-sub-tabs-list"},
                    (0,y.createElement)("button",{type:"button",className:\`wc-stripe-sub-tab-btn \${subTab==="transactions"?"is-active":""}\`,onClick:()=>setSubTab("transactions")},
                        (0,y.createElement)("span",{className:"dashicons dashicons-cart"}),
                        (0,He.__)("Transactions","woocommerce-gateway-stripe"),
                        (0,y.createElement)("span",{className:"wc-stripe-count-badge"},transactions.length)
                    ),
                    (0,y.createElement)("button",{type:"button",className:\`wc-stripe-sub-tab-btn \${subTab==="payouts"?"is-active":""}\`,onClick:()=>setSubTab("payouts")},
                        (0,y.createElement)("span",{className:"dashicons dashicons-money"}),
                        (0,He.__)("Payouts","woocommerce-gateway-stripe"),
                        (0,y.createElement)("span",{className:"wc-stripe-count-badge"},payouts.list?payouts.list.length:0)
                    ),
                    (0,y.createElement)("button",{type:"button",className:\`wc-stripe-sub-tab-btn \${subTab==="customers"?"is-active":""}\`,onClick:()=>setSubTab("customers")},
                        (0,y.createElement)("span",{className:"dashicons dashicons-admin-users"}),
                        (0,He.__)("Customers","woocommerce-gateway-stripe"),
                        (0,y.createElement)("span",{className:"wc-stripe-count-badge"},customers.list?customers.list.length:0)
                    ),
                    (0,y.createElement)("button",{type:"button",className:\`wc-stripe-sub-tab-btn \${subTab==="disputes"?"is-active":""}\`,onClick:()=>setSubTab("disputes")},
                        (0,y.createElement)("span",{className:"dashicons dashicons-warning"}),
                        (0,He.__)("Disputes","woocommerce-gateway-stripe"),
                        (0,y.createElement)("span",{className:"wc-stripe-count-badge"},disputes.list?disputes.list.length:0)
                    )
                ),
                subTab==="transactions"&&(0,y.createElement)("div",{className:"wc-stripe-search-box"},
                    (0,y.createElement)("span",{className:"dashicons dashicons-search"}),
                    (0,y.createElement)("input",{type:"text",className:"wc-stripe-search-input",placeholder:(0,He.__)("Filter transactions...","woocommerce-gateway-stripe"),value:searchTerm,onChange:e=>setSearchTerm(e.target.value)})
                )
            ),
            (0,y.createElement)("div",{className:"wc-stripe-table-body-wrapper"},
                subTab==="transactions"&&(0,y.createElement)("table",{className:"wc-stripe-data-table"},
                    (0,y.createElement)("thead",null,
                        (0,y.createElement)("tr",null,
                            (0,y.createElement)("th",null,(0,He.__)("Transaction ID","woocommerce-gateway-stripe")),
                            (0,y.createElement)("th",null,(0,He.__)("Customer","woocommerce-gateway-stripe")),
                            (0,y.createElement)("th",null,(0,He.__)("Method","woocommerce-gateway-stripe")),
                            (0,y.createElement)("th",null,(0,He.__)("Amount","woocommerce-gateway-stripe")),
                            (0,y.createElement)("th",null,(0,He.__)("Fee / Net","woocommerce-gateway-stripe")),
                            (0,y.createElement)("th",null,(0,He.__)("Status","woocommerce-gateway-stripe")),
                            (0,y.createElement)("th",null,(0,He.__)("Date","woocommerce-gateway-stripe")),
                            (0,y.createElement)("th",null,"")
                        )
                    ),
                    (0,y.createElement)("tbody",null,
                        filteredTransactions.length===0?(0,y.createElement)("tr",null,(0,y.createElement)("td",{colSpan:8,className:"wc-stripe-empty-table"},(0,He.__)("No transactions found in this date range.","woocommerce-gateway-stripe"))):
                        filteredTransactions.map(t=>(0,y.createElement)("tr",{key:t.id},
                            (0,y.createElement)("td",null,(0,y.createElement)("span",{className:"wc-stripe-mono-id"},t.id),(0,y.createElement)("span",{className:"wc-stripe-sub-order"},t.order_id)),
                            (0,y.createElement)("td",null,(0,y.createElement)("div",{className:"wc-stripe-cust-name"},t.customer),(0,y.createElement)("div",{className:"wc-stripe-cust-email"},t.email)),
                            (0,y.createElement)("td",null,(0,y.createElement)("span",{className:"wc-stripe-method-pill"},t.payment_method)),
                            (0,y.createElement)("td",{className:"wc-stripe-bold-amount"},t.amount_fmt),
                            (0,y.createElement)("td",null,(0,y.createElement)("div",{className:"wc-stripe-net-val"},t.net_fmt),(0,y.createElement)("div",{className:"wc-stripe-fee-val"},t.fee_fmt)),
                            (0,y.createElement)("td",null,(0,y.createElement)("span",{className:\`wc-stripe-status-tag is-\${t.status}\`},t.status)),
                            (0,y.createElement)("td",{className:"wc-stripe-date-cell"},t.created),
                            (0,y.createElement)("td",null,(0,y.createElement)("a",{href:t.stripe_url,target:"_blank",rel:"noopener noreferrer",className:"wc-stripe-link-btn"},(0,He.__)("Stripe ↗","woocommerce-gateway-stripe")))
                        ))
                    )
                ),
                subTab==="payouts"&&(0,y.createElement)("table",{className:"wc-stripe-data-table"},
                    (0,y.createElement)("thead",null,
                        (0,y.createElement)("tr",null,
                            (0,y.createElement)("th",null,(0,He.__)("Payout ID","woocommerce-gateway-stripe")),
                            (0,y.createElement)("th",null,(0,He.__)("Destination","woocommerce-gateway-stripe")),
                            (0,y.createElement)("th",null,(0,He.__)("Amount","woocommerce-gateway-stripe")),
                            (0,y.createElement)("th",null,(0,He.__)("Arrival Date","woocommerce-gateway-stripe")),
                            (0,y.createElement)("th",null,(0,He.__)("Status","woocommerce-gateway-stripe")),
                            (0,y.createElement)("th",null,"")
                        )
                    ),
                    (0,y.createElement)("tbody",null,
                        payouts.list.length===0?(0,y.createElement)("tr",null,(0,y.createElement)("td",{colSpan:6,className:"wc-stripe-empty-table"},(0,He.__)("No payouts found in this date range.","woocommerce-gateway-stripe"))):
                        payouts.list.map(p=>(0,y.createElement)("tr",{key:p.id},
                            (0,y.createElement)("td",null,(0,y.createElement)("span",{className:"wc-stripe-mono-id"},p.id)),
                            (0,y.createElement)("td",null,p.destination),
                            (0,y.createElement)("td",{className:"wc-stripe-bold-amount"},p.amount_fmt),
                            (0,y.createElement)("td",{className:"wc-stripe-date-cell"},p.arrival),
                            (0,y.createElement)("td",null,(0,y.createElement)("span",{className:\`wc-stripe-status-tag is-\${p.status}\`},p.status)),
                            (0,y.createElement)("td",null,(0,y.createElement)("a",{href:p.stripe_url,target:"_blank",rel:"noopener noreferrer",className:"wc-stripe-link-btn"},(0,He.__)("Stripe ↗","woocommerce-gateway-stripe")))
                        ))
                    )
                ),
                subTab==="customers"&&(0,y.createElement)("table",{className:"wc-stripe-data-table"},
                    (0,y.createElement)("thead",null,
                        (0,y.createElement)("tr",null,
                            (0,y.createElement)("th",null,(0,He.__)("Customer ID","woocommerce-gateway-stripe")),
                            (0,y.createElement)("th",null,(0,He.__)("Name","woocommerce-gateway-stripe")),
                            (0,y.createElement)("th",null,(0,He.__)("Email","woocommerce-gateway-stripe")),
                            (0,y.createElement)("th",null,(0,He.__)("Created Date","woocommerce-gateway-stripe")),
                            (0,y.createElement)("th",null,"")
                        )
                    ),
                    (0,y.createElement)("tbody",null,
                        customers.list.length===0?(0,y.createElement)("tr",null,(0,y.createElement)("td",{colSpan:5,className:"wc-stripe-empty-table"},(0,He.__)("No customer records found.","woocommerce-gateway-stripe"))):
                        customers.list.map(c=>(0,y.createElement)("tr",{key:c.id},
                            (0,y.createElement)("td",null,(0,y.createElement)("span",{className:"wc-stripe-mono-id"},c.id)),
                            (0,y.createElement)("td",{className:"wc-stripe-cust-name"},c.name),
                            (0,y.createElement)("td",{className:"wc-stripe-cust-email"},c.email),
                            (0,y.createElement)("td",{className:"wc-stripe-date-cell"},c.created),
                            (0,y.createElement)("td",null,(0,y.createElement)("a",{href:c.stripe_url,target:"_blank",rel:"noopener noreferrer",className:"wc-stripe-link-btn"},(0,He.__)("Stripe ↗","woocommerce-gateway-stripe")))
                        ))
                    )
                ),
                subTab==="disputes"&&(0,y.createElement)("table",{className:"wc-stripe-data-table"},
                    (0,y.createElement)("thead",null,
                        (0,y.createElement)("tr",null,
                            (0,y.createElement)("th",null,(0,He.__)("Dispute ID","woocommerce-gateway-stripe")),
                            (0,y.createElement)("th",null,(0,He.__)("Charge","woocommerce-gateway-stripe")),
                            (0,y.createElement)("th",null,(0,He.__)("Disputed Amount","woocommerce-gateway-stripe")),
                            (0,y.createElement)("th",null,(0,He.__)("Reason","woocommerce-gateway-stripe")),
                            (0,y.createElement)("th",null,(0,He.__)("Evidence Due","woocommerce-gateway-stripe")),
                            (0,y.createElement)("th",null,(0,He.__)("Status","woocommerce-gateway-stripe")),
                            (0,y.createElement)("th",null,"")
                        )
                    ),
                    (0,y.createElement)("tbody",null,
                        disputes.list.length===0?(0,y.createElement)("tr",null,(0,y.createElement)("td",{colSpan:7,className:"wc-stripe-empty-table"},(0,He.__)("No disputes recorded. Your account is healthy!","woocommerce-gateway-stripe"))):
                        disputes.list.map(d=>(0,y.createElement)("tr",{key:d.id},
                            (0,y.createElement)("td",null,(0,y.createElement)("span",{className:"wc-stripe-mono-id"},d.id)),
                            (0,y.createElement)("td",null,d.charge_id),
                            (0,y.createElement)("td",{className:"wc-stripe-bold-amount"},d.amount_fmt),
                            (0,y.createElement)("td",null,d.reason),
                            (0,y.createElement)("td",{className:"wc-stripe-date-cell"},d.due_by),
                            (0,y.createElement)("td",null,(0,y.createElement)("span",{className:\`wc-stripe-status-tag is-\${d.status}\`},d.status)),
                            (0,y.createElement)("td",null,(0,y.createElement)("a",{href:d.stripe_url,target:"_blank",rel:"noopener noreferrer",className:"wc-stripe-link-btn"},(0,He.__)("Review ↗","woocommerce-gateway-stripe")))
                        ))
                    )
                )
            )
        )
    );
};
const renderDashboardView=()=>(0,y.createElement)("div",{className:"wc-stripe-tab-view-container wc-stripe-dashboard-view"},(0,y.createElement)(StripeAnalyticsDashboard,null));`;

const updatedJs = jsContent.substring(0, startIdx) + dashboardComponent + jsContent.substring(endIdx);
fs.writeFileSync(jsPath, updatedJs, 'utf8');
console.log('Successfully injected StripeAnalyticsDashboard into build/upe-settings.js');

// CSS Styles for Analytics Dashboard
const dashboardCss = [
  '/* Analytics & Performance Dashboard Styling */',
  '.wc-stripe-account-overview-bar {',
  '    background: #ffffff !important;',
  '    border: 1px solid #e2e8f0 !important;',
  '    border-radius: 12px !important;',
  '    padding: 16px 22px !important;',
  '    margin-bottom: 20px !important;',
  '    display: flex !important;',
  '    align-items: center !important;',
  '    justify-content: space-between !important;',
  '    flex-wrap: wrap !important;',
  '    gap: 16px !important;',
  '    box-shadow: 0 1px 3px rgba(15, 23, 42, 0.04) !important;',
  '}',
  '.wc-stripe-account-info-group {',
  '    display: flex !important;',
  '    align-items: center !important;',
  '    flex-wrap: wrap !important;',
  '    gap: 10px !important;',
  '}',
  '.wc-stripe-account-badge {',
  '    display: inline-flex !important;',
  '    align-items: center !important;',
  '    gap: 6px !important;',
  '    background: #635bff !important;',
  '    color: #ffffff !important;',
  '    font-size: 12px !important;',
  '    font-weight: 700 !important;',
  '    padding: 6px 12px !important;',
  '    border-radius: 6px !important;',
  '}',
  '.wc-stripe-account-badge .dashicons {',
  '    font-size: 16px !important;',
  '    width: 16px !important;',
  '    height: 16px !important;',
  '}',
  '.wc-stripe-account-detail-pill {',
  '    display: inline-flex !important;',
  '    align-items: center !important;',
  '    gap: 6px !important;',
  '    background: #f8fafc !important;',
  '    border: 1px solid #e2e8f0 !important;',
  '    padding: 5px 10px !important;',
  '    border-radius: 6px !important;',
  '    font-size: 12.5px !important;',
  '}',
  '.wc-stripe-detail-label {',
  '    color: #64748b !important;',
  '    font-weight: 500 !important;',
  '}',
  '.wc-stripe-detail-value {',
  '    color: #0f172a !important;',
  '    font-weight: 700 !important;',
  '}',
  '.wc-stripe-detail-value.is-bank {',
  '    color: #0284c7 !important;',
  '}',
  '.wc-stripe-account-actions-group {',
  '    display: flex !important;',
  '    align-items: center !important;',
  '    gap: 12px !important;',
  '}',
  '.wc-stripe-date-range-pills {',
  '    display: inline-flex !important;',
  '    background: #f1f5f9 !important;',
  '    border-radius: 6px !important;',
  '    padding: 3px !important;',
  '    gap: 2px !important;',
  '}',
  '.wc-stripe-range-btn {',
  '    border: none !important;',
  '    background: transparent !important;',
  '    font-size: 11.5px !important;',
  '    font-weight: 700 !important;',
  '    color: #64748b !important;',
  '    padding: 5px 10px !important;',
  '    border-radius: 4px !important;',
  '    cursor: pointer !important;',
  '    transition: all 0.15s ease !important;',
  '}',
  '.wc-stripe-range-btn:hover {',
  '    color: #0f172a !important;',
  '}',
  '.wc-stripe-range-btn.is-selected {',
  '    background: #ffffff !important;',
  '    color: #635bff !important;',
  '    box-shadow: 0 1px 3px rgba(0,0,0,0.08) !important;',
  '}',
  '.wc-stripe-refresh-btn {',
  '    display: inline-flex !important;',
  '    align-items: center !important;',
  '    gap: 6px !important;',
  '    font-size: 12.5px !important;',
  '    font-weight: 600 !important;',
  '    padding: 6px 14px !important;',
  '    height: auto !important;',
  '    border-radius: 6px !important;',
  '    cursor: pointer !important;',
  '}',
  '.wc-stripe-refresh-btn .dashicons {',
  '    font-size: 16px !important;',
  '    width: 16px !important;',
  '    height: 16px !important;',
  '}',
  '.wc-stripe-refresh-btn.is-loading .dashicons {',
  '    animation: spin 1s infinite linear !important;',
  '}',
  '',
  '/* 4-Card KPI Grid */',
  '.wc-stripe-kpi-grid {',
  '    display: grid !important;',
  '    grid-template-columns: repeat(auto-fit, minmax(240px, 1fr)) !important;',
  '    gap: 16px !important;',
  '    margin-bottom: 24px !important;',
  '}',
  '.wc-stripe-kpi-card {',
  '    background: #ffffff !important;',
  '    border: 1px solid #e2e8f0 !important;',
  '    border-radius: 12px !important;',
  '    padding: 20px !important;',
  '    box-shadow: 0 1px 3px rgba(15, 23, 42, 0.04) !important;',
  '    display: flex !important;',
  '    flex-direction: column !important;',
  '    transition: transform 0.2s ease !important;',
  '}',
  '.wc-stripe-kpi-card:hover {',
  '    transform: translateY(-2px) !important;',
  '    box-shadow: 0 4px 12px rgba(15, 23, 42, 0.07) !important;',
  '}',
  '.wc-stripe-kpi-header {',
  '    display: flex !important;',
  '    align-items: center !important;',
  '    justify-content: space-between !important;',
  '    margin-bottom: 10px !important;',
  '}',
  '.wc-stripe-kpi-title {',
  '    font-size: 13px !important;',
  '    font-weight: 600 !important;',
  '    color: #64748b !important;',
  '    text-transform: uppercase !important;',
  '    letter-spacing: 0.03em !important;',
  '}',
  '.wc-stripe-kpi-icon {',
  '    font-size: 20px !important;',
  '    width: 20px !important;',
  '    height: 20px !important;',
  '    color: #94a3b8 !important;',
  '}',
  '.wc-stripe-kpi-value {',
  '    font-size: 24px !important;',
  '    font-weight: 800 !important;',
  '    color: #0f172a !important;',
  '    letter-spacing: -0.02em !important;',
  '    margin-bottom: 12px !important;',
  '}',
  '.wc-stripe-kpi-meta {',
  '    display: flex !important;',
  '    align-items: center !important;',
  '    justify-content: space-between !important;',
  '    gap: 8px !important;',
  '    font-size: 12px !important;',
  '    margin-top: auto !important;',
  '}',
  '.wc-stripe-kpi-subtext {',
  '    color: #64748b !important;',
  '    font-weight: 500 !important;',
  '}',
  '.wc-stripe-kpi-badge {',
  '    font-size: 11px !important;',
  '    font-weight: 700 !important;',
  '    padding: 3px 8px !important;',
  '    border-radius: 6px !important;',
  '}',
  '.wc-stripe-kpi-badge.is-success {',
  '    background: #dcfce7 !important;',
  '    color: #15803d !important;',
  '}',
  '.wc-stripe-kpi-badge.is-info {',
  '    background: #e0e7ff !important;',
  '    color: #4338ca !important;',
  '}',
  '.wc-stripe-kpi-badge.is-arrival {',
  '    background: #f0fdf4 !important;',
  '    color: #166534 !important;',
  '}',
  '.wc-stripe-kpi-badge.is-clean {',
  '    background: #f1f5f9 !important;',
  '    color: #475569 !important;',
  '}',
  '.wc-stripe-kpi-badge.is-alert {',
  '    background: #fee2e2 !important;',
  '    color: #b91c1c !important;',
  '}',
  '',
  '/* Table View Card */',
  '.wc-stripe-analytics-table-card {',
  '    background: #ffffff !important;',
  '    border: 1px solid #e2e8f0 !important;',
  '    border-radius: 12px !important;',
  '    box-shadow: 0 1px 3px rgba(15, 23, 42, 0.04) !important;',
  '    overflow: hidden !important;',
  '}',
  '.wc-stripe-table-nav-bar {',
  '    display: flex !important;',
  '    align-items: center !important;',
  '    justify-content: space-between !important;',
  '    padding: 12px 18px !important;',
  '    background: #f8fafc !important;',
  '    border-bottom: 1px solid #e2e8f0 !important;',
  '    flex-wrap: wrap !important;',
  '    gap: 12px !important;',
  '}',
  '.wc-stripe-sub-tabs-list {',
  '    display: flex !important;',
  '    gap: 8px !important;',
  '}',
  '.wc-stripe-sub-tab-btn {',
  '    display: inline-flex !important;',
  '    align-items: center !important;',
  '    gap: 6px !important;',
  '    padding: 8px 14px !important;',
  '    background: transparent !important;',
  '    border: 1px solid transparent !important;',
  '    border-radius: 6px !important;',
  '    font-size: 13px !important;',
  '    font-weight: 600 !important;',
  '    color: #64748b !important;',
  '    cursor: pointer !important;',
  '    transition: all 0.15s ease !important;',
  '}',
  '.wc-stripe-sub-tab-btn:hover {',
  '    background: #ffffff !important;',
  '    color: #0f172a !important;',
  '}',
  '.wc-stripe-sub-tab-btn.is-active {',
  '    background: #ffffff !important;',
  '    border-color: #cbd5e1 !important;',
  '    color: #635bff !important;',
  '    box-shadow: 0 1px 2px rgba(0,0,0,0.04) !important;',
  '}',
  '.wc-stripe-count-badge {',
  '    font-size: 10.5px !important;',
  '    font-weight: 700 !important;',
  '    background: #e2e8f0 !important;',
  '    color: #475569 !important;',
  '    padding: 1px 6px !important;',
  '    border-radius: 9999px !important;',
  '}',
  '.wc-stripe-search-box {',
  '    position: relative !important;',
  '    display: flex !important;',
  '    align-items: center !important;',
  '}',
  '.wc-stripe-search-box .dashicons {',
  '    position: absolute !important;',
  '    left: 10px !important;',
  '    color: #94a3b8 !important;',
  '    font-size: 16px !important;',
  '}',
  '.wc-stripe-search-input {',
  '    padding: 6px 12px 6px 32px !important;',
  '    font-size: 12.5px !important;',
  '    border: 1px solid #cbd5e1 !important;',
  '    border-radius: 6px !important;',
  '    background: #ffffff !important;',
  '    width: 220px !important;',
  '}',
  '.wc-stripe-table-body-wrapper {',
  '    overflow-x: auto !important;',
  '}',
  '.wc-stripe-data-table {',
  '    width: 100% !important;',
  '    border-collapse: collapse !important;',
  '    text-align: left !important;',
  '}',
  '.wc-stripe-data-table th {',
  '    padding: 12px 18px !important;',
  '    font-size: 12px !important;',
  '    font-weight: 700 !important;',
  '    color: #64748b !important;',
  '    text-transform: uppercase !important;',
  '    letter-spacing: 0.04em !important;',
  '    border-bottom: 1px solid #e2e8f0 !important;',
  '    background: #ffffff !important;',
  '}',
  '.wc-stripe-data-table td {',
  '    padding: 14px 18px !important;',
  '    font-size: 13px !important;',
  '    color: #1e293b !important;',
  '    border-bottom: 1px solid #f1f5f9 !important;',
  '}',
  '.wc-stripe-data-table tr:hover td {',
  '    background: #f8fafc !important;',
  '}',
  '.wc-stripe-mono-id {',
  '    font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace !important;',
  '    font-size: 12px !important;',
  '    color: #635bff !important;',
  '    font-weight: 600 !important;',
  '    display: block !important;',
  '}',
  '.wc-stripe-sub-order {',
  '    font-size: 11.5px !important;',
  '    color: #64748b !important;',
  '}',
  '.wc-stripe-cust-name {',
  '    font-weight: 600 !important;',
  '    color: #0f172a !important;',
  '}',
  '.wc-stripe-cust-email {',
  '    font-size: 12px !important;',
  '    color: #64748b !important;',
  '}',
  '.wc-stripe-bold-amount {',
  '    font-weight: 700 !important;',
  '    font-size: 14px !important;',
  '    color: #0f172a !important;',
  '}',
  '.wc-stripe-net-val {',
  '    font-size: 12.5px !important;',
  '    font-weight: 600 !important;',
  '    color: #16a34a !important;',
  '}',
  '.wc-stripe-fee-val {',
  '    font-size: 11px !important;',
  '    color: #94a3b8 !important;',
  '}',
  '.wc-stripe-status-tag {',
  '    display: inline-block !important;',
  '    font-size: 11px !important;',
  '    font-weight: 700 !important;',
  '    text-transform: uppercase !important;',
  '    padding: 3px 8px !important;',
  '    border-radius: 4px !important;',
  '}',
  '.wc-stripe-status-tag.is-succeeded, .wc-stripe-status-tag.is-paid, .wc-stripe-status-tag.is-won {',
  '    background: #dcfce7 !important;',
  '    color: #15803d !important;',
  '}',
  '.wc-stripe-status-tag.is-failed, .wc-stripe-status-tag.is-lost {',
  '    background: #fee2e2 !important;',
  '    color: #b91c1c !important;',
  '}',
  '.wc-stripe-status-tag.is-refunded, .wc-stripe-status-tag.is-pending, .wc-stripe-status-tag.is-needs_response {',
  '    background: #fef3c7 !important;',
  '    color: #b45309 !important;',
  '}',
  '.wc-stripe-method-pill {',
  '    background: #f1f5f9 !important;',
  '    border: 1px solid #e2e8f0 !important;',
  '    padding: 3px 8px !important;',
  '    border-radius: 4px !important;',
  '    font-size: 11.5px !important;',
  '    font-weight: 600 !important;',
  '    color: #475569 !important;',
  '}',
  '.wc-stripe-date-cell {',
  '    color: #64748b !important;',
  '    font-size: 12.5px !important;',
  '}',
  '.wc-stripe-link-btn {',
  '    color: #635bff !important;',
  '    font-size: 12px !important;',
  '    font-weight: 600 !important;',
  '    text-decoration: none !important;',
  '}',
  '.wc-stripe-link-btn:hover {',
  '    text-decoration: underline !important;',
  '}',
  '.wc-stripe-empty-table {',
  '    text-align: center !important;',
  '    padding: 36px 18px !important;',
  '    color: #64748b !important;',
  '    font-size: 14px !important;',
  '}'
].join('\n');

let cssContent = fs.readFileSync(cssPath, 'utf8');
fs.writeFileSync(cssPath, cssContent + '\n' + dashboardCss, 'utf8');

let rtlCssContent = fs.readFileSync(rtlCssPath, 'utf8');
fs.writeFileSync(rtlCssPath, rtlCssContent + '\n' + dashboardCss, 'utf8');

console.log('Appended dashboard analytics styles to CSS and RTL CSS.');
