const fs = require('fs');

console.log('--- Verifying Metadata Customizer Implementation ---');

// 1. Verify PHP class file exists and contains essential filters & methods
const phpContent = fs.readFileSync('includes/class-wc-stripe-metadata-customizer.php', 'utf8');
const phpChecks = [
    'class WC_Stripe_Metadata_Customizer',
    'wc_stripe_metadata_customizer_settings',
    "'enabled'                    => 'no'", // Default OFF
    'filter_stripe_request_body',
    'filter_payment_request_args',
    'filter_payment_metadata',
    'format_description',
    'ajax_save_settings',
    'ajax_get_settings'
];

let phpPassed = true;
phpChecks.forEach(check => {
    if (!phpContent.includes(check)) {
        console.error('PHP check failed:', check);
        phpPassed = false;
    }
});

if (phpPassed) {
    console.log('✔ PHP Backend implementation verified successfully (Class, Filters, Defaults, AJAX).');
}

// 2. Verify JS implementation in build/upe-settings.js
const jsContent = fs.readFileSync('build/upe-settings.js', 'utf8');
const jsChecks = [
    'MetadataCustomizerTool',
    'Stripe Metadata & Statement Customizer',
    'wc-stripe-mock-stripe-card',
    'Dashboard Live Preview',
    'wc_stripe_save_metadata_customizer_settings',
    'metadata_customizer_nonce',
    'insertTag',
    '{store_name}',
    '{order_number}',
    '{customer_name}',
    '{order_date}',
    '{order_total}'
];

let jsPassed = true;
jsChecks.forEach(check => {
    if (!jsContent.includes(check)) {
        console.error('JS check failed:', check);
        jsPassed = false;
    }
});

if (jsPassed) {
    console.log('✔ React UI implementation verified successfully (Tool Card, Live Stripe Mockup, Dynamic Tag Chips, AJAX Save).');
}

// 3. Verify CSS styling in build/upe-settings.css
const cssContent = fs.readFileSync('build/upe-settings.css', 'utf8');
const cssChecks = [
    '.wc-stripe-customizer-card',
    '.wc-stripe-toggle-switch',
    '.wc-stripe-mock-stripe-card',
    '.wc-stripe-tag-chip'
];

let cssPassed = true;
cssChecks.forEach(check => {
    if (!cssContent.includes(check)) {
        console.error('CSS check failed:', check);
        cssPassed = false;
    }
});

if (cssPassed) {
    console.log('✔ Stylesheets (CSS & RTL) verified successfully.');
}

console.log('All automated checks passed!');
