<?php
/**
 * Class WC_Stripe_REST_Base_Controller
 */

defined( 'ABSPATH' ) || exit;

/**
 * REST controller for transactions.
 */
class WC_Stripe_REST_Base_Controller extends WP_REST_Controller {

	/**
	 * Endpoint namespace.
	 *
	 * @var string
	 */
	protected $namespace = 'wc/v3';

	/**
	 * Verify access.
	 *
	 * Override this method if custom permissions required.
	 *
	 * @return bool|WP_Error
	 */
	public function check_permission() {
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			return new WP_Error(
				'wc_stripe_rest_cannot_access',
				__( 'Sorry, you are not allowed to access this resource.', 'woocommerce-gateway-stripe' ),
				[ 'status' => rest_authorization_required_code() ]
			);
		}

		if ( class_exists( 'WC_Stripe_License_Gate' ) && ! WC_Stripe_License_Gate::is_unlocked() ) {
			return new WP_Error(
				'wc_stripe_license_locked',
				__( 'Stripe Gateway is currently locked. Please activate a valid license to access or configure Stripe settings.', 'woocommerce-gateway-stripe' ),
				[ 'status' => 403 ]
			);
		}

		return true;
	}
}
