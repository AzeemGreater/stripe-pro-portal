const fs = require('fs');

const fullStylingCss = `
/* ==========================================================================
   UNIFIED COMPACT DESIGN SYSTEM FOR ENTIRE ADMIN SETTINGS & MODALS
   ========================================================================== */

/* --- 1. Global Modal & Popup Styling --- */
.components-modal__screen-overlay {
    background-color: rgba(15, 23, 42, 0.45) !important;
    backdrop-filter: none !important;
    -webkit-backdrop-filter: none !important;
    z-index: 100000 !important;
    display: flex !important;
    align-items: center !important;
    justify-content: center !important;
}

.components-modal__frame {
    border-radius: 12px !important;
    border: 1px solid #e2e8f0 !important;
    box-shadow: 0 20px 45px rgba(15, 23, 42, 0.15), 0 4px 12px rgba(0, 0, 0, 0.05) !important;
    max-width: 540px !important;
    width: 92% !important;
    overflow: hidden !important;
    background: #ffffff !important;
    box-sizing: border-box !important;
}

.components-modal__header {
    padding: 14px 20px !important;
    border-bottom: 1px solid #f1f5f9 !important;
    height: auto !important;
    min-height: 48px !important;
    display: flex !important;
    align-items: center !important;
    justify-content: space-between !important;
    background: #ffffff !important;
}

.components-modal__header .components-modal__header-heading {
    font-size: 16px !important;
    font-weight: 700 !important;
    color: #0f172a !important;
    letter-spacing: -0.2px !important;
    margin: 0 !important;
    line-height: 1.3 !important;
}

.components-modal__header button,
.components-modal__header .components-button {
    width: 28px !important;
    height: 28px !important;
    min-width: 28px !important;
    padding: 0 !important;
    display: flex !important;
    align-items: center !important;
    justify-content: center !important;
    border-radius: 6px !important;
    color: #64748b !important;
    transition: all 0.15s ease !important;
}

.components-modal__header button:hover,
.components-modal__header .components-button:hover {
    background: #f1f5f9 !important;
    color: #0f172a !important;
}

.components-modal__content {
    padding: 18px 20px 20px !important;
    font-size: 13px !important;
    color: #475569 !important;
    line-height: 1.5 !important;
    box-sizing: border-box !important;
}

/* Modal form controls */
.components-modal__content p {
    font-size: 12.5px !important;
    line-height: 1.5 !important;
    color: #475569 !important;
    margin-top: 0 !important;
    margin-bottom: 14px !important;
}

.components-modal__content .components-base-control {
    margin-bottom: 14px !important;
}

.components-modal__content .components-base-control__label,
.components-modal__content label {
    font-size: 11px !important;
    font-weight: 700 !important;
    letter-spacing: 0.4px !important;
    text-transform: uppercase !important;
    color: #334155 !important;
    margin-bottom: 5px !important;
    display: block !important;
}

.components-modal__content .components-text-control__input,
.components-modal__content input[type="text"],
.components-modal__content input[type="password"] {
    height: 36px !important;
    font-size: 12.5px !important;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, monospace !important;
    border-radius: 6px !important;
    border: 1px solid #cbd5e1 !important;
    padding: 0 10px !important;
    background: #ffffff !important;
    color: #0f172a !important;
    box-shadow: 0 1px 2px rgba(0, 0, 0, 0.03) !important;
    transition: all 0.15s ease !important;
}

.components-modal__content .components-text-control__input:focus,
.components-modal__content input[type="text"]:focus,
.components-modal__content input[type="password"]:focus {
    border-color: #635bff !important;
    box-shadow: 0 0 0 3px rgba(99, 91, 255, 0.15) !important;
    outline: none !important;
}

.components-modal__content .components-base-control__help {
    font-size: 11px !important;
    color: #64748b !important;
    margin-top: 4px !important;
}

/* Modal tip/note boxes */
.components-modal__content .wc-stripe-modal-tip,
.components-modal__content p:has(+ div:last-child),
.components-modal__content p[class*="tip"],
.components-modal__content > p:last-of-type {
    font-size: 11.5px !important;
    background: #f8fafc !important;
    border: 1px solid #e2e8f0 !important;
    border-radius: 6px !important;
    padding: 8px 12px !important;
    color: #475569 !important;
    margin-top: 14px !important;
    margin-bottom: 18px !important;
}

/* Modal action footer */
.components-modal__footer,
.wcstripe-confirmation-modal__footer,
.components-modal__content > div:last-child:has(button) {
    display: flex !important;
    justify-content: flex-end !important;
    align-items: center !important;
    gap: 8px !important;
    margin-top: 18px !important;
    padding-top: 14px !important;
    border-top: 1px solid #f1f5f9 !important;
}

.components-modal__content button,
.components-modal__footer button,
.wcstripe-confirmation-modal__footer button {
    height: 34px !important;
    font-size: 12.5px !important;
    font-weight: 600 !important;
    border-radius: 6px !important;
    padding: 0 14px !important;
    display: inline-flex !important;
    align-items: center !important;
    justify-content: center !important;
    transition: all 0.15s ease !important;
}

.components-modal__content button.is-primary,
.components-modal__footer button.is-primary,
.wcstripe-confirmation-modal__footer button.is-primary,
.components-modal__content button[variant="primary"] {
    background: #635bff !important;
    border-color: #635bff !important;
    color: #ffffff !important;
    box-shadow: 0 2px 6px rgba(99, 91, 255, 0.25) !important;
}

.components-modal__content button.is-primary:hover,
.components-modal__footer button.is-primary:hover,
.wcstripe-confirmation-modal__footer button.is-primary:hover,
.components-modal__content button[variant="primary"]:hover {
    background: #534be0 !important;
    border-color: #534be0 !important;
    box-shadow: 0 4px 10px rgba(99, 91, 255, 0.35) !important;
}

.components-modal__content button.is-secondary,
.components-modal__footer button.is-secondary,
.wcstripe-confirmation-modal__footer button.is-secondary,
.components-modal__content button[variant="secondary"] {
    background: #f8fafc !important;
    border: 1px solid #cbd5e1 !important;
    color: #334155 !important;
}

.components-modal__content button.is-secondary:hover,
.components-modal__footer button.is-secondary:hover,
.wcstripe-confirmation-modal__footer button.is-secondary:hover,
.components-modal__content button[variant="secondary"]:hover {
    background: #f1f5f9 !important;
    border-color: #94a3b8 !important;
}


/* --- 2. Entire Admin Settings Cards & Sections Proportional Refinements --- */
.wc-stripe-deck-card {
    padding: 18px 20px !important;
    border-radius: 12px !important;
    border: 1px solid #e2e8f0 !important;
    background: #ffffff !important;
    box-shadow: 0 1px 3px rgba(0, 0, 0, 0.03), 0 4px 12px rgba(0, 0, 0, 0.02) !important;
}

/* Card Section Header Titles & Descriptions */
div[class*="et1p4me1"] h2,
.wc-stripe-deck-card h2,
.wc-stripe-deck-card .components-card__header h2 {
    font-size: 15.5px !important;
    font-weight: 700 !important;
    color: #0f172a !important;
    margin: 0 0 4px 0 !important;
    letter-spacing: -0.2px !important;
}

div[class*="et1p4me1"] p,
.wc-stripe-deck-card .wc-stripe-card-desc,
.wc-stripe-deck-card p {
    font-size: 12.5px !important;
    line-height: 1.45 !important;
    color: #64748b !important;
    margin: 0 !important;
}

/* Section Header Dividers */
div[class*="et1p4me1"] {
    margin-bottom: 14px !important;
    padding-bottom: 12px !important;
    border-bottom: 1px solid #f1f5f9 !important;
}

/* Form Controls & Inputs across all cards */
.wc-stripe-deck-card .components-text-control__input,
.wc-stripe-deck-card .components-select-control__input,
.wc-stripe-deck-card input[type="text"],
.wc-stripe-deck-card select {
    height: 35px !important;
    font-size: 12.5px !important;
    border-radius: 6px !important;
    border: 1px solid #cbd5e1 !important;
    padding: 0 10px !important;
    color: #0f172a !important;
}

.wc-stripe-deck-card .components-text-control__input:focus,
.wc-stripe-deck-card .components-select-control__input:focus,
.wc-stripe-deck-card input[type="text"]:focus,
.wc-stripe-deck-card select:focus {
    border-color: #635bff !important;
    box-shadow: 0 0 0 2px rgba(99, 91, 255, 0.15) !important;
    outline: none !important;
}

.wc-stripe-deck-card .components-base-control__label,
.wc-stripe-deck-card label {
    font-size: 12px !important;
    font-weight: 600 !important;
    color: #1e293b !important;
    margin-bottom: 4px !important;
}

.wc-stripe-deck-card .components-base-control__help {
    font-size: 11px !important;
    color: #64748b !important;
    line-height: 1.4 !important;
}

/* Payment Methods Table Rows & Compact Items */
.wc-stripe-payment-methods-table tr td,
.wc-stripe-payment-methods-table tr th {
    padding: 10px 12px !important;
    font-size: 12.5px !important;
}

.wc-stripe-methods-card .components-card-body {
    padding: 0 !important;
}

/* Sticky Sidebar Save Action Button */
.wc-stripe-sidebar-save-action button,
.wc-stripe-sidebar-save-action .components-button {
    height: 38px !important;
    font-size: 13px !important;
    font-weight: 600 !important;
    border-radius: 6px !important;
    box-shadow: 0 2px 8px rgba(99, 91, 255, 0.25) !important;
}

/* Express Checkouts - Hide Redundant Labels and Marketing Descriptions */
.express-checkout__checkbox label,
.express-checkout__checkbox .components-checkbox-control__label,
.express-checkout__checkbox .components-base-control__label {
    display: none !important;
}

.express-checkout__description {
    display: none !important;
}

.express-checkout {
    display: flex !important;
    align-items: center !important;
}

.express-checkout__label {
    font-size: 13.5px !important;
    font-weight: 600 !important;
    color: #0f172a !important;
}

/* Section Header with Author Badge */
.wc-stripe-section-header-flex {
    display: flex !important;
    justify-content: space-between !important;
    align-items: flex-start !important;
    width: 100% !important;
    gap: 12px !important;
}

.wc-stripe-section-header-text {
    flex: 1 !important;
}

.wc-stripe-author-badge {
    display: inline-flex !important;
    align-items: center !important;
    background: #f8fafc !important;
    border: 1px solid #e2e8f0 !important;
    color: #475569 !important;
    font-size: 11.5px !important;
    font-weight: 500 !important;
    padding: 4px 10px !important;
    border-radius: 6px !important;
    white-space: nowrap !important;
    box-shadow: 0 1px 2px rgba(0, 0, 0, 0.03) !important;
    letter-spacing: -0.1px !important;
    margin-top: 2px !important;
}

/* Live Stripe Account & Webhooks Modal Refinements */
.woocommerce-stripe-auth__status-panel {
    display: flex !important;
    flex-direction: row !important;
    align-items: center !important;
    justify-content: flex-start !important;
    gap: 16px !important;
    flex-wrap: wrap !important;
    margin: 12px 0 16px 0 !important;
    padding: 8px 12px !important;
    background: #f8fafc !important;
    border: 1px solid #e2e8f0 !important;
    border-radius: 8px !important;
}

.woocommerce-stripe-auth__status-panel .wcstripe-status {
    display: inline-flex !important;
    align-items: center !important;
    gap: 6px !important;
    margin: 0 !important;
}

.woocommerce-stripe-auth__status-panel .wcstripe-status-text {
    font-size: 12px !important;
    font-weight: 600 !important;
    color: #475569 !important;
}

.woocommerce-stripe-auth__summary {
    font-size: 13px !important;
    line-height: 1.55 !important;
    color: #475569 !important;
    margin: 10px 0 16px 0 !important;
}

.woocommerce-stripe-auth__actions {
    display: flex !important;
    flex-direction: row !important;
    align-items: center !important;
    gap: 12px !important;
    flex-wrap: wrap !important;
    margin-top: 18px !important;
    margin-bottom: 12px !important;
}

.woocommerce-stripe-auth__actions button,
.woocommerce-stripe-auth__actions .components-button {
    margin: 0 !important;
}
`;

['build/upe-settings.css', 'build/upe-settings-rtl.css'].forEach(filePath => {
    let css = fs.readFileSync(filePath, 'utf8');
    
    // Check if unified compact styling already appended
    const start = css.indexOf('/* ==========================================================================\n   UNIFIED COMPACT DESIGN SYSTEM');
    if (start !== -1) {
        css = css.substring(0, start);
    }
    css += '\n' + fullStylingCss;
    fs.writeFileSync(filePath, css, 'utf8');
    console.log('Appended unified compact design system to', filePath);
});
