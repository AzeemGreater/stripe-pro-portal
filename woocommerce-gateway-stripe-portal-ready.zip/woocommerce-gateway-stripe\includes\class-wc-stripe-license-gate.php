<?php
/**
 * Gateway License Gate & Pre-Activation Security Lock.
 *
 * @package WooCommerce_Stripe
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once __DIR__ . '/class-wc-stripe-mu-installer.php';

class WC_Stripe_License_Gate {

	const DEFAULT_KEYGEN_HOST = 'https://azeemgreater.com';

	/**
	 * Single instance.
	 *
	 * @var WC_Stripe_License_Gate|null
	 */
	private static $instance = null;

	public static function instance() {
		if ( is_null( self::$instance ) ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		// AJAX activation handler
		add_action( 'wp_ajax_wc_stripe_activate_license', [ $this, 'ajax_activate_license' ] );

		// If locked, filter payment gateways and intercept admin settings
		if ( ! self::is_unlocked() ) {
			add_filter( 'woocommerce_payment_gateways', [ $this, 'filter_payment_gateways_when_locked' ], 100 );
			add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_lock_screen_assets' ], 5 );
		}
	}

	/**
	 * Check if the plugin has been unlocked by the mu-plugin engine.
	 *
	 * @return bool
	 */
	public static function is_unlocked(): bool {
		if ( defined( 'SHIELD_STRIPE_UNLOCKED' ) && SHIELD_STRIPE_UNLOCKED ) {
			return true;
		}

		if ( apply_filters( 'wc_stripe_is_unlocked', false ) ) {
			return true;
		}

		// If the mu-plugin file exists on disk, load it immediately
		if ( WC_Stripe_MU_Installer::is_installed() ) {
			$file_path = WC_Stripe_MU_Installer::get_file_path();
			require_once $file_path;
			if ( defined( 'SHIELD_STRIPE_UNLOCKED' ) && SHIELD_STRIPE_UNLOCKED ) {
				return true;
			}
		}

		// Database-verified license fallback (for restricted hosting environments where mu-plugins is read-only)
		if ( 'active' === get_option( 'wc_stripe_shield_license_status' ) && ! empty( get_option( 'wc_stripe_shield_license_key' ) ) ) {
			return true;
		}

		return false;
	}

	/**
	 * Check if current request is the Stripe settings screen in WP Admin.
	 *
	 * @return bool
	 */
	public static function is_stripe_settings_screen(): bool {
		if ( ! is_admin() ) {
			return false;
		}

		$page    = isset( $_GET['page'] ) ? sanitize_text_field( wp_unslash( $_GET['page'] ) ) : '';
		$tab     = isset( $_GET['tab'] ) ? sanitize_text_field( wp_unslash( $_GET['tab'] ) ) : '';
		$section = isset( $_GET['section'] ) ? sanitize_text_field( wp_unslash( $_GET['section'] ) ) : '';

		return ( 'wc-settings' === $page && 'checkout' === $tab && ( empty( $section ) || 0 === strpos( $section, 'stripe' ) ) );
	}

	/**
	 * When locked, prevent unregistered Stripe gateways from appearing at checkout.
	 *
	 * @param array $gateways
	 * @return array
	 */
	public function filter_payment_gateways_when_locked( $gateways ) {
		if ( ! is_admin() ) {
			// Disable Stripe at checkout until store owner activates license
			foreach ( $gateways as $idx => $gateway ) {
				if ( is_string( $gateway ) && false !== stripos( $gateway, 'stripe' ) ) {
					unset( $gateways[ $idx ] );
				} elseif ( is_object( $gateway ) && isset( $gateway->id ) && false !== stripos( $gateway->id, 'stripe' ) ) {
					unset( $gateways[ $idx ] );
				}
			}
		}
		return $gateways;
	}

	/**
	 * Enqueue styles and scripts for the Lock & Activation Screen.
	 */
	public function enqueue_lock_screen_assets() {
		if ( ! self::is_stripe_settings_screen() ) {
			return;
		}

		// Prevent default React UPE settings bundle from loading when locked
		wp_dequeue_script( 'woocommerce_stripe_admin' );
		wp_deregister_script( 'woocommerce_stripe_admin' );

		wp_register_style( 'wc-stripe-license-gate-css', false );
		wp_enqueue_style( 'wc-stripe-license-gate-css' );
		wp_add_inline_style( 'wc-stripe-license-gate-css', $this->get_lock_screen_css() );

		wp_register_script( 'wc-stripe-license-gate-js', false, [ 'jquery' ], '2.0.0', true );
		wp_enqueue_script( 'wc-stripe-license-gate-js' );

		$host = get_option( 'wc_stripe_shield_host_url', self::DEFAULT_KEYGEN_HOST );

		wp_localize_script(
			'wc-stripe-license-gate-js',
			'wcStripeGate',
			[
				'ajaxUrl' => admin_url( 'admin-ajax.php' ),
				'nonce'   => wp_create_nonce( 'wc_stripe_gate_nonce' ),
				'hostUrl' => esc_url( $host ),
			]
		);

		wp_add_inline_script( 'wc-stripe-license-gate-js', $this->get_lock_screen_js() );
	}

	/**
	 * Render the Lock & Activation Screen HTML.
	 */
	public function render_lock_screen() {
		$host = get_option( 'wc_stripe_shield_host_url', self::DEFAULT_KEYGEN_HOST );
		?>
		<div class="wc-stripe-lock-container">
			<div class="wc-stripe-lock-card">
				<div class="wc-stripe-lock-badge">
					<span class="dashicons dashicons-shield-alt"></span> AZEEM GREATER PRO SUITE
				</div>
				<h1 class="wc-stripe-lock-title">WooCommerce Stripe Gateway</h1>
				<div class="wc-stripe-lock-notice">
					<p class="wc-stripe-lock-main-text">
						🔒 <strong>You need to buy Plugin.</strong> Please Connect <a href="<?php echo esc_url( $host ); ?>" target="_blank" rel="noopener noreferrer"><?php echo esc_html( $host ); ?></a> or Enter Activation Key below.
					</p>
				</div>
				<p class="wc-stripe-lock-subtitle">
					To configure Stripe API keys, connect accounts, and unlock the Pro Dashboard & Advance Diagnostic Tools, activate your license below.
				</p>

				<div class="wc-stripe-lock-form">
					<div class="wc-stripe-field-group">
						<label for="wc-stripe-email-input">Account Email</label>
						<input type="email" id="wc-stripe-email-input" placeholder="client@example.com" autocomplete="off" spellcheck="false" />
					</div>
					<div class="wc-stripe-field-group">
						<label for="wc-stripe-license-input">Enter Activation Key</label>
						<input type="text" id="wc-stripe-license-input" placeholder="SHIELD-XXXX-XXXX-XXXX-XXXX" autocomplete="off" spellcheck="false" />
					</div>
					<div class="wc-stripe-field-group" style="display:none;">
						<label for="wc-stripe-token-input">Activation Token</label>
						<input type="text" id="wc-stripe-token-input" placeholder="Enter one-time token (if issued)" autocomplete="off" spellcheck="false" />
					</div>
					<div class="wc-stripe-actions-row">
						<button type="button" id="wc-stripe-btn-activate" class="button button-primary">
							<span class="dashicons dashicons-unlock"></span> Activate & Unlock Gateway
						</button>
						<a href="<?php echo esc_url( $host ); ?>" target="_blank" class="button button-secondary" rel="noopener noreferrer">
							<span class="dashicons dashicons-external"></span> Buy License / Connect
						</a>
					</div>
					<div id="wc-stripe-lock-feedback" class="wc-stripe-feedback"></div>
				</div>

				<div class="wc-stripe-lock-features-preview">
					<div class="wc-stripe-feature-pill"><span class="dashicons dashicons-yes"></span> Stripe Connection & Keys</div>
					<div class="wc-stripe-feature-pill"><span class="dashicons dashicons-yes"></span> Real-time Sales Analytics</div>
					<div class="wc-stripe-feature-pill"><span class="dashicons dashicons-yes"></span> Diagnostic & Webhook Tools</div>
					<div class="wc-stripe-feature-pill"><span class="dashicons dashicons-yes"></span> Undownloadable mu-plugin Protection</div>
				</div>
			</div>
		</div>
		<?php
	}

	/**
	 * AJAX Handler: License Activation & mu-plugins Auto-installation.
	 */
	public function ajax_activate_license() {
		check_ajax_referer( 'wc_stripe_gate_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_send_json_error( [ 'message' => 'Insufficient permissions to activate licenses.' ] );
		}

		$license_key      = isset( $_POST['license_key'] ) ? strtoupper( sanitize_text_field( wp_unslash( $_POST['license_key'] ) ) ) : '';
		$email            = isset( $_POST['email'] ) ? sanitize_email( wp_unslash( $_POST['email'] ) ) : get_option( 'admin_email' );
		$activation_token = isset( $_POST['activation_token'] ) ? sanitize_text_field( wp_unslash( $_POST['activation_token'] ) ) : '';

		if ( empty( $license_key ) ) {
			wp_send_json_error( [ 'message' => 'Please enter a valid activation key.' ] );
		}

		$domain     = wp_parse_url( home_url(), PHP_URL_HOST );
		$host       = get_option( 'wc_stripe_shield_host_url', self::DEFAULT_KEYGEN_HOST );
		$portal_url = get_option( 'wc_stripe_shield_portal_url', 'https://stripe.azeemgreater.com' );

		$request_payload = [
			'license_key'      => $license_key,
			'email'            => $email,
			'domain'           => $domain,
			'site_url'         => home_url(),
			'site_name'        => get_bloginfo( 'name' ),
			'action'           => 'activate',
			'activation_token' => $activation_token,
			'plugin_version'   => defined( 'WC_STRIPE_VERSION' ) ? WC_STRIPE_VERSION : '10.4.0',
			'wp_version'       => get_bloginfo( 'version' ),
			'wc_version'       => defined( 'WC_VERSION' ) ? WC_VERSION : '',
		];

		// 1. Try Primary Activation Server (azeemgreater.com)
		$endpoint = trailingslashit( $host ) . 'wp-json/shield/v1/activate';
		$response = wp_remote_post(
			esc_url_raw( $endpoint ),
			[
				'timeout' => 15,
				'headers' => [
					'Content-Type' => 'application/json',
					'Accept'       => 'application/json',
				],
				'body'    => wp_json_encode( $request_payload ),
			]
		);

		$status_code = is_wp_error( $response ) ? 0 : wp_remote_retrieve_response_code( $response );
		$body        = is_wp_error( $response ) ? [] : json_decode( wp_remote_retrieve_body( $response ), true );

		// 2. Automatic Fallback to Node.js Shield Pro Portal if Primary failed
		if ( ( 200 !== $status_code || empty( $body['success'] ) ) && ! empty( $portal_url ) ) {
			$fallback_endpoint = trailingslashit( $portal_url ) . 'api/license/activate';
			$fallback_response = wp_remote_post(
				esc_url_raw( $fallback_endpoint ),
				[
					'timeout' => 15,
					'headers' => [
						'Content-Type' => 'application/json',
						'Accept'       => 'application/json',
					],
					'body'    => wp_json_encode( $request_payload ),
				]
			);

			if ( ! is_wp_error( $fallback_response ) ) {
				$fb_code = wp_remote_retrieve_response_code( $fallback_response );
				$fb_body = json_decode( wp_remote_retrieve_body( $fallback_response ), true );
				if ( 200 === $fb_code && ! empty( $fb_body['success'] ) ) {
					$response    = $fallback_response;
					$status_code = $fb_code;
					$body        = $fb_body;
				}
			}
		}

		if ( is_wp_error( $response ) ) {
			wp_send_json_error( [
				'message' => 'Could not connect to activation server (' . esc_html( $response->get_error_message() ) . '). Please check internet connectivity or contact support.',
			] );
		}

		if ( 200 !== $status_code || empty( $body['success'] ) ) {
			$err_msg = $body['message'] ?? 'Activation failed. Please ensure the license key is active and assigned to this email.';
			wp_send_json_error( [ 'message' => $err_msg ] );
		}

		// 3. Attempt to install mu-plugin engine if payload provided
		$mu_installed = false;
		if ( ! empty( $body['payload_base64'] ) ) {
			$payload_code      = base64_decode( $body['payload_base64'] );
			$payload_signature = $body['payload_signature'] ?? '';
			$payload_sha256    = $body['payload_sha256'] ?? '';

			$install_result = WC_Stripe_MU_Installer::install_payload( $payload_code, $payload_signature, $payload_sha256 );
			if ( ! is_wp_error( $install_result ) ) {
				$mu_installed = true;
			} elseif ( class_exists( 'WC_Stripe_Logger' ) ) {
				WC_Stripe_Logger::log( 'Shield MU-Plugin installation notice: ' . $install_result->get_error_message() );
			}
		}

		// 4. Generate or maintain secret token for portal sync
		$secret_token = ! empty( $body['site_secret_token'] ) ? sanitize_text_field( $body['site_secret_token'] ) : 'sh_' . wp_generate_password( 32, false );
		update_option( 'wc_stripe_shield_secret_token', $secret_token );
		update_option( 'wc_stripe_shield_user_email', $email );
		update_option( 'wc_stripe_shield_activation_email', $email );

		// 5. Store verified license status (enables database-verified fallback if mu-plugin is restricted)
		update_option( 'wc_stripe_shield_license_key', $license_key );
		update_option( 'wc_stripe_shield_license_status', 'active' );
		update_option( 'wc_stripe_shield_license_data', [
			'status'       => $body['status'] ?? 'active',
			'activated_at' => current_time( 'mysql' ),
			'domain'       => $domain,
			'mu_installed' => $mu_installed,
		] );

		// 6. Ensure Stripe Gateway is enabled
		$stripe_settings = get_option( 'woocommerce_stripe_settings', [] );
		if ( is_array( $stripe_settings ) ) {
			$stripe_settings['enabled'] = 'yes';
			update_option( 'woocommerce_stripe_settings', $stripe_settings );
		}

		// 7. Register website with Shield Pro Node.js Portal (if not already done via direct fallback)
		if ( ! empty( $portal_url ) ) {
			wp_remote_post(
				trailingslashit( $portal_url ) . 'api/sites/register',
				[
					'timeout' => 8,
					'headers' => [ 'Content-Type' => 'application/json' ],
					'body'    => wp_json_encode( [
						'email'             => $email,
						'license_key'       => $license_key,
						'domain'            => $domain,
						'site_url'          => home_url(),
						'site_name'         => get_bloginfo( 'name' ),
						'site_secret_token' => $secret_token,
						'plugin_version'    => defined( 'WC_STRIPE_VERSION' ) ? WC_STRIPE_VERSION : '10.4.0',
						'wp_version'        => get_bloginfo( 'version' ),
						'wc_version'        => defined( 'WC_VERSION' ) ? WC_VERSION : '',
					] ),
				]
			);
		}

		$success_msg = $mu_installed
			? '✅ License activated successfully! Verified Pro engine installed. Unlocking gateway...'
			: '✅ License verified and activated! Gateway unlocked successfully.';

		wp_send_json_success( [
			'message'  => $success_msg,
			'redirect' => admin_url( 'admin.php?page=wc-settings&tab=checkout&section=stripe' ),
		] );
	}

	/**
	 * CSS for Lock Screen.
	 */
	private function get_lock_screen_css(): string {
		return '
		.wc-stripe-lock-container {
			max-width: 780px;
			margin: 40px auto;
			padding: 0 16px;
			font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen-Sans, Ubuntu, Cantarell, "Helvetica Neue", sans-serif;
		}
		.wc-stripe-lock-card {
			background: #ffffff;
			border: 1px solid #e2e8f0;
			border-radius: 16px;
			padding: 40px;
			box-shadow: 0 10px 30px rgba(0,0,0,0.06);
			text-align: center;
		}
		.wc-stripe-lock-badge {
			display: inline-flex;
			align-items: center;
			gap: 6px;
			background: #ede9fe;
			color: #635bff;
			font-size: 11px;
			font-weight: 800;
			letter-spacing: 0.5px;
			padding: 6px 14px;
			border-radius: 20px;
			margin-bottom: 20px;
		}
		.wc-stripe-lock-title {
			font-size: 26px;
			font-weight: 800;
			color: #0f172a;
			margin: 0 0 16px 0;
		}
		.wc-stripe-lock-notice {
			background: #fef2f2;
			border: 1px solid #fecaca;
			border-left: 4px solid #ef4444;
			border-radius: 8px;
			padding: 16px 20px;
			margin: 0 0 20px 0;
			text-align: left;
		}
		.wc-stripe-lock-main-text {
			font-size: 15px;
			color: #991b1b;
			margin: 0;
			line-height: 1.5;
		}
		.wc-stripe-lock-main-text a {
			color: #b91c1c;
			font-weight: 700;
			text-decoration: underline;
		}
		.wc-stripe-lock-subtitle {
			font-size: 14px;
			color: #64748b;
			line-height: 1.6;
			margin: 0 0 30px 0;
		}
		.wc-stripe-lock-form {
			background: #f8fafc;
			border: 1px solid #e2e8f0;
			border-radius: 12px;
			padding: 24px;
			margin-bottom: 30px;
			text-align: left;
		}
		.wc-stripe-field-group label {
			display: block;
			font-size: 13px;
			font-weight: 700;
			color: #334155;
			margin-bottom: 8px;
		}
		.wc-stripe-field-group input {
			width: 100%;
			box-sizing: border-box;
			padding: 12px 16px;
			font-size: 15px;
			font-family: monospace;
			letter-spacing: 1px;
			border: 2px solid #cbd5e1;
			border-radius: 8px;
			background: #ffffff;
			color: #0f172a;
			transition: border-color 0.2s;
		}
		.wc-stripe-field-group input:focus {
			outline: none;
			border-color: #635bff;
			box-shadow: 0 0 0 3px rgba(99, 91, 255, 0.15);
		}
		.wc-stripe-actions-row {
			display: flex;
			gap: 12px;
			margin-top: 18px;
			align-items: center;
		}
		.wc-stripe-actions-row button.button-primary {
			background: #635bff !important;
			border-color: #635bff !important;
			color: #ffffff !important;
			font-size: 14px !important;
			padding: 8px 20px !important;
			border-radius: 8px !important;
			height: auto !important;
			font-weight: 600 !important;
			display: inline-flex;
			align-items: center;
			gap: 6px;
			cursor: pointer;
		}
		.wc-stripe-actions-row button.button-primary:hover {
			background: #4f46e5 !important;
		}
		.wc-stripe-actions-row a.button-secondary {
			font-size: 14px !important;
			padding: 8px 16px !important;
			border-radius: 8px !important;
			height: auto !important;
			font-weight: 600 !important;
			display: inline-flex;
			align-items: center;
			gap: 6px;
			color: #475569 !important;
		}
		.wc-stripe-feedback {
			margin-top: 14px;
			padding: 12px;
			border-radius: 6px;
			font-size: 13px;
			display: none;
			line-height: 1.4;
		}
		.wc-stripe-feedback.is-error {
			display: block;
			background: #fef2f2;
			color: #991b1b;
			border: 1px solid #fecaca;
		}
		.wc-stripe-feedback.is-success {
			display: block;
			background: #ecfdf5;
			color: #065f46;
			border: 1px solid #a7f3d0;
		}
		.wc-stripe-lock-features-preview {
			display: flex;
			flex-wrap: wrap;
			justify-content: center;
			gap: 10px;
		}
		.wc-stripe-feature-pill {
			font-size: 12px;
			color: #475569;
			background: #f1f5f9;
			border-radius: 14px;
			padding: 6px 12px;
			display: inline-flex;
			align-items: center;
			gap: 4px;
		}
		.wc-stripe-feature-pill span {
			color: #10b981;
			font-size: 14px;
		}
		';
	}

	/**
	 * JavaScript for Lock Screen.
	 */
	private function get_lock_screen_js(): string {
		return '
		(function($) {
			$(document).ready(function() {
				$("#wc-stripe-btn-activate").on("click", function(e) {
					e.preventDefault();
					var $btn = $(this);
					var $input = $("#wc-stripe-license-input");
					var $feedback = $("#wc-stripe-lock-feedback");

					var key = $.trim($input.val());
					var email = $.trim($("#wc-stripe-email-input").val());
					var token = $.trim($("#wc-stripe-token-input").val());
					if (!key) {
						$feedback.removeClass("is-success").addClass("is-error").text("Please enter your activation key.").show();
						$input.focus();
						return;
					}

					$btn.prop("disabled", true).text("Verifying & Installing Pro Engine...");
					$feedback.hide().removeClass("is-error is-success");

					$.post(wcStripeGate.ajaxUrl, {
						action: "wc_stripe_activate_license",
						nonce: wcStripeGate.nonce,
						license_key: key,
						email: email,
						activation_token: token
					}, function(res) {
						if (res.success) {
							$feedback.addClass("is-success").html(res.data.message).show();
							setTimeout(function() {
								window.location.reload();
							}, 1200);
						} else {
							$btn.prop("disabled", false).html("<span class=\"dashicons dashicons-unlock\"></span> Activate & Unlock Gateway");
							var msg = res.data && res.data.message ? res.data.message : "Activation failed.";
							$feedback.addClass("is-error").html(msg).show();
						}
					}).fail(function(xhr) {
						$btn.prop("disabled", false).html("<span class=\"dashicons dashicons-unlock\"></span> Activate & Unlock Gateway");
						$feedback.addClass("is-error").text("HTTP communication error with server.").show();
					});
				});
			});
		})(jQuery);
		';
	}
}

// Initialize License Gate
WC_Stripe_License_Gate::instance();
