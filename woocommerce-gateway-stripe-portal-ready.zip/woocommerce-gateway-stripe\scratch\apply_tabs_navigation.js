const fs = require('fs');
const path = require('path');

const jsPath = path.join(__dirname, '../build/upe-settings.js');
const cssPath = path.join(__dirname, '../build/upe-settings.css');
const rtlCssPath = path.join(__dirname, '../build/upe-settings-rtl.css');

let jsContent = fs.readFileSync(jsPath, 'utf8');

// Target string in upe-settings.js
const targetPrefix = 'const[modalType,setModalType]=(0,h.useState)(""),[keepModalContent,setKeepModalContent]=(0,h.useState)(!1);return(0,y.createElement)("div",{className:"wc-stripe-unified-deck-layout"},';

if (!jsContent.includes(targetPrefix)) {
    console.error('Target string not found in upe-settings.js');
    process.exit(1);
}

// Backup file
fs.writeFileSync(jsPath + '.bak', jsContent, 'utf8');

const replacementPrefix = `const[modalType,setModalType]=(0,h.useState)(""),[keepModalContent,setKeepModalContent]=(0,h.useState)(!1);
const getInitialTab=()=>{try{const u=new URLSearchParams(window.location.search).get("view");if(u==="dashboard"||u==="advance_tools")return u}catch(e){}return"settings"};
const[activeTab,setActiveTab]=(0,h.useState)(getInitialTab());
(0,h.useEffect)(()=>{const h=()=>{setActiveTab(getInitialTab())};window.addEventListener("popstate",h);return()=>window.removeEventListener("popstate",h)},[]);
const switchTab=t=>{setActiveTab(t);try{const u=new URL(window.location.href);t==="settings"?u.searchParams.delete("view"):u.searchParams.set("view",t);window.history.pushState({},"",u.toString())}catch(e){}};
const renderDashboardView=()=>(0,y.createElement)("div",{className:"wc-stripe-tab-view-container wc-stripe-dashboard-view"},(0,y.createElement)("div",{className:"wc-stripe-scaffold-banner"},(0,y.createElement)("div",{className:"wc-stripe-scaffold-badge"},(0,He.__)("Dashboard","woocommerce-gateway-stripe")),(0,y.createElement)("h2",{className:"wc-stripe-scaffold-title"},(0,He.__)("Stripe Performance & Analytics","woocommerce-gateway-stripe")),(0,y.createElement)("p",{className:"wc-stripe-scaffold-desc"},(0,He.__)("Monitor real-time transactions, volume, conversion analytics, and dispute metrics directly from your store.","woocommerce-gateway-stripe"))),(0,y.createElement)("div",{className:"wc-stripe-scaffold-grid"},(0,y.createElement)("div",{className:"wc-stripe-scaffold-card"},(0,y.createElement)("div",{className:"wc-stripe-scaffold-card-icon dashicons dashicons-chart-area"}),(0,y.createElement)("h3",null,(0,He.__)("Gross Volume","woocommerce-gateway-stripe")),(0,y.createElement)("p",null,(0,He.__)("Track sales trends, average order values, and recurring payment analytics over custom date ranges.","woocommerce-gateway-stripe")),(0,y.createElement)("div",{className:"wc-stripe-scaffold-slot"},(0,He.__)("Widget Slot: Volume Analytics Ready","woocommerce-gateway-stripe"))),(0,y.createElement)("div",{className:"wc-stripe-scaffold-card"},(0,y.createElement)("div",{className:"wc-stripe-scaffold-card-icon dashicons dashicons-yes-alt"}),(0,y.createElement)("h3",null,(0,He.__)("Payment Success Rate","woocommerce-gateway-stripe")),(0,y.createElement)("p",null,(0,He.__)("Real-time authorization ratios, 3DS authentication success rates, and decline code breakdown.","woocommerce-gateway-stripe")),(0,y.createElement)("div",{className:"wc-stripe-scaffold-slot"},(0,He.__)("Widget Slot: Success Rate Ready","woocommerce-gateway-stripe"))),(0,y.createElement)("div",{className:"wc-stripe-scaffold-card"},(0,y.createElement)("div",{className:"wc-stripe-scaffold-card-icon dashicons dashicons-bell"}),(0,y.createElement)("h3",null,(0,He.__)("Disputes & Webhooks","woocommerce-gateway-stripe")),(0,y.createElement)("p",null,(0,He.__)("Instant visibility into chargebacks, dispute responses, and webhook listener delivery latency.","woocommerce-gateway-stripe")),(0,y.createElement)("div",{className:"wc-stripe-scaffold-slot"},(0,He.__)("Widget Slot: Dispute Feed Ready","woocommerce-gateway-stripe")))));
const renderAdvanceToolsView=()=>(0,y.createElement)("div",{className:"wc-stripe-tab-view-container wc-stripe-advance-tools-view"},(0,y.createElement)("div",{className:"wc-stripe-scaffold-banner"},(0,y.createElement)("div",{className:"wc-stripe-scaffold-badge is-beta"},(0,He.__)("Advance Tools","woocommerce-gateway-stripe")),(0,y.createElement)("h2",{className:"wc-stripe-scaffold-title"},(0,He.__)("Diagnostic & Maintenance Tools","woocommerce-gateway-stripe")),(0,y.createElement)("p",{className:"wc-stripe-scaffold-desc"},(0,He.__)("Advanced utilities for database cache purging, webhook endpoint synchronization, API connection diagnostics, and token management.","woocommerce-gateway-stripe"))),(0,y.createElement)("div",{className:"wc-stripe-scaffold-grid"},(0,y.createElement)("div",{className:"wc-stripe-scaffold-card"},(0,y.createElement)("div",{className:"wc-stripe-scaffold-card-icon dashicons dashicons-rest-api"}),(0,y.createElement)("h3",null,(0,He.__)("API & Connection Health","woocommerce-gateway-stripe")),(0,y.createElement)("p",null,(0,He.__)("Test round-trip API connectivity, verify account capabilities, and check publishable/secret key status.","woocommerce-gateway-stripe")),(0,y.createElement)("div",{className:"wc-stripe-scaffold-slot"},(0,He.__)("Tool Slot: API Diagnostics Ready","woocommerce-gateway-stripe"))),(0,y.createElement)("div",{className:"wc-stripe-scaffold-card"},(0,y.createElement)("div",{className:"wc-stripe-scaffold-card-icon dashicons dashicons-update"}),(0,y.createElement)("h3",null,(0,He.__)("Webhook Synchronization","woocommerce-gateway-stripe")),(0,y.createElement)("p",null,(0,He.__)("Re-register endpoint secrets, ping Stripe event listener, and review recent delivery logs.","woocommerce-gateway-stripe")),(0,y.createElement)("div",{className:"wc-stripe-scaffold-slot"},(0,He.__)("Tool Slot: Webhook Sync Ready","woocommerce-gateway-stripe"))),(0,y.createElement)("div",{className:"wc-stripe-scaffold-card"},(0,y.createElement)("div",{className:"wc-stripe-scaffold-card-icon dashicons dashicons-trash"}),(0,y.createElement)("h3",null,(0,He.__)("Cache & Token Utilities","woocommerce-gateway-stripe")),(0,y.createElement)("p",null,(0,He.__)("Flush localized Stripe transient cache, re-index customer payment tokens, and repair legacy mandates.","woocommerce-gateway-stripe")),(0,y.createElement)("div",{className:"wc-stripe-scaffold-slot"},(0,He.__)("Tool Slot: Cache Tools Ready","woocommerce-gateway-stripe")))));
return(0,y.createElement)("div",{className:"wc-stripe-unified-deck-layout"},(0,y.createElement)("div",{className:"wc-stripe-tabs-nav-wrapper"},(0,y.createElement)("div",{className:"wc-stripe-tabs-nav",role:"tablist"},(0,y.createElement)("button",{type:"button",role:"tab","aria-selected":activeTab==="settings",className:\`wc-stripe-tab-btn \${activeTab==="settings"?"is-active":""}\`,onClick:()=>switchTab("settings")},(0,y.createElement)("span",{className:"dashicons dashicons-admin-settings wc-stripe-tab-icon"}),(0,y.createElement)("span",{className:"wc-stripe-tab-label"},(0,He.__)("Settings","woocommerce-gateway-stripe"))),(0,y.createElement)("button",{type:"button",role:"tab","aria-selected":activeTab==="dashboard",className:\`wc-stripe-tab-btn \${activeTab==="dashboard"?"is-active":""}\`,onClick:()=>switchTab("dashboard")},(0,y.createElement)("span",{className:"dashicons dashicons-chart-bar wc-stripe-tab-icon"}),(0,y.createElement)("span",{className:"wc-stripe-tab-label"},(0,He.__)("Dashboard","woocommerce-gateway-stripe")),(0,y.createElement)("span",{className:"wc-stripe-tab-pill"},(0,He.__)("New","woocommerce-gateway-stripe"))),(0,y.createElement)("button",{type:"button",role:"tab","aria-selected":activeTab==="advance_tools",className:\`wc-stripe-tab-btn \${activeTab==="advance_tools"?"is-active":""}\`,onClick:()=>switchTab("advance_tools")},(0,y.createElement)("span",{className:"dashicons dashicons-admin-tools wc-stripe-tab-icon"}),(0,y.createElement)("span",{className:"wc-stripe-tab-label"},(0,He.__)("Advance Tools","woocommerce-gateway-stripe")),(0,y.createElement)("span",{className:"wc-stripe-tab-pill is-beta"},(0,He.__)("Beta","woocommerce-gateway-stripe"))))),activeTab==="dashboard"?renderDashboardView():activeTab==="advance_tools"?renderAdvanceToolsView():(0,y.createElement)(y.Fragment,null,`;

// We also need to close the fragment right before the ending of the component
const originalEnding = '(0,y.createElement)(Vm,{onSettingsSave:d}))))))';
const replacementEnding = '(0,y.createElement)(Vm,{onSettingsSave:d})))))))';

let updatedContent = jsContent.replace(targetPrefix, replacementPrefix);
if (updatedContent === jsContent) {
    console.error('Failed to replace target prefix in upe-settings.js');
    process.exit(1);
}

updatedContent = updatedContent.replace(originalEnding, replacementEnding);
if (!updatedContent.includes(replacementEnding)) {
    console.error('Failed to replace ending in upe-settings.js');
    process.exit(1);
}

fs.writeFileSync(jsPath, updatedContent, 'utf8');
console.log('Successfully updated build/upe-settings.js with 3-tab navigation!');

// Now append CSS styles
const customCss = [
  '/* ==========================================================================',
  '   Stripe 3-Tab Navigation & Minimalist Scaffolds (Developed By Azeem Greater)',
  '   ========================================================================== */',
  '',
  '.wc-stripe-tabs-nav-wrapper {',
  '    margin: 0 0 24px 0 !important;',
  '    padding: 0 !important;',
  '    border-bottom: 2px solid #e2e8f0 !important;',
  '    background: transparent !important;',
  '}',
  '',
  '.wc-stripe-tabs-nav {',
  '    display: flex !important;',
  '    flex-direction: row !important;',
  '    align-items: center !important;',
  '    gap: 8px !important;',
  '    margin: 0 !important;',
  '    padding: 0 !important;',
  '}',
  '',
  '.wc-stripe-tab-btn {',
  '    display: inline-flex !important;',
  '    align-items: center !important;',
  '    gap: 8px !important;',
  '    padding: 12px 20px !important;',
  '    font-size: 14px !important;',
  '    font-weight: 600 !important;',
  '    color: #64748b !important;',
  '    background: transparent !important;',
  '    border: none !important;',
  '    border-bottom: 3px solid transparent !important;',
  '    margin-bottom: -2px !important;',
  '    border-radius: 6px 6px 0 0 !important;',
  '    cursor: pointer !important;',
  '    transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1) !important;',
  '    outline: none !important;',
  '    text-decoration: none !important;',
  '    user-select: none !important;',
  '}',
  '',
  '.wc-stripe-tab-btn:hover {',
  '    color: #0f172a !important;',
  '    background: #f8fafc !important;',
  '}',
  '',
  '.wc-stripe-tab-btn.is-active {',
  '    color: #635bff !important;',
  '    border-bottom: 3px solid #635bff !important;',
  '    background: transparent !important;',
  '}',
  '',
  '.wc-stripe-tab-btn .wc-stripe-tab-icon {',
  '    font-size: 18px !important;',
  '    width: 18px !important;',
  '    height: 18px !important;',
  '    display: inline-flex !important;',
  '    align-items: center !important;',
  '    justify-content: center !important;',
  '    color: inherit !important;',
  '}',
  '',
  '.wc-stripe-tab-pill {',
  '    font-size: 10px !important;',
  '    font-weight: 700 !important;',
  '    text-transform: uppercase !important;',
  '    padding: 2px 7px !important;',
  '    border-radius: 9999px !important;',
  '    background: #e0e7ff !important;',
  '    color: #4338ca !important;',
  '    line-height: 1.2 !important;',
  '    letter-spacing: 0.04em !important;',
  '}',
  '',
  '.wc-stripe-tab-pill.is-beta {',
  '    background: #fef3c7 !important;',
  '    color: #b45309 !important;',
  '}',
  '',
  '/* Tab View Scaffolds */',
  '.wc-stripe-tab-view-container {',
  '    animation: wcStripeTabFadeIn 0.25s ease-in-out !important;',
  '}',
  '',
  '@keyframes wcStripeTabFadeIn {',
  '    from {',
  '        opacity: 0;',
  '        transform: translateY(4px);',
  '    }',
  '    to {',
  '        opacity: 1;',
  '        transform: translateY(0);',
  '    }',
  '}',
  '',
  '.wc-stripe-scaffold-banner {',
  '    background: linear-gradient(135deg, #ffffff 0%, #f8fafc 100%) !important;',
  '    border: 1px solid #e2e8f0 !important;',
  '    border-radius: 12px !important;',
  '    padding: 28px 32px !important;',
  '    margin-bottom: 24px !important;',
  '    box-shadow: 0 1px 3px rgba(15, 23, 42, 0.04) !important;',
  '    position: relative !important;',
  '}',
  '',
  '.wc-stripe-scaffold-badge {',
  '    display: inline-block !important;',
  '    font-size: 11px !important;',
  '    font-weight: 700 !important;',
  '    text-transform: uppercase !important;',
  '    letter-spacing: 0.05em !important;',
  '    padding: 4px 10px !important;',
  '    border-radius: 6px !important;',
  '    background: #ede9fe !important;',
  '    color: #6d28d9 !important;',
  '    margin-bottom: 12px !important;',
  '}',
  '',
  '.wc-stripe-scaffold-badge.is-beta {',
  '    background: #fef3c7 !important;',
  '    color: #b45309 !important;',
  '}',
  '',
  '.wc-stripe-scaffold-title {',
  '    font-size: 20px !important;',
  '    font-weight: 700 !important;',
  '    color: #0f172a !important;',
  '    margin: 0 0 8px 0 !important;',
  '    line-height: 1.3 !important;',
  '}',
  '',
  '.wc-stripe-scaffold-desc {',
  '    font-size: 13.5px !important;',
  '    color: #64748b !important;',
  '    margin: 0 !important;',
  '    line-height: 1.55 !important;',
  '    max-width: 720px !important;',
  '}',
  '',
  '.wc-stripe-scaffold-grid {',
  '    display: grid !important;',
  '    grid-template-columns: repeat(auto-fit, minmax(320px, 1fr)) !important;',
  '    gap: 20px !important;',
  '}',
  '',
  '.wc-stripe-scaffold-card {',
  '    background: #ffffff !important;',
  '    border: 1px solid #e2e8f0 !important;',
  '    border-radius: 12px !important;',
  '    padding: 24px !important;',
  '    box-shadow: 0 1px 3px rgba(15, 23, 42, 0.04) !important;',
  '    display: flex !important;',
  '    flex-direction: column !important;',
  '    transition: transform 0.2s ease, box-shadow 0.2s ease !important;',
  '}',
  '',
  '.wc-stripe-scaffold-card:hover {',
  '    transform: translateY(-2px) !important;',
  '    box-shadow: 0 6px 16px rgba(15, 23, 42, 0.07) !important;',
  '}',
  '',
  '.wc-stripe-scaffold-card-icon {',
  '    width: 36px !important;',
  '    height: 36px !important;',
  '    border-radius: 8px !important;',
  '    background: #f1f5f9 !important;',
  '    color: #635bff !important;',
  '    display: flex !important;',
  '    align-items: center !important;',
  '    justify-content: center !important;',
  '    font-size: 20px !important;',
  '    margin-bottom: 14px !important;',
  '}',
  '',
  '.wc-stripe-scaffold-card h3 {',
  '    font-size: 16px !important;',
  '    font-weight: 700 !important;',
  '    color: #1e293b !important;',
  '    margin: 0 0 8px 0 !important;',
  '}',
  '',
  '.wc-stripe-scaffold-card p {',
  '    font-size: 13px !important;',
  '    color: #64748b !important;',
  '    line-height: 1.5 !important;',
  '    margin: 0 0 16px 0 !important;',
  '    flex-grow: 1 !important;',
  '}',
  '',
  '.wc-stripe-scaffold-slot {',
  '    padding: 12px 14px !important;',
  '    background: #f8fafc !important;',
  '    border: 1px dashed #cbd5e1 !important;',
  '    border-radius: 8px !important;',
  '    font-size: 12px !important;',
  '    font-weight: 600 !important;',
  '    color: #94a3b8 !important;',
  '    text-align: center !important;',
  '    text-transform: uppercase !important;',
  '    letter-spacing: 0.03em !important;',
  '}',
  ''
].join('\n');

let cssContent = fs.readFileSync(cssPath, 'utf8');
if (!cssContent.includes('wc-stripe-tabs-nav-wrapper')) {
    fs.writeFileSync(cssPath, cssContent + '\n' + customCss, 'utf8');
    console.log('Appended tab styles to build/upe-settings.css');
}

let rtlCssContent = fs.readFileSync(rtlCssPath, 'utf8');
if (!rtlCssContent.includes('wc-stripe-tabs-nav-wrapper')) {
    fs.writeFileSync(rtlCssPath, rtlCssContent + '\n' + customCss, 'utf8');
    console.log('Appended tab styles to build/upe-settings-rtl.css');
}
