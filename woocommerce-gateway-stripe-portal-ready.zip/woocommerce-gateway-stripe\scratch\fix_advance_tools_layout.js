const fs = require('fs');
const path = require('path');

const jsPath = path.join(__dirname, '../build/upe-settings.js');
const cssPath = path.join(__dirname, '../build/upe-settings.css');
const rtlCssPath = path.join(__dirname, '../build/upe-settings-rtl.css');

let jsContent = fs.readFileSync(jsPath, 'utf8');

// 1. Update renderAdvanceToolsView to remove the 3 placeholder boxes
const targetOldTools = `const renderAdvanceToolsView=()=>(0,y.createElement)("div",{className:"wc-stripe-tab-view-container wc-stripe-advance-tools-view"},
    (0,y.createElement)(MetadataCustomizerTool,null),
    (0,y.createElement)("div",{className:"wc-stripe-scaffold-grid",style:{marginTop:"24px"}},
        (0,y.createElement)("div",{className:"wc-stripe-scaffold-card"},
            (0,y.createElement)("div",{className:"wc-stripe-scaffold-card-icon dashicons dashicons-rest-api"}),
            (0,y.createElement)("h3",null,(0,He.__)("API & Connection Health","woocommerce-gateway-stripe")),
            (0,y.createElement)("p",null,(0,He.__)("Test round-trip API connectivity, verify account capabilities, and check publishable/secret key status.","woocommerce-gateway-stripe")),
            (0,y.createElement)("div",{className:"wc-stripe-scaffold-slot"},(0,He.__)("Tool Slot: API Diagnostics Ready","woocommerce-gateway-stripe"))
        ),
        (0,y.createElement)("div",{className:"wc-stripe-scaffold-card"},
            (0,y.createElement)("div",{className:"wc-stripe-scaffold-card-icon dashicons dashicons-update"}),
            (0,y.createElement)("h3",null,(0,He.__)("Webhook Synchronization","woocommerce-gateway-stripe")),
            (0,y.createElement)("p",null,(0,He.__)("Re-register endpoint secrets, ping Stripe event listener, and review recent delivery logs.","woocommerce-gateway-stripe")),
            (0,y.createElement)("div",{className:"wc-stripe-scaffold-slot"},(0,He.__)("Tool Slot: Webhook Sync Ready","woocommerce-gateway-stripe"))
        ),
        (0,y.createElement)("div",{className:"wc-stripe-scaffold-card"},
            (0,y.createElement)("div",{className:"wc-stripe-scaffold-card-icon dashicons dashicons-trash"}),
            (0,y.createElement)("h3",null,(0,He.__)("Cache & Token Utilities","woocommerce-gateway-stripe")),
            (0,y.createElement)("p",null,(0,He.__)("Flush localized Stripe transient cache, re-index customer payment tokens, and repair legacy mandates.","woocommerce-gateway-stripe")),
            (0,y.createElement)("div",{className:"wc-stripe-scaffold-slot"},(0,He.__)("Tool Slot: Cache Tools Ready","woocommerce-gateway-stripe"))
        )
    )
);`;

const targetNewTools = `const renderAdvanceToolsView=()=>(0,y.createElement)("div",{className:"wc-stripe-tab-view-container wc-stripe-advance-tools-view"},
    (0,y.createElement)(MetadataCustomizerTool,null)
);`;

if (jsContent.includes(targetOldTools)) {
    jsContent = jsContent.replace(targetOldTools, targetNewTools);
    fs.writeFileSync(jsPath, jsContent, 'utf8');
    console.log('Successfully removed 3 placeholder boxes from renderAdvanceToolsView!');
} else {
    console.log('Looking for alternate placeholder string...');
    const startIdx = jsContent.indexOf('const renderAdvanceToolsView=');
    const endMarker = ';return(0,y.createElement)("div",{className:"wc-stripe-unified-deck-layout"}';
    const endIdx = jsContent.indexOf(endMarker, startIdx);
    if (startIdx !== -1 && endIdx !== -1) {
        jsContent = jsContent.substring(0, startIdx) + targetNewTools + jsContent.substring(endIdx);
        fs.writeFileSync(jsPath, jsContent, 'utf8');
        console.log('Successfully updated renderAdvanceToolsView via slice replacement!');
    }
}

// 2. Refine and enhance the CSS for the customizer card & live preview layout
const refinedCss = `
/* ==========================================================================
   Refined Stripe Metadata Customizer & Live Preview Layout
   ========================================================================== */

.wc-stripe-customizer-card {
    background: #ffffff !important;
    border: 1px solid #e2e8f0 !important;
    border-radius: 14px !important;
    padding: 28px !important;
    box-shadow: 0 4px 20px -2px rgba(15, 23, 42, 0.05), 0 2px 6px -1px rgba(15, 23, 42, 0.02) !important;
    margin-bottom: 24px !important;
    box-sizing: border-box !important;
}

.wc-stripe-customizer-header {
    display: flex !important;
    align-items: center !important;
    justify-content: space-between !important;
    flex-wrap: wrap !important;
    gap: 16px !important;
    padding-bottom: 20px !important;
    border-bottom: 1px solid #e2e8f0 !important;
    margin-bottom: 24px !important;
}

.wc-stripe-customizer-header-left {
    display: flex !important;
    align-items: center !important;
    gap: 14px !important;
}

.wc-stripe-customizer-icon-wrap {
    width: 46px !important;
    height: 46px !important;
    border-radius: 12px !important;
    background: #eef2ff !important;
    color: #635bff !important;
    display: flex !important;
    align-items: center !important;
    justify-content: center !important;
    font-size: 24px !important;
    box-shadow: 0 2px 8px rgba(99, 91, 255, 0.12) !important;
}

.wc-stripe-customizer-title {
    font-size: 19px !important;
    font-weight: 700 !important;
    color: #0f172a !important;
    margin: 0 0 4px 0 !important;
    letter-spacing: -0.01em !important;
}

.wc-stripe-customizer-subtitle {
    font-size: 13px !important;
    color: #64748b !important;
    margin: 0 !important;
    max-width: 680px !important;
    line-height: 1.45 !important;
}

.wc-stripe-customizer-header-right {
    display: flex !important;
    align-items: center !important;
    gap: 12px !important;
}

.wc-stripe-customizer-body {
    display: grid !important;
    grid-template-columns: 1.15fr 0.85fr !important;
    gap: 28px !important;
    align-items: stretch !important;
}

@media (max-width: 1024px) {
    .wc-stripe-customizer-body {
        grid-template-columns: 1fr !important;
    }
}

.wc-stripe-customizer-form-col {
    display: flex !important;
    flex-direction: column !important;
}

.wc-stripe-field-group {
    margin-bottom: 20px !important;
}

.wc-stripe-field-label {
    display: block !important;
    font-size: 13px !important;
    font-weight: 600 !important;
    color: #1e293b !important;
    margin-bottom: 7px !important;
}

.wc-stripe-input {
    width: 100% !important;
    padding: 10px 14px !important;
    font-size: 13.5px !important;
    border: 1px solid #cbd5e1 !important;
    border-radius: 8px !important;
    background: #f8fafc !important;
    color: #0f172a !important;
    transition: all 0.2s ease !important;
    box-sizing: border-box !important;
}

.wc-stripe-input:focus {
    border-color: #635bff !important;
    box-shadow: 0 0 0 3px rgba(99, 91, 255, 0.15) !important;
    background: #ffffff !important;
    outline: none !important;
}

.wc-stripe-field-help {
    font-size: 12px !important;
    color: #64748b !important;
    margin: 6px 0 0 0 !important;
    line-height: 1.45 !important;
}

.wc-stripe-tags-wrapper {
    margin-top: 10px !important;
    padding: 10px 12px !important;
    background: #f1f5f9 !important;
    border-radius: 8px !important;
    border: 1px solid #e2e8f0 !important;
}

.wc-stripe-tags-label {
    display: block !important;
    font-size: 11px !important;
    font-weight: 700 !important;
    color: #475569 !important;
    text-transform: uppercase !important;
    letter-spacing: 0.05em !important;
    margin-bottom: 8px !important;
}

.wc-stripe-tags-list {
    display: flex !important;
    flex-wrap: wrap !important;
    gap: 6px !important;
}

.wc-stripe-tag-chip {
    background: #ffffff !important;
    border: 1px solid #cbd5e1 !important;
    border-radius: 6px !important;
    font-size: 12px !important;
    font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace !important;
    color: #4338ca !important;
    padding: 4px 10px !important;
    cursor: pointer !important;
    transition: all 0.15s ease !important;
    box-shadow: 0 1px 2px rgba(0,0,0,0.03) !important;
}

.wc-stripe-tag-chip:hover {
    background: #e0e7ff !important;
    border-color: #818cf8 !important;
    transform: translateY(-1px) !important;
}

.wc-stripe-customizer-actions {
    display: flex !important;
    align-items: center !important;
    gap: 14px !important;
    margin-top: auto !important;
    padding-top: 10px !important;
}

.wc-stripe-save-btn {
    background: #635bff !important;
    border-color: #635bff !important;
    color: #ffffff !important;
    font-weight: 600 !important;
    padding: 10px 22px !important;
    height: auto !important;
    border-radius: 8px !important;
    cursor: pointer !important;
    transition: all 0.2s ease !important;
    box-shadow: 0 2px 6px rgba(99, 91, 255, 0.25) !important;
}

.wc-stripe-save-btn:hover {
    background: #4f46e5 !important;
    border-color: #4f46e5 !important;
    box-shadow: 0 4px 10px rgba(99, 91, 255, 0.35) !important;
}

/* Perfect Aligned Live Stripe Mockup */
.wc-stripe-customizer-preview-col {
    display: flex !important;
    flex-direction: column !important;
}

.wc-stripe-mock-stripe-card {
    background: #0f172a !important;
    border: 1px solid #1e293b !important;
    border-radius: 12px !important;
    padding: 22px !important;
    color: #f8fafc !important;
    box-shadow: 0 10px 25px -5px rgba(15, 23, 42, 0.3), 0 8px 10px -6px rgba(15, 23, 42, 0.2) !important;
    display: flex !important;
    flex-direction: column !important;
    height: 100% !important;
    box-sizing: border-box !important;
}

.wc-stripe-mock-header {
    display: flex !important;
    align-items: center !important;
    justify-content: space-between !important;
    padding-bottom: 14px !important;
    border-bottom: 1px solid #1e293b !important;
    margin-bottom: 18px !important;
}

.wc-stripe-mock-brand {
    display: flex !important;
    align-items: center !important;
    gap: 10px !important;
}

.wc-stripe-mock-stripe-logo {
    font-weight: 900 !important;
    font-size: 15px !important;
    letter-spacing: -0.04em !important;
    color: #635bff !important;
    background: #ffffff !important;
    padding: 3px 9px !important;
    border-radius: 6px !important;
}

.wc-stripe-mock-tag {
    font-size: 12px !important;
    color: #94a3b8 !important;
    font-weight: 600 !important;
}

.wc-stripe-mock-status-pill {
    font-size: 11px !important;
    font-weight: 700 !important;
    padding: 3px 9px !important;
    border-radius: 9999px !important;
    letter-spacing: 0.02em !important;
}

.wc-stripe-mock-status-pill.is-active {
    background: rgba(34, 197, 94, 0.15) !important;
    color: #4ade80 !important;
    border: 1px solid rgba(74, 222, 128, 0.3) !important;
}

.wc-stripe-mock-status-pill.is-off {
    background: rgba(148, 163, 184, 0.12) !important;
    color: #94a3b8 !important;
    border: 1px solid rgba(148, 163, 184, 0.2) !important;
}

.wc-stripe-mock-body {
    flex: 1 1 auto !important;
}

.wc-stripe-mock-row {
    margin-bottom: 16px !important;
}

.wc-stripe-mock-label {
    display: block !important;
    font-size: 11px !important;
    font-weight: 700 !important;
    text-transform: uppercase !important;
    color: #94a3b8 !important;
    margin-bottom: 6px !important;
    letter-spacing: 0.04em !important;
}

.wc-stripe-mock-value.is-desc {
    display: block !important;
    font-size: 13.5px !important;
    font-weight: 600 !important;
    color: #38bdf8 !important;
    background: #1e293b !important;
    padding: 10px 14px !important;
    border-radius: 8px !important;
    border: 1px solid #334155 !important;
    word-break: break-word !important;
    line-height: 1.45 !important;
}

.wc-stripe-mock-meta-box {
    background: #1e293b !important;
    border: 1px solid #334155 !important;
    border-radius: 8px !important;
    padding: 14px 16px !important;
    font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace !important;
}

.wc-stripe-mock-meta-title {
    font-size: 11px !important;
    font-weight: 700 !important;
    color: #cbd5e1 !important;
    margin-bottom: 10px !important;
    text-transform: uppercase !important;
    letter-spacing: 0.05em !important;
}

.wc-stripe-mock-meta-item {
    display: flex !important;
    align-items: center !important;
    gap: 8px !important;
    font-size: 12.5px !important;
    margin-bottom: 6px !important;
}

.wc-stripe-mock-meta-item:last-child {
    margin-bottom: 0 !important;
}

.wc-stripe-mock-meta-key {
    color: #94a3b8 !important;
}

.wc-stripe-mock-meta-val {
    color: #4ade80 !important;
    word-break: break-all !important;
}

.wc-stripe-mock-footer {
    margin-top: 18px !important;
    padding-top: 14px !important;
    font-size: 11.5px !important;
    color: #64748b !important;
    border-top: 1px solid #1e293b !important;
    line-height: 1.4 !important;
}
`;

let cssContent = fs.readFileSync(cssPath, 'utf8');
fs.writeFileSync(cssPath, cssContent + '\n' + refinedCss, 'utf8');

let rtlCssContent = fs.readFileSync(rtlCssPath, 'utf8');
fs.writeFileSync(rtlCssPath, rtlCssContent + '\n' + refinedCss, 'utf8');

console.log('Updated CSS styling for Advance Tools and Preview mockup.');
