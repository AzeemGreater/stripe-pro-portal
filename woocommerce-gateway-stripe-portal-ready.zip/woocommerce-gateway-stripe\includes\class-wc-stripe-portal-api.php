<?php
/**
 * Shield Pro Portal - Remote REST API Controller
 * Provides secure endpoints for the Node.js Portal to sync settings and analytics.
 *
 * @package WooCommerce_Stripe
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class WC_Stripe_Portal_API {

	const REST_NAMESPACE = 'shield/v1';

	public static function init() {
		add_action( 'rest_api_init', [ __CLASS__, 'register_routes' ] );
	}

	public static function register_routes() {
		// GET /wp-json/shield/v1/settings
		register_rest_route(
			self::REST_NAMESPACE,
			'/settings',
			[
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => [ __CLASS__, 'get_settings' ],
				'permission_callback' => [ __CLASS__, 'verify_shield_token' ],
			]
		);

		// POST /wp-json/shield/v1/settings
		register_rest_route(
			self::REST_NAMESPACE,
			'/settings',
			[
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => [ __CLASS__, 'update_settings' ],
				'permission_callback' => [ __CLASS__, 'verify_shield_token' ],
			]
		);

		// GET /wp-json/shield/v1/status
		register_rest_route(
			self::REST_NAMESPACE,
			'/status',
			[
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => [ __CLASS__, 'get_status' ],
				'permission_callback' => [ __CLASS__, 'verify_shield_token' ],
			]
		);

		// GET /wp-json/shield/v1/analytics
		register_rest_route(
			self::REST_NAMESPACE,
			'/analytics',
			[
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => [ __CLASS__, 'get_analytics' ],
				'permission_callback' => [ __CLASS__, 'verify_shield_token' ],
			]
		);

		// POST /wp-json/shield/v1/disconnect
		register_rest_route(
			self::REST_NAMESPACE,
			'/disconnect',
			[
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => [ __CLASS__, 'disconnect_site' ],
				'permission_callback' => [ __CLASS__, 'verify_shield_token' ],
			]
		);
	}

	/**
	 * Verify X-Shield-Token from request against stored token
	 *
	 * @param WP_REST_Request $request
	 * @return bool|WP_Error
	 */
	public static function verify_shield_token( $request ) {
		$token = $request->get_header( 'x-shield-token' );

		// Fallback to query parameter if header stripped by proxy
		if ( empty( $token ) ) {
			$token = $request->get_param( 'shield_token' );
		}

		// Also check standard Authorization: Bearer <token>
		if ( empty( $token ) ) {
			$auth_header = $request->get_header( 'authorization' );
			if ( ! empty( $auth_header ) && 0 === stripos( $auth_header, 'bearer ' ) ) {
				$token = trim( substr( $auth_header, 7 ) );
			}
		}

		$token        = trim( (string) $token );
		$stored_token = trim( (string) get_option( 'wc_stripe_shield_secret_token', '' ) );
		$stored_key   = trim( (string) get_option( 'wc_stripe_shield_license_key', '' ) );

		// If no token stored yet, check if master license key matches
		if ( empty( $stored_token ) && ! empty( $stored_key ) ) {
			if ( ! empty( $token ) && ( hash_equals( $stored_key, $token ) || 0 === strpos( $token, 'sh_' ) ) ) {
				update_option( 'wc_stripe_shield_secret_token', $token );
				return true;
			}
		}

		if ( ! empty( $token ) ) {
			if ( ! empty( $stored_token ) && hash_equals( $stored_token, $token ) ) {
				return true;
			}
			if ( ! empty( $stored_key ) && hash_equals( $stored_key, $token ) ) {
				return true;
			}
		}

		// Also allow WordPress administrator cookie authentication
		if ( current_user_can( 'manage_woocommerce' ) ) {
			return true;
		}

		return new WP_Error(
			'shield_unauthorized',
			__( 'Invalid or missing X-Shield-Token authentication.', 'woocommerce-gateway-stripe' ),
			[ 'status' => 401 ]
		);
	}

	/**
	 * GET /wp-json/shield/v1/settings
	 */
	public static function get_settings( $request ) {
		$stripe_settings = get_option( 'woocommerce_stripe_settings', [] );
		$meta_settings   = get_option( 'wc_stripe_metadata_customizer_settings', [] );

		$response = [
			'enabled'              => $stripe_settings['enabled'] ?? 'yes',
			'title'                => $stripe_settings['title'] ?? 'Credit / Debit Card (Stripe)',
			'description'          => $stripe_settings['description'] ?? 'Pay securely with your credit or debit card.',
			'testmode'             => $stripe_settings['testmode'] ?? 'yes',
			'statement_descriptor' => $stripe_settings['statement_descriptor'] ?? get_bloginfo( 'name' ),
			'capture'              => $stripe_settings['capture'] ?? 'yes',
			'saved_cards'          => $stripe_settings['saved_cards'] ?? 'yes',
			'inline_cc_form'       => $stripe_settings['inline_cc_form'] ?? 'no',
			'logging'              => $stripe_settings['logging'] ?? 'yes',
			'publishable_key'      => $stripe_settings['publishable_key'] ?? '',
			'test_publishable_key' => $stripe_settings['test_publishable_key'] ?? '',
			'has_keys'             => ( ! empty( $stripe_settings['publishable_key'] ) && ! empty( $stripe_settings['secret_key'] ) ) ||
			                          ( ! empty( $stripe_settings['test_publishable_key'] ) && ! empty( $stripe_settings['test_secret_key'] ) ),
			'metadata_customizer'  => [
				'enabled'                     => $meta_settings['enabled'] ?? 'no',
				'store_name'                  => $meta_settings['store_name'] ?? get_bloginfo( 'name' ),
				'site_url'                    => $meta_settings['site_url'] ?? 'hidden',
				'order_description_template'  => $meta_settings['order_description_template'] ?? '{store_name} - order {order_number}',
				'statement_descriptor_suffix' => $meta_settings['statement_descriptor_suffix'] ?? '',
				'mask_level3'                 => $meta_settings['mask_level3'] ?? 'no',
				'mask_customer_pii'           => $meta_settings['mask_customer_pii'] ?? 'no',
				'strip_shipping'              => $meta_settings['strip_shipping'] ?? 'no',
			],
		];

		return rest_ensure_response( $response );
	}

	/**
	 * POST /wp-json/shield/v1/settings
	 */
	public static function update_settings( $request ) {
		$params = $request->get_json_params();
		if ( ! is_array( $params ) ) {
			$params = $request->get_params();
		}
		if ( ! is_array( $params ) ) {
			$params = [];
		}

		$stripe_settings = get_option( 'woocommerce_stripe_settings', [] );
		if ( ! is_array( $stripe_settings ) ) {
			$stripe_settings = [];
		}

		$boolean_keys = [
			'enabled',
			'testmode',
			'capture',
			'saved_cards',
			'inline_cc_form',
			'logging',
		];

		foreach ( $boolean_keys as $key ) {
			if ( isset( $params[ $key ] ) ) {
				$val                   = $params[ $key ];
				$stripe_settings[ $key ] = ( 'yes' === $val || true === $val || '1' === $val ) ? 'yes' : 'no';
			}
		}

		$text_keys = [
			'title',
			'description',
			'statement_descriptor',
			'publishable_key',
			'secret_key',
			'test_publishable_key',
			'test_secret_key',
			'webhook_secret',
			'test_webhook_secret',
		];

		foreach ( $text_keys as $key ) {
			if ( isset( $params[ $key ] ) ) {
				$stripe_settings[ $key ] = sanitize_text_field( $params[ $key ] );
			}
		}

		update_option( 'woocommerce_stripe_settings', $stripe_settings );

		// Update Metadata Customizer if present
		if ( isset( $params['metadata_customizer'] ) && is_array( $params['metadata_customizer'] ) ) {
			$meta = $params['metadata_customizer'];
			update_option( 'wc_stripe_metadata_customizer_settings', [
				'enabled'                     => ( isset( $meta['enabled'] ) && ( 'yes' === $meta['enabled'] || true === $meta['enabled'] || '1' === $meta['enabled'] ) ) ? 'yes' : 'no',
				'store_name'                  => sanitize_text_field( $meta['store_name'] ?? get_bloginfo( 'name' ) ),
				'site_url'                    => sanitize_text_field( $meta['site_url'] ?? 'hidden' ),
				'order_description_template'  => sanitize_text_field( $meta['order_description_template'] ?? '{store_name} - order {order_number}' ),
				'statement_descriptor_suffix' => sanitize_text_field( $meta['statement_descriptor_suffix'] ?? '' ),
				'mask_level3'                 => ( isset( $meta['mask_level3'] ) && ( 'yes' === $meta['mask_level3'] || true === $meta['mask_level3'] || '1' === $meta['mask_level3'] ) ) ? 'yes' : 'no',
				'mask_customer_pii'           => ( isset( $meta['mask_customer_pii'] ) && ( 'yes' === $meta['mask_customer_pii'] || true === $meta['mask_customer_pii'] || '1' === $meta['mask_customer_pii'] ) ) ? 'yes' : 'no',
				'strip_shipping'              => ( isset( $meta['strip_shipping'] ) && ( 'yes' === $meta['strip_shipping'] || true === $meta['strip_shipping'] || '1' === $meta['strip_shipping'] ) ) ? 'yes' : 'no',
			] );
		}

		return rest_ensure_response( [
			'success' => true,
			'message' => __( 'Gateway settings updated successfully.', 'woocommerce-gateway-stripe' ),
		] );
	}

	/**
	 * GET /wp-json/shield/v1/status
	 */
	public static function get_status( $request ) {
		global $wp_version;

		$is_unlocked = class_exists( 'WC_Stripe_License_Gate' ) && WC_Stripe_License_Gate::is_unlocked();
		$settings    = get_option( 'woocommerce_stripe_settings', [] );

		return rest_ensure_response( [
			'success'         => true,
			'status'          => $is_unlocked ? 'active' : 'locked',
			'license_status'  => get_option( 'wc_stripe_shield_license_status', 'inactive' ),
			'is_unlocked'     => $is_unlocked,
			'gateway_enabled' => ( is_array( $settings ) && isset( $settings['enabled'] ) && 'yes' === $settings['enabled'] ),
			'site_name'       => get_bloginfo( 'name' ),
			'site_url'        => home_url(),
			'plugin_version'  => defined( 'WC_STRIPE_VERSION' ) ? WC_STRIPE_VERSION : '10.4.0',
			'wp_version'      => $wp_version,
			'wc_version'      => defined( 'WC_VERSION' ) ? WC_VERSION : 'unknown',
		] );
	}

	/**
	 * GET /wp-json/shield/v1/analytics
	 */
	public static function get_analytics( $request ) {
		$range = $request->get_param( 'range' ) ?: '30d';

		if ( class_exists( 'WC_Stripe_Analytics_Controller' ) ) {
			$data = WC_Stripe_Analytics_Controller::get_analytics_data( $range );
			return rest_ensure_response( $data );
		}

		return rest_ensure_response( [
			'range'   => $range,
			'summary' => [
				'gross_volume' => 0,
				'gross_volume_fmt' => '$0.00',
				'net_volume' => 0,
				'net_volume_fmt' => '$0.00',
				'total_fees_fmt' => '$0.00',
				'success_count' => 0,
				'failed_count' => 0,
				'total_count' => 0,
				'success_rate' => 100,
			],
			'balance' => [
				'available' => 0,
				'pending' => 0,
				'available_formatted' => '$0.00',
				'pending_formatted' => '$0.00',
			],
			'transactions' => [],
		] );
	}

	/**
	 * POST /wp-json/shield/v1/disconnect
	 * Deactivate license on WordPress site and disable Stripe payment gateway
	 */
	public static function disconnect_site( $request ) {
		// 1. Deactivate Shield License in WordPress options
		delete_option( 'wc_stripe_shield_license_key' );
		delete_option( 'wc_stripe_shield_secret_token' );
		delete_option( 'wc_stripe_shield_activation_email' );
		update_option( 'wc_stripe_shield_license_status', 'inactive' );

		// 2. Disable Stripe Gateway in WooCommerce
		$stripe_settings = get_option( 'woocommerce_stripe_settings', [] );
		if ( is_array( $stripe_settings ) ) {
			$stripe_settings['enabled'] = 'no';
			update_option( 'woocommerce_stripe_settings', $stripe_settings );
		}

		// 3. Remove mu-plugin payload to return gateway to locked activation state
		if ( class_exists( 'WC_Stripe_MU_Installer' ) ) {
			WC_Stripe_MU_Installer::remove_payload();
		}

		return rest_ensure_response( [
			'success' => true,
			'message' => __( 'Site successfully disconnected, license deactivated, and Stripe disabled.', 'woocommerce-gateway-stripe' ),
		] );
	}
}

// Initialize on plugin load
WC_Stripe_Portal_API::init();
