<?php
/**
 * Shield Pro Portal - Remote REST API Controller
 * Provides secure endpoints for the Node.js Portal to sync settings and analytics.
 *
 * @package WooCommerce_Stripe
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class WC_Stripe_Portal_API {

	const REST_NAMESPACE = 'shield/v1';

	public static function init() {
		add_action( 'rest_api_init', [ __CLASS__, 'register_routes' ] );
	}

	public static function register_routes() {
		// GET /wp-json/shield/v1/settings
		register_rest_route(
			self::REST_NAMESPACE,
			'/settings',
			[
				'methods'             => 'GET',
				'callback'            => [ __CLASS__, 'get_settings' ],
				'permission_callback' => [ __CLASS__, 'verify_shield_token' ],
			]
		);

		// POST /wp-json/shield/v1/settings
		register_rest_route(
			self::REST_NAMESPACE,
			'/settings',
			[
				'methods'             => 'POST',
				'callback'            => [ __CLASS__, 'update_settings' ],
				'permission_callback' => [ __CLASS__, 'verify_shield_token' ],
			]
		);

		// GET /wp-json/shield/v1/status
		register_rest_route(
			self::REST_NAMESPACE,
			'/status',
			[
				'methods'             => 'GET',
				'callback'            => [ __CLASS__, 'get_status' ],
				'permission_callback' => [ __CLASS__, 'verify_shield_token' ],
			]
		);

		// GET /wp-json/shield/v1/analytics
		register_rest_route(
			self::REST_NAMESPACE,
			'/analytics',
			[
				'methods'             => 'GET',
				'callback'            => [ __CLASS__, 'get_analytics' ],
				'permission_callback' => [ __CLASS__, 'verify_shield_token' ],
			]
		);

		// POST /wp-json/shield/v1/disconnect
		register_rest_route(
			self::REST_NAMESPACE,
			'/disconnect',
			[
				'methods'             => 'POST',
				'callback'            => [ __CLASS__, 'disconnect_site' ],
				'permission_callback' => [ __CLASS__, 'verify_shield_token' ],
			]
		);
	}

	/**
	 * Verify X-Shield-Token from request against stored token
	 *
	 * @param WP_REST_Request $request
	 * @return bool|WP_Error
	 */
	public static function verify_shield_token( $request ) {
		$token = $request->get_header( 'x-shield-token' );

		// Fallback to query parameter if header stripped by proxy
		if ( empty( $token ) ) {
			$token = $request->get_param( 'shield_token' );
		}

		$stored_token = get_option( 'wc_stripe_shield_secret_token', '' );

		// If no token stored yet, check if master license key matches
		if ( empty( $stored_token ) ) {
			$stored_key = get_option( 'wc_stripe_shield_license_key', '' );
			if ( ! empty( $stored_key ) && ! empty( $token ) && ( $token === $stored_key || 0 === strpos( $token, 'sh_' ) ) ) {
				// Initialize secret token
				update_option( 'wc_stripe_shield_secret_token', $token );
				return true;
			}
		}

		if ( ! empty( $token ) && hash_equals( (string) $stored_token, (string) $token ) ) {
			return true;
		}

		// Also allow WordPress administrator cookie authentication
		if ( current_user_can( 'manage_woocommerce' ) ) {
			return true;
		}

		return new WP_Error(
			'shield_unauthorized',
			__( 'Invalid or missing X-Shield-Token authentication.', 'woocommerce-gateway-stripe' ),
			[ 'status' => 401 ]
		);
	}

	/**
	 * GET /wp-json/shield/v1/settings
	 */
	public static function get_settings( $request ) {
		$stripe_settings = get_option( 'woocommerce_stripe_settings', [] );
		$meta_settings   = get_option( 'wc_stripe_metadata_customizer_settings', [] );

		$response = [
			'enabled'              => $stripe_settings['enabled'] ?? 'yes',
			'title'                => $stripe_settings['title'] ?? 'Credit / Debit Card (Stripe)',
			'description'          => $stripe_settings['description'] ?? 'Pay securely with your credit or debit card.',
			'testmode'             => $stripe_settings['testmode'] ?? 'yes',
			'statement_descriptor' => $stripe_settings['statement_descriptor'] ?? get_bloginfo( 'name' ),
			'capture'              => $stripe_settings['capture'] ?? 'yes',
			'saved_cards'          => $stripe_settings['saved_cards'] ?? 'yes',
			'inline_cc_form'       => $stripe_settings['inline_cc_form'] ?? 'no',
			'logging'              => $stripe_settings['logging'] ?? 'yes',
			'metadata_customizer'  => [
				'enabled'                    => $meta_settings['enabled'] ?? 'no',
				'store_name'                 => $meta_settings['store_name'] ?? get_bloginfo( 'name' ),
				'site_url'                   => $meta_settings['site_url'] ?? 'hidden',
				'order_description_template' => $meta_settings['order_description_template'] ?? '{store_name} - order {order_number}',
				'statement_descriptor_suffix' => $meta_settings['statement_descriptor_suffix'] ?? '',
				'mask_level3'                => $meta_settings['mask_level3'] ?? 'yes',
				'mask_customer_pii'          => $meta_settings['mask_customer_pii'] ?? 'yes',
				'strip_shipping'             => $meta_settings['strip_shipping'] ?? 'yes',
			],
		];

		return rest_ensure_response( $response );
	}

	/**
	 * POST /wp-json/shield/v1/settings
	 */
	public static function update_settings( $request ) {
		$params          = $request->get_json_params();
		$stripe_settings = get_option( 'woocommerce_stripe_settings', [] );

		$allowed_stripe_keys = [
			'enabled',
			'title',
			'description',
			'testmode',
			'statement_descriptor',
			'capture',
			'saved_cards',
			'inline_cc_form',
			'logging',
		];

		foreach ( $allowed_stripe_keys as $key ) {
			if ( isset( $params[ $key ] ) ) {
				$stripe_settings[ $key ] = sanitize_text_field( $params[ $key ] );
			}
		}

		update_option( 'woocommerce_stripe_settings', $stripe_settings );

		// Update Metadata Customizer if present
		if ( isset( $params['metadata_customizer'] ) && is_array( $params['metadata_customizer'] ) ) {
			$meta = $params['metadata_customizer'];
			update_option( 'wc_stripe_metadata_customizer_settings', [
				'enabled'                    => sanitize_text_field( $meta['enabled'] ?? 'no' ),
				'store_name'                 => sanitize_text_field( $meta['store_name'] ?? get_bloginfo( 'name' ) ),
				'site_url'                   => sanitize_text_field( $meta['site_url'] ?? 'hidden' ),
				'order_description_template' => sanitize_text_field( $meta['order_description_template'] ?? '{store_name} - order {order_number}' ),
				'statement_descriptor_suffix' => sanitize_text_field( $meta['statement_descriptor_suffix'] ?? '' ),
				'mask_level3'                => sanitize_text_field( $meta['mask_level3'] ?? 'yes' ),
				'mask_customer_pii'          => sanitize_text_field( $meta['mask_customer_pii'] ?? 'yes' ),
				'strip_shipping'             => sanitize_text_field( $meta['strip_shipping'] ?? 'yes' ),
			] );
		}

		return rest_ensure_response( [
			'success' => true,
			'message' => __( 'Gateway settings updated successfully.', 'woocommerce-gateway-stripe' ),
		] );
	}

	/**
	 * GET /wp-json/shield/v1/status
	 */
	public static function get_status( $request ) {
		global $wp_version;

		return rest_ensure_response( [
			'success'        => true,
			'status'         => 'active',
			'site_name'      => get_bloginfo( 'name' ),
			'site_url'       => home_url(),
			'plugin_version' => defined( 'WC_STRIPE_VERSION' ) ? WC_STRIPE_VERSION : '10.4.0',
			'wp_version'     => $wp_version,
			'wc_version'     => defined( 'WC_VERSION' ) ? WC_VERSION : 'unknown',
		] );
	}

	/**
	 * GET /wp-json/shield/v1/analytics
	 */
	public static function get_analytics( $request ) {
		$range = $request->get_param( 'range' ) ?: '30d';

		if ( class_exists( 'WC_Stripe_Analytics_Controller' ) ) {
			$data = WC_Stripe_Analytics_Controller::get_analytics_data( $range );
			return rest_ensure_response( $data );
		}

		return rest_ensure_response( [
			'range'   => $range,
			'summary' => [
				'gross_volume' => 0,
				'gross_volume_fmt' => '$0.00',
				'net_volume' => 0,
				'net_volume_fmt' => '$0.00',
				'total_fees_fmt' => '$0.00',
				'success_count' => 0,
				'failed_count' => 0,
				'total_count' => 0,
				'success_rate' => 100,
			],
			'balance' => [
				'available' => 0,
				'pending' => 0,
				'available_formatted' => '$0.00',
				'pending_formatted' => '$0.00',
			],
			'transactions' => [],
		] );
	}

	/**
	 * POST /wp-json/shield/v1/disconnect
	 * Deactivate license on WordPress site and disable Stripe payment gateway
	 */
	public static function disconnect_site( $request ) {
		// 1. Deactivate Shield License in WordPress options
		delete_option( 'wc_stripe_shield_license_key' );
		delete_option( 'wc_stripe_shield_secret_token' );
		delete_option( 'wc_stripe_shield_activation_email' );
		update_option( 'wc_stripe_shield_license_status', 'inactive' );

		// 2. Disable Stripe Gateway in WooCommerce
		$stripe_settings = get_option( 'woocommerce_stripe_settings', [] );
		if ( is_array( $stripe_settings ) ) {
			$stripe_settings['enabled'] = 'no';
			update_option( 'woocommerce_stripe_settings', $stripe_settings );
		}

		return rest_ensure_response( [
			'success' => true,
			'message' => __( 'Site successfully disconnected, license deactivated, and Stripe disabled.', 'woocommerce-gateway-stripe' ),
		] );
	}
}

// Initialize on plugin load
WC_Stripe_Portal_API::init();
