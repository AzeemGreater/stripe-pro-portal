const fs = require('fs');
const path = require('path');

const jsPath = path.join(__dirname, '../build/upe-settings.js');
const cssPath = path.join(__dirname, '../build/upe-settings.css');
const rtlCssPath = path.join(__dirname, '../build/upe-settings-rtl.css');

let jsContent = fs.readFileSync(jsPath, 'utf8');

const startMarker = 'const MetadataCustomizerTool=()=>{';
const startIdx = jsContent.indexOf(startMarker);

const endMarker = ';return(0,y.createElement)("div",{className:"wc-stripe-unified-deck-layout"},(0,y.createElement)("div",{className:"wc-stripe-tab';
const endIdx = jsContent.indexOf(endMarker, startIdx);

if (startIdx === -1 || endIdx === -1) {
    console.error('Could not find component boundaries in upe-settings.js');
    process.exit(1);
}

const expandedComponent = `const MetadataCustomizerTool=()=>{
    const initialMeta=(typeof wc_stripe_settings_params!=="undefined"&&wc_stripe_settings_params.metadata_customizer_settings)||{
        enabled:"no",
        site_url:"hidden",
        store_name:"BEKAPAINT LIMITED",
        order_description_template:"{store_name} - order {order_number}",
        mask_level3:"no",
        mask_customer_pii:"no",
        strip_shipping:"no",
        statement_descriptor_suffix:""
    };
    const [enabled,setEnabled]=(0,h.useState)(initialMeta.enabled==="yes"||initialMeta.enabled===true);
    const [siteUrl,setSiteUrl]=(0,h.useState)(initialMeta.site_url||"hidden");
    const [storeName,setStoreName]=(0,h.useState)(initialMeta.store_name||"BEKAPAINT LIMITED");
    const [descTemplate,setDescTemplate]=(0,h.useState)(initialMeta.order_description_template||"{store_name} - order {order_number}");
    const [maskLevel3,setMaskLevel3]=(0,h.useState)(initialMeta.mask_level3==="yes"||initialMeta.mask_level3===true);
    const [maskPii,setMaskPii]=(0,h.useState)(initialMeta.mask_customer_pii==="yes"||initialMeta.mask_customer_pii===true);
    const [stripShipping,setStripShipping]=(0,h.useState)(initialMeta.strip_shipping==="yes"||initialMeta.strip_shipping===true);
    const [statementSuffix,setStatementSuffix]=(0,h.useState)(initialMeta.statement_descriptor_suffix||"");

    const [isSaving,setIsSaving]=(0,h.useState)(!1);
    const [saveStatus,setSaveStatus]=(0,h.useState)("");
    const [saveMessage,setSaveMessage]=(0,h.useState)("");

    const insertTag=(tag)=>{
        setDescTemplate(prev=>prev?prev+" "+tag:tag);
    };

    const getFormattedPreviewDesc=()=>{
        let out=descTemplate||"";
        out=out.replace(/{store_name}/g,storeName||"Store Name");
        out=out.replace(/{order_number}/g,"1042");
        out=out.replace(/{customer_name}/g,maskPii?"Customer #1042":"Sarah Jenkins");
        out=out.replace(/{order_date}/g,"2026-09-21");
        out=out.replace(/{order_total}/g,"$129.00");
        return out;
    };

    const handleSave=()=>{
        setIsSaving(!0);
        setSaveStatus("");
        const ajaxUrl=(typeof ajaxurl!=="undefined"?ajaxurl:(typeof wc_stripe_settings_params!=="undefined"?wc_stripe_settings_params.ajax_url:"admin-ajax.php"));
        const nonce=(typeof wc_stripe_settings_params!=="undefined"&&wc_stripe_settings_params.metadata_customizer_nonce)||"";
        const formData=new URLSearchParams();
        formData.append("action","wc_stripe_save_metadata_customizer_settings");
        formData.append("security",nonce);
        formData.append("enabled",enabled?"yes":"no");
        formData.append("site_url",siteUrl);
        formData.append("store_name",storeName);
        formData.append("order_description_template",descTemplate);
        formData.append("mask_level3",maskLevel3?"yes":"no");
        formData.append("mask_customer_pii",maskPii?"yes":"no");
        formData.append("strip_shipping",stripShipping?"yes":"no");
        formData.append("statement_descriptor_suffix",statementSuffix);

        fetch(ajaxUrl,{
            method:"POST",
            headers:{"Content-Type":"application/x-www-form-urlencoded"},
            body:formData.toString()
        }).then(r=>r.json()).then(res=>{
            setIsSaving(!1);
            if(res.success){
                setSaveStatus("success");
                setSaveMessage((0,He.__)("Privacy & cloaking settings saved successfully!","woocommerce-gateway-stripe"));
                setTimeout(()=>setSaveStatus(""),4000);
            }else{
                setSaveStatus("error");
                setSaveMessage((res.data&&res.data.message)||(0,He.__)("Failed to save settings.","woocommerce-gateway-stripe"));
            }
        }).catch(err=>{
            setIsSaving(!1);
            setSaveStatus("error");
            setSaveMessage((0,He.__)("Connection error while saving.","woocommerce-gateway-stripe"));
        });
    };

    return (0,y.createElement)("div",{className:"wc-stripe-customizer-card"},
        (0,y.createElement)("div",{className:"wc-stripe-customizer-header"},
            (0,y.createElement)("div",{className:"wc-stripe-customizer-header-left"},
                (0,y.createElement)("div",{className:"wc-stripe-customizer-icon-wrap"},
                    (0,y.createElement)("span",{className:"dashicons dashicons-shield-alt"})
                ),
                (0,y.createElement)("div",null,
                    (0,y.createElement)("h3",{className:"wc-stripe-customizer-title"},(0,He.__)("Stripe Privacy & Data Cloaking Suite","woocommerce-gateway-stripe")),
                    (0,y.createElement)("p",{className:"wc-stripe-customizer-subtitle"},(0,He.__)("Mask store metadata, product line items, shipping data, customer PII, and customize bank statement descriptions sent to Stripe.","woocommerce-gateway-stripe"))
                )
            ),
            (0,y.createElement)("div",{className:"wc-stripe-customizer-header-right"},
                (0,y.createElement)("label",{className:"wc-stripe-toggle-switch"},
                    (0,y.createElement)("input",{type:"checkbox",checked:enabled,onChange:e=>setEnabled(e.target.checked)}),
                    (0,y.createElement)("span",{className:"wc-stripe-toggle-slider"})
                ),
                (0,y.createElement)("span",{className:\`wc-stripe-status-indicator \${enabled?"is-active":"is-disabled"}\`},enabled?(0,He.__)("Suite Active","woocommerce-gateway-stripe"):(0,He.__)("Disabled (Default OFF)","woocommerce-gateway-stripe"))
            )
        ),
        (0,y.createElement)("div",{className:"wc-stripe-customizer-body"},
            (0,y.createElement)("div",{className:"wc-stripe-customizer-form-col"},
                (0,y.createElement)("div",{className:"wc-stripe-section-divider-title"},(0,He.__)("Store Identifiers & Statement Description","woocommerce-gateway-stripe")),
                (0,y.createElement)("div",{className:"wc-stripe-field-group"},
                    (0,y.createElement)("label",{className:"wc-stripe-field-label"},(0,He.__)("Site URL Metadata (site_url)","woocommerce-gateway-stripe")),
                    (0,y.createElement)("input",{type:"text",className:"wc-stripe-input",value:siteUrl,placeholder:"hidden",onChange:e=>setSiteUrl(e.target.value)}),
                    (0,y.createElement)("p",{className:"wc-stripe-field-help"},(0,He.__)("Custom value sent for site_url in Stripe metadata (e.g. 'hidden' or custom domain).","woocommerce-gateway-stripe"))
                ),
                (0,y.createElement)("div",{className:"wc-stripe-field-group"},
                    (0,y.createElement)("label",{className:"wc-stripe-field-label"},(0,He.__)("Store Name Metadata (site_name)","woocommerce-gateway-stripe")),
                    (0,y.createElement)("input",{type:"text",className:"wc-stripe-input",value:storeName,placeholder:"BEKAPAINT LIMITED",onChange:e=>setStoreName(e.target.value)}),
                    (0,y.createElement)("p",{className:"wc-stripe-field-help"},(0,He.__)("The brand name sent in Stripe metadata and used for description formatting.","woocommerce-gateway-stripe"))
                ),
                (0,y.createElement)("div",{className:"wc-stripe-field-group"},
                    (0,y.createElement)("label",{className:"wc-stripe-field-label"},(0,He.__)("Order Description Template","woocommerce-gateway-stripe")),
                    (0,y.createElement)("input",{type:"text",className:"wc-stripe-input",value:descTemplate,placeholder:"{store_name} - order {order_number}",onChange:e=>setDescTemplate(e.target.value)}),
                    (0,y.createElement)("div",{className:"wc-stripe-tags-wrapper"},
                        (0,y.createElement)("span",{className:"wc-stripe-tags-label"},(0,He.__)("Insert Dynamic Tags:","woocommerce-gateway-stripe")),
                        (0,y.createElement)("div",{className:"wc-stripe-tags-list"},
                            (0,y.createElement)("button",{type:"button",className:"wc-stripe-tag-chip",onClick:()=>insertTag("{store_name}")},"{store_name}"),
                            (0,y.createElement)("button",{type:"button",className:"wc-stripe-tag-chip",onClick:()=>insertTag("{order_number}")},"{order_number}"),
                            (0,y.createElement)("button",{type:"button",className:"wc-stripe-tag-chip",onClick:()=>insertTag("{customer_name}")},"{customer_name}"),
                            (0,y.createElement)("button",{type:"button",className:"wc-stripe-tag-chip",onClick:()=>insertTag("{order_date}")},"{order_date}"),
                            (0,y.createElement)("button",{type:"button",className:"wc-stripe-tag-chip",onClick:()=>insertTag("{order_total}")},"{order_total}")
                        )
                    )
                ),
                (0,y.createElement)("div",{className:"wc-stripe-field-group"},
                    (0,y.createElement)("label",{className:"wc-stripe-field-label"},(0,He.__)("Bank Statement Descriptor Suffix (Optional)","woocommerce-gateway-stripe")),
                    (0,y.createElement)("input",{type:"text",className:"wc-stripe-input",value:statementSuffix,placeholder:"e.g. BEKAPAINT",maxLength:22,onChange:e=>setStatementSuffix(e.target.value)}),
                    (0,y.createElement)("p",{className:"wc-stripe-field-help"},(0,He.__)("Appears on the customer's credit card/bank statement (max 22 characters).","woocommerce-gateway-stripe"))
                ),
                (0,y.createElement)("div",{className:"wc-stripe-section-divider-title",style:{marginTop:"14px"}},(0,He.__)("Stealth & Data Cloaking Rules","woocommerce-gateway-stripe")),
                (0,y.createElement)("div",{className:"wc-stripe-toggle-feature-row"},
                    (0,y.createElement)("div",null,
                        (0,y.createElement)("span",{className:"wc-stripe-toggle-feature-title"},(0,He.__)("Cloak Level 3 Product Line Items","woocommerce-gateway-stripe")),
                        (0,y.createElement)("span",{className:"wc-stripe-toggle-feature-desc"},(0,He.__)("Removes product names, SKUs, and itemized basket details from Stripe payloads.","woocommerce-gateway-stripe"))
                    ),
                    (0,y.createElement)("label",{className:"wc-stripe-toggle-switch"},
                        (0,y.createElement)("input",{type:"checkbox",checked:maskLevel3,onChange:e=>setMaskLevel3(e.target.checked)}),
                        (0,y.createElement)("span",{className:"wc-stripe-toggle-slider"})
                    )
                ),
                (0,y.createElement)("div",{className:"wc-stripe-toggle-feature-row"},
                    (0,y.createElement)("div",null,
                        (0,y.createElement)("span",{className:"wc-stripe-toggle-feature-title"},(0,He.__)("Anonymize Customer PII","woocommerce-gateway-stripe")),
                        (0,y.createElement)("span",{className:"wc-stripe-toggle-feature-desc"},(0,He.__)("Masks customer full name and email in Stripe metadata (e.g. Customer #1042).","woocommerce-gateway-stripe"))
                    ),
                    (0,y.createElement)("label",{className:"wc-stripe-toggle-switch"},
                        (0,y.createElement)("input",{type:"checkbox",checked:maskPii,onChange:e=>setMaskPii(e.target.checked)}),
                        (0,y.createElement)("span",{className:"wc-stripe-toggle-slider"})
                    )
                ),
                (0,y.createElement)("div",{className:"wc-stripe-toggle-feature-row"},
                    (0,y.createElement)("div",null,
                        (0,y.createElement)("span",{className:"wc-stripe-toggle-feature-title"},(0,He.__)("Strip Physical Shipping Address","woocommerce-gateway-stripe")),
                        (0,y.createElement)("span",{className:"wc-stripe-toggle-feature-desc"},(0,He.__)("Suppresses delivery street address and apartment numbers sent to Stripe.","woocommerce-gateway-stripe"))
                    ),
                    (0,y.createElement)("label",{className:"wc-stripe-toggle-switch"},
                        (0,y.createElement)("input",{type:"checkbox",checked:stripShipping,onChange:e=>setStripShipping(e.target.checked)}),
                        (0,y.createElement)("span",{className:"wc-stripe-toggle-slider"})
                    )
                ),
                (0,y.createElement)("div",{className:"wc-stripe-customizer-actions"},
                    (0,y.createElement)("button",{type:"button",className:\`button button-primary wc-stripe-save-btn \${isSaving?"is-busy":""}\`,disabled:isSaving,onClick:handleSave},
                        isSaving?(0,He.__)("Saving...","woocommerce-gateway-stripe"):(0,He.__)("Save Privacy Settings","woocommerce-gateway-stripe")
                    ),
                    saveStatus==="success"&&(0,y.createElement)("span",{className:"wc-stripe-save-notice is-success"},
                        (0,y.createElement)("span",{className:"dashicons dashicons-yes"}),
                        saveMessage
                    ),
                    saveStatus==="error"&&(0,y.createElement)("span",{className:"wc-stripe-save-notice is-error"},
                        (0,y.createElement)("span",{className:"dashicons dashicons-warning"}),
                        saveMessage
                    )
                )
            ),
            (0,y.createElement)("div",{className:"wc-stripe-customizer-preview-col"},
                (0,y.createElement)("div",{className:"wc-stripe-mock-stripe-card"},
                    (0,y.createElement)("div",{className:"wc-stripe-mock-header"},
                        (0,y.createElement)("div",{className:"wc-stripe-mock-brand"},
                            (0,y.createElement)("span",{className:"wc-stripe-mock-stripe-logo"},"stripe"),
                            (0,y.createElement)("span",{className:"wc-stripe-mock-tag"},(0,He.__)("Dashboard Live Preview","woocommerce-gateway-stripe"))
                        ),
                        (0,y.createElement)("span",{className:\`wc-stripe-mock-status-pill \${enabled?"is-active":"is-off"}\`},
                            enabled?(0,He.__)("Cloaking Active","woocommerce-gateway-stripe"):(0,He.__)("Default State (Disabled)","woocommerce-gateway-stripe")
                        )
                    ),
                    (0,y.createElement)("div",{className:"wc-stripe-mock-body"},
                        (0,y.createElement)("div",{className:"wc-stripe-mock-row"},
                            (0,y.createElement)("span",{className:"wc-stripe-mock-label"},(0,He.__)("Statement Description:","woocommerce-gateway-stripe")),
                            (0,y.createElement)("span",{className:"wc-stripe-mock-value is-desc"},
                                enabled?getFormattedPreviewDesc():"Your Store Name - Order 1042"
                            )
                        ),
                        statementSuffix&&(0,y.createElement)("div",{className:"wc-stripe-mock-row"},
                            (0,y.createElement)("span",{className:"wc-stripe-mock-label"},(0,He.__)("Bank Statement Descriptor:","woocommerce-gateway-stripe")),
                            (0,y.createElement)("span",{className:"wc-stripe-mock-value is-suffix"},
                                enabled?(\`STRIPE* \${statementSuffix}\`):"STRIPE* STORE"
                            )
                        ),
                        (0,y.createElement)("div",{className:"wc-stripe-mock-row"},
                            (0,y.createElement)("span",{className:"wc-stripe-mock-label"},(0,He.__)("Product Data & Shipping Status:","woocommerce-gateway-stripe")),
                            (0,y.createElement)("div",{style:{display:"flex",gap:"8px",flexWrap:"wrap"}},
                                (0,y.createElement)("span",{className:\`wc-stripe-pill-badge \${enabled&&maskLevel3?"is-shielded":"is-exposed"}\`},
                                    enabled&&maskLevel3?(0,He.__)("Level 3 Items: Stripped","woocommerce-gateway-stripe"):(0,He.__)("Level 3 Items: Transmitted","woocommerce-gateway-stripe")
                                ),
                                (0,y.createElement)("span",{className:\`wc-stripe-pill-badge \${enabled&&stripShipping?"is-shielded":"is-exposed"}\`},
                                    enabled&&stripShipping?(0,He.__)("Shipping Addr: Omitted","woocommerce-gateway-stripe"):(0,He.__)("Shipping Addr: Transmitted","woocommerce-gateway-stripe")
                                )
                            )
                        ),
                        (0,y.createElement)("div",{className:"wc-stripe-mock-meta-box"},
                            (0,y.createElement)("div",{className:"wc-stripe-mock-meta-title"},(0,He.__)("Metadata Payload (Stripe API)","woocommerce-gateway-stripe")),
                            (0,y.createElement)("div",{className:"wc-stripe-mock-meta-item"},
                                (0,y.createElement)("span",{className:"wc-stripe-mock-meta-key"},"site_url:"),
                                (0,y.createElement)("span",{className:"wc-stripe-mock-meta-val"},
                                    enabled?(\`"\${siteUrl||"hidden"}"\`):('"https://example.com"')
                                )
                            ),
                            (0,y.createElement)("div",{className:"wc-stripe-mock-meta-item"},
                                (0,y.createElement)("span",{className:"wc-stripe-mock-meta-key"},"site_name:"),
                                (0,y.createElement)("span",{className:"wc-stripe-mock-meta-val"},
                                    enabled?(\`"\${storeName||"BEKAPAINT LIMITED"}"\`):('"My Original WooCommerce Store"')
                                )
                            ),
                            (0,y.createElement)("div",{className:"wc-stripe-mock-meta-item"},
                                (0,y.createElement)("span",{className:"wc-stripe-mock-meta-key"},"customer_name:"),
                                (0,y.createElement)("span",{className:"wc-stripe-mock-meta-val"},
                                    enabled&&maskPii?'"Customer #1042"':'"Sarah Jenkins"'
                                )
                            ),
                            (0,y.createElement)("div",{className:"wc-stripe-mock-meta-item"},
                                (0,y.createElement)("span",{className:"wc-stripe-mock-meta-key"},"customer_email:"),
                                (0,y.createElement)("span",{className:"wc-stripe-mock-meta-val"},
                                    enabled&&maskPii?'"customer1042@hidden.local"':'"sarah@example.com"'
                                )
                            ),
                            (0,y.createElement)("div",{className:"wc-stripe-mock-meta-item"},
                                (0,y.createElement)("span",{className:"wc-stripe-mock-meta-key"},"order_id:"),
                                (0,y.createElement)("span",{className:"wc-stripe-mock-meta-val"},'"1042"')
                            )
                        )
                    ),
                    (0,y.createElement)("div",{className:"wc-stripe-mock-footer"},
                        enabled?(0,He.__)("All active cloaking rules will automatically apply on checkout and payment intents.","woocommerce-gateway-stripe"):(0,He.__)("Turn the master switch to ON to activate the cloaking rules.","woocommerce-gateway-stripe")
                    )
                )
            )
        )
    );
};
const renderAdvanceToolsView=()=>(0,y.createElement)("div",{className:"wc-stripe-tab-view-container wc-stripe-advance-tools-view"},
    (0,y.createElement)(MetadataCustomizerTool,null)
);`;

const updatedJs = jsContent.substring(0, startIdx) + expandedComponent + jsContent.substring(endIdx);
fs.writeFileSync(jsPath, updatedJs, 'utf8');
console.log('Successfully injected expanded MetadataCustomizerTool into build/upe-settings.js');

// CSS Styles for Privacy Suite
const suiteCss = [
  '/* Expanded Privacy Suite Styling */',
  '.wc-stripe-section-divider-title {',
  '    font-size: 13px !important;',
  '    font-weight: 700 !important;',
  '    color: #334155 !important;',
  '    text-transform: uppercase !important;',
  '    letter-spacing: 0.05em !important;',
  '    padding-bottom: 8px !important;',
  '    border-bottom: 1px solid #f1f5f9 !important;',
  '    margin-bottom: 16px !important;',
  '}',
  '.wc-stripe-toggle-feature-row {',
  '    display: flex !important;',
  '    align-items: center !important;',
  '    justify-content: space-between !important;',
  '    padding: 12px 14px !important;',
  '    background: #f8fafc !important;',
  '    border: 1px solid #e2e8f0 !important;',
  '    border-radius: 8px !important;',
  '    margin-bottom: 12px !important;',
  '    gap: 16px !important;',
  '}',
  '.wc-stripe-toggle-feature-title {',
  '    display: block !important;',
  '    font-size: 13.5px !important;',
  '    font-weight: 600 !important;',
  '    color: #1e293b !important;',
  '    margin-bottom: 2px !important;',
  '}',
  '.wc-stripe-toggle-feature-desc {',
  '    display: block !important;',
  '    font-size: 12px !important;',
  '    color: #64748b !important;',
  '    line-height: 1.4 !important;',
  '}',
  '.wc-stripe-mock-value.is-suffix {',
  '    display: inline-block !important;',
  '    font-size: 13px !important;',
  '    font-weight: 700 !important;',
  '    color: #f59e0b !important;',
  '    background: #1e293b !important;',
  '    padding: 6px 12px !important;',
  '    border-radius: 6px !important;',
  '    border: 1px solid #334155 !important;',
  '}',
  '.wc-stripe-pill-badge {',
  '    font-size: 11px !important;',
  '    font-weight: 600 !important;',
  '    padding: 3px 8px !important;',
  '    border-radius: 6px !important;',
  '}',
  '.wc-stripe-pill-badge.is-shielded {',
  '    background: rgba(34, 197, 94, 0.15) !important;',
  '    color: #4ade80 !important;',
  '    border: 1px solid rgba(74, 222, 128, 0.3) !important;',
  '}',
  '.wc-stripe-pill-badge.is-exposed {',
  '    background: rgba(148, 163, 184, 0.12) !important;',
  '    color: #94a3b8 !important;',
  '    border: 1px solid rgba(148, 163, 184, 0.2) !important;',
  '}'
].join('\n');

let cssContent = fs.readFileSync(cssPath, 'utf8');
fs.writeFileSync(cssPath, cssContent + '\n' + suiteCss, 'utf8');

let rtlCssContent = fs.readFileSync(rtlCssPath, 'utf8');
fs.writeFileSync(rtlCssPath, rtlCssContent + '\n' + suiteCss, 'utf8');

console.log('Appended suite styles to CSS and RTL CSS.');
