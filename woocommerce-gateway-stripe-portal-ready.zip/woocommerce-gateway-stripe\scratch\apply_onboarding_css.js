const fs = require('fs');

const onboardingCss = `
/* ==========================================================================
   COMPACT ONBOARDING & WELCOME CARD LAYOUT (#f8f9fa canvas, 12px rounded cards)
   ========================================================================== */

.wc-stripe-onboarding-deck-wrapper {
    background-color: #f8f9fa;
    min-height: calc(100vh - 80px);
    padding: 24px 16px;
    box-sizing: border-box;
    display: flex;
    justify-content: center;
    align-items: flex-start;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen-Sans, Ubuntu, Cantarell, "Helvetica Neue", sans-serif;
}

.wc-stripe-onboarding-card {
    background: #ffffff;
    border: 1px solid #e2e8f0;
    border-radius: 12px;
    box-shadow: 0 4px 20px rgba(0, 0, 0, 0.04), 0 1px 3px rgba(0, 0, 0, 0.02);
    width: 100%;
    max-width: 820px;
    overflow: hidden;
    box-sizing: border-box;
    transition: all 0.2s ease-in-out;
}

.wc-stripe-onboarding-banner {
    width: 100%;
    overflow: hidden;
    line-height: 0;
    background: linear-gradient(135deg, #635bff 0%, #a259ff 50%, #ff5e62 100%);
}

.wc-stripe-onboarding-banner img {
    width: 100%;
    height: auto;
    display: block;
    max-height: 100px;
    object-fit: cover;
}

.wc-stripe-onboarding-content-grid {
    display: flex;
    flex-direction: row;
    padding: 24px 28px 20px;
    gap: 28px;
    box-sizing: border-box;
}

@media (max-width: 800px) {
    .wc-stripe-onboarding-content-grid {
        flex-direction: column;
        padding: 20px;
        gap: 20px;
    }
}

/* Left Column: Info & Value Props */
.wc-stripe-onboarding-info-col {
    flex: 1 1 56%;
    display: flex;
    flex-direction: column;
}

.wc-stripe-onboarding-title {
    font-size: 20px !important;
    font-weight: 700 !important;
    color: #1a1f36 !important;
    margin: 0 0 8px 0 !important;
    letter-spacing: -0.3px;
    line-height: 1.3 !important;
}

.wc-stripe-onboarding-description {
    font-size: 13px !important;
    line-height: 1.5 !important;
    color: #4f566b !important;
    margin: 0 0 16px 0 !important;
}

.wc-stripe-onboarding-features-list {
    display: flex;
    flex-direction: column;
    gap: 10px;
    background: #f8fafc;
    border: 1px solid #edf2f7;
    border-radius: 10px;
    padding: 14px 16px;
    box-sizing: border-box;
}

.wc-stripe-feature-item {
    display: flex;
    align-items: flex-start;
    gap: 10px;
}

.wc-stripe-feature-icon {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    width: 18px;
    height: 18px;
    background-color: #ecfdf5;
    color: #059669;
    border-radius: 50%;
    font-weight: 700;
    font-size: 10.5px;
    flex-shrink: 0;
    margin-top: 1px;
}

.wc-stripe-feature-text {
    font-size: 12px;
    line-height: 1.45;
    color: #475569;
}

.wc-stripe-feature-text strong {
    color: #0f172a;
    font-weight: 600;
}

/* Right Column: Actions Box */
.wc-stripe-onboarding-actions-col {
    flex: 1 1 44%;
    display: flex;
    flex-direction: column;
}

.wc-stripe-actions-box {
    background: #ffffff;
    border: 1px solid #e2e8f0;
    border-radius: 10px;
    padding: 18px 18px 16px;
    box-sizing: border-box;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.02);
    display: flex;
    flex-direction: column;
}

.wc-stripe-actions-box-title {
    font-size: 14.5px !important;
    font-weight: 700 !important;
    color: #0f172a !important;
    margin: 0 0 4px 0 !important;
}

.wc-stripe-actions-box-sub {
    font-size: 12px !important;
    line-height: 1.4 !important;
    color: #64748b !important;
    margin: 0 0 14px 0 !important;
}

.wc-stripe-auth-buttons-stack {
    display: flex;
    flex-direction: column;
    gap: 9px;
    width: 100%;
}

.wc-stripe-auth-buttons-stack button,
.wc-stripe-auth-buttons-stack .components-button {
    width: 100% !important;
    justify-content: center !important;
    height: 36px !important;
    font-size: 12.5px !important;
    font-weight: 600 !important;
    border-radius: 6px !important;
    transition: all 0.2s ease !important;
    display: flex !important;
    align-items: center !important;
    text-align: center !important;
    padding: 0 12px !important;
}

.wc-stripe-auth-buttons-stack button.is-primary,
.wc-stripe-auth-buttons-stack button[variant="primary"] {
    background: #635bff !important;
    border-color: #635bff !important;
    color: #ffffff !important;
    box-shadow: 0 2px 8px rgba(99, 91, 255, 0.2) !important;
}

.wc-stripe-auth-buttons-stack button.is-primary:hover,
.wc-stripe-auth-buttons-stack button[variant="primary"]:hover {
    background: #534be0 !important;
    border-color: #534be0 !important;
    transform: translateY(-1px);
    box-shadow: 0 4px 12px rgba(99, 91, 255, 0.3) !important;
}

.wc-stripe-auth-buttons-stack button.is-secondary,
.wc-stripe-auth-buttons-stack button[variant="secondary"] {
    background: #f8fafc !important;
    border: 1px solid #cbd5e1 !important;
    color: #334155 !important;
}

.wc-stripe-auth-buttons-stack button.is-secondary:hover,
.wc-stripe-auth-buttons-stack button[variant="secondary"]:hover {
    background: #f1f5f9 !important;
    border-color: #94a3b8 !important;
}

.wc-stripe-btn-connect-api {
    background: transparent !important;
    border: 1px dashed #94a3b8 !important;
    color: #475569 !important;
}

.wc-stripe-btn-connect-api:hover {
    background: #f8fafc !important;
    border-color: #635bff !important;
    color: #635bff !important;
}

.wc-stripe-auth-help-note {
    font-size: 11px !important;
    line-height: 1.4 !important;
    color: #64748b !important;
    margin: 12px 0 0 0 !important;
    border-top: 1px solid #f1f5f9;
    padding-top: 10px;
}

.wc-stripe-actions-box p {
    font-size: 11px !important;
    line-height: 1.4 !important;
    margin-top: 8px !important;
    margin-bottom: 0 !important;
}

/* Footer: Developed by Azeem Greater & Security Badge */
.wc-stripe-onboarding-footer {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 12px 28px;
    background: #f8fafc;
    border-top: 1px solid #e2e8f0;
    box-sizing: border-box;
    flex-wrap: wrap;
    gap: 8px;
}

.wc-stripe-developer-tag {
    font-size: 12px;
    font-weight: 600;
    color: #635bff;
    letter-spacing: 0.1px;
    display: inline-flex;
    align-items: center;
    gap: 4px;
}

.wc-stripe-badge-secure {
    font-size: 11px;
    font-weight: 500;
    color: #64748b;
    display: inline-flex;
    align-items: center;
    gap: 5px;
}

@media (max-width: 600px) {
    .wc-stripe-onboarding-footer {
        flex-direction: column;
        align-items: flex-start;
        padding: 12px 20px;
    }
}
`;

['build/upe-settings.css', 'build/upe-settings-rtl.css'].forEach(filePath => {
    let css = fs.readFileSync(filePath, 'utf8');
    // Remove previous onboarding rules if present
    const start = css.indexOf('/* ==========================================================================\n   ENHANCED ONBOARDING') !== -1 
        ? css.indexOf('/* ==========================================================================\n   ENHANCED ONBOARDING')
        : css.indexOf('/* ==========================================================================\n   COMPACT ONBOARDING');
    if (start !== -1) {
        css = css.substring(0, start);
    }
    css += '\n' + onboardingCss;
    fs.writeFileSync(filePath, css, 'utf8');
    console.log('Updated compact onboarding CSS in', filePath);
});
