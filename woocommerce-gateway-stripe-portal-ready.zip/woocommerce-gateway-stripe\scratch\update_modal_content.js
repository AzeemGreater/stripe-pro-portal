const fs = require('fs');

const jsPath = 'build/upe-settings.js';
let jsContent = fs.readFileSync(jsPath, 'utf8');

const targetStr = '(0,y.createElement)("p",null,(0,He.__)("Connect or create a Stripe account to accept all major debit and credit cards, digital wallets (including Apple Pay and Google Pay), buy now, pay later options (such as Klarna and Affirm), and a wide range of local and international payment methods.","woocommerce-gateway-stripe")),(0,y.createElement)("p",{className:"woocommerce-stripe-auth__help"},(e=>We({mixedString:e?(0,He.__)(\'By clicking "Connect a test account", you agree to the {{tosLink}}Terms of service.{{/tosLink}}\',"woocommerce-gateway-stripe"):(0,He.__)(\'By clicking "Connect an account", you agree to the {{tosLink}}Terms of service.{{/tosLink}}\',"woocommerce-gateway-stripe"),components:{tosLink:(0,y.createElement)("a",{target:"_blank",rel:"noreferrer",href:"https://wordpress.com/tos"})}}))(e)),(0,y.createElement)("p",{className:"woocommerce-stripe-auth__help"},(0,He.__)("Some payment methods are automatically enabled when you connect your account. Review your Payment Methods settings for details.","woocommerce-gateway-stripe"))';

const replacementStr = '(0,y.createElement)("p",{className:"woocommerce-stripe-auth__summary"},(e=>We({mixedString:(0,He.__)("Connect or create your Stripe account to securely accept cards, digital wallets, and local payment methods. By connecting, you agree to the {{tosLink}}Terms of service{{/tosLink}}. Enabled payment methods can be customized in settings at any time.","woocommerce-gateway-stripe"),components:{tosLink:(0,y.createElement)("a",{target:"_blank",rel:"noreferrer",href:"https://wordpress.com/tos"})}}))(e))';

if (jsContent.includes(targetStr)) {
    jsContent = jsContent.replace(targetStr, replacementStr);
    fs.writeFileSync(jsPath, jsContent, 'utf8');
    console.log('Successfully updated modal paragraph in build/upe-settings.js');
} else {
    console.log('Target paragraph string not found in build/upe-settings.js');
}
