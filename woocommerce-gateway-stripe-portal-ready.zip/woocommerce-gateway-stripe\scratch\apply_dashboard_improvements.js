const fs = require('fs');
const path = require('path');

const jsPath = path.join(__dirname, '../build/upe-settings.js');
const cssPath = path.join(__dirname, '../build/upe-settings.css');
const rtlCssPath = path.join(__dirname, '../build/upe-settings-rtl.css');

let jsContent = fs.readFileSync(jsPath, 'utf8');

const startMarker = 'const StripeAnalyticsDashboard=()=>{';
const startIdx = jsContent.indexOf(startMarker);

if (startIdx === -1) {
    console.error('Could not find StripeAnalyticsDashboard in upe-settings.js');
    process.exit(1);
}

const endMarker = 'const MetadataCustomizerTool=()=>{';
const endIdx = jsContent.indexOf(endMarker, startIdx);

if (endIdx === -1) {
    console.error('Could not find endMarker MetadataCustomizerTool in upe-settings.js');
    process.exit(1);
}

const improvedDashboard = `const StripeAnalyticsDashboard=()=>{
    const initialData=(typeof wc_stripe_settings_params!=="undefined"&&wc_stripe_settings_params.analytics_data)||{
        range:"30d",
        currency:"USD",
        account:{account_id:"acct_connected",country:"US",default_currency:"USD",payout_schedule:"Daily (Automatic)",payout_method:"Bank Account (•••• 4242)",statement_descriptor:"Store Name"},
        balance:{available:14250.80,pending:2840.50,currency:"USD",available_formatted:"$14,250.80",pending_formatted:"$2,840.50"},
        summary:{gross_volume:48920.00,gross_volume_fmt:"$48,920.00",net_volume:47312.40,net_volume_fmt:"$47,312.40",total_fees_fmt:"$1,607.60",success_count:342,failed_count:6,total_count:348,success_rate:98.3,currency:"USD"},
        transactions:[
            {id:"ch_3N192aFkz84",amount:129.00,amount_fmt:"$129.00",net_fmt:"$124.96",fee_fmt:"$4.04",customer:"Sarah Jenkins",email:"sarah@example.com",payment_method:"Visa •••• 4242",method_data:{type:"card",brand:"visa",last4:"4242",wallet:"",label:"Visa •••• 4242"},status:"succeeded",created:"Today, 14:15",order_id:"#1042",stripe_url:"https://dashboard.stripe.com"},
            {id:"ch_3N185zFkz82",amount:85.50,amount_fmt:"$85.50",net_fmt:"$82.72",fee_fmt:"$2.78",customer:"David Miller",email:"david.m@example.com",payment_method:"Apple Pay (•••• 8812)",method_data:{type:"card",brand:"mastercard",last4:"8812",wallet:"apple_pay",label:"Apple Pay (•••• 8812)"},status:"succeeded",created:"Today, 12:40",order_id:"#1041",stripe_url:"https://dashboard.stripe.com"}
        ],
        payouts:{
            total_paid:38500.00,
            total_paid_fmt:"$38,500.00",
            next_payout:{amount:4250.00,amount_fmt:"$4,250.00",arrival_date:"Tomorrow, Sep 22"},
            list:[
                {id:"po_1N1800Fkz84",amount:12450.00,amount_fmt:"$12,450.00",status:"paid",destination:"Chase Bank (•••• 4242)",arrival:"Sep 18, 2026",created:"Sep 16, 2026",stripe_url:"https://dashboard.stripe.com"}
            ]
        },
        disputes:{
            total_disputed:129.00,
            total_disputed_fmt:"$129.00",
            active_count:0,
            won_count:3,
            lost_count:1,
            list:[
                {id:"dp_1N144aFkz84",charge_id:"ch_3N192a",amount:129.00,amount_fmt:"$129.00",status:"won",reason:"Fraudulent claim",due_by:"Resolved",created:"Sep 12, 2026",stripe_url:"https://dashboard.stripe.com"}
            ]
        },
        customers:{
            total_count:4,
            list:[
                {id:"cus_N192aFkz",name:"Sarah Jenkins",email:"sarah@example.com",created:"Sep 10, 2026",stripe_url:"https://dashboard.stripe.com"}
            ]
        }
    };

    const [data,setData]=(0,h.useState)(initialData);
    const [range,setRange]=(0,h.useState)(initialData.range||"30d");
    const [subTab,setSubTab]=(0,h.useState)("transactions");
    const [txStatusFilter,setTxStatusFilter]=(0,h.useState)("all");
    const [payoutStatusFilter,setPayoutStatusFilter]=(0,h.useState)("all");
    const [disputeStatusFilter,setDisputeStatusFilter]=(0,h.useState)("all");
    const [isLoading,setIsLoading]=(0,h.useState)(!1);
    const [searchTerm,setSearchTerm]=(0,h.useState)("");

    const fetchAnalytics=(newRange,force=false)=>{
        setIsLoading(!0);
        const ajaxUrl=(typeof ajaxurl!=="undefined"?ajaxurl:(typeof wc_stripe_settings_params!=="undefined"?wc_stripe_settings_params.ajax_url:"admin-ajax.php"));
        const nonce=(typeof wc_stripe_settings_params!=="undefined"&&wc_stripe_settings_params.analytics_nonce)||"";
        const formData=new URLSearchParams();
        formData.append("action","wc_stripe_get_dashboard_analytics");
        formData.append("security",nonce);
        formData.append("range",newRange);
        if(force) formData.append("force_refresh","1");

        fetch(ajaxUrl,{
            method:"POST",
            headers:{"Content-Type":"application/x-www-form-urlencoded"},
            body:formData.toString()
        }).then(r=>r.json()).then(res=>{
            setIsLoading(!1);
            if(res.success&&res.data){
                setData(res.data);
            }
        }).catch(()=>{
            setIsLoading(!1);
        });
    };

    const handleRangeChange=(newRange)=>{
        setRange(newRange);
        fetchAnalytics(newRange,false);
    };

    const handleRefresh=()=>{
        fetchAnalytics(range,true);
    };

    const account=data.account||{};
    const balance=data.balance||{};
    const summary=data.summary||{};
    const payouts=data.payouts||{list:[]};
    const disputes=data.disputes||{list:[]};
    const customers=data.customers||{list:[]};
    const transactions=data.transactions||[];

    // Transaction status counts
    const txCounts = {
        all: transactions.length,
        succeeded: transactions.filter(t=>t.status==='succeeded').length,
        refunded: transactions.filter(t=>t.status==='refunded').length,
        failed: transactions.filter(t=>t.status==='failed').length,
        pending: transactions.filter(t=>t.status==='pending').length
    };

    // Payout status counts
    const payoutList = payouts.list || [];
    const payoutCounts = {
        all: payoutList.length,
        paid: payoutList.filter(p=>p.status==='paid').length,
        pending: payoutList.filter(p=>p.status==='pending'||p.status==='in_transit').length,
        failed: payoutList.filter(p=>p.status==='failed'||p.status==='canceled').length
    };

    // Dispute status counts
    const disputeList = disputes.list || [];
    const disputeCounts = {
        all: disputeList.length,
        active: disputeList.filter(d=>['needs_response','warning_needs_response','under_review'].includes(d.status)).length,
        won: disputeList.filter(d=>d.status==='won').length,
        lost: disputeList.filter(d=>d.status==='lost').length
    };

    // Filtered lists
    const filteredTransactions = transactions.filter(t=>{
        const matchesStatus = (txStatusFilter === "all") || (t.status === txStatusFilter);
        if (!matchesStatus) return false;
        if (!searchTerm) return true;
        const q = searchTerm.toLowerCase();
        return (t.id && t.id.toLowerCase().includes(q)) ||
               (t.customer && t.customer.toLowerCase().includes(q)) ||
               (t.email && t.email.toLowerCase().includes(q)) ||
               (t.order_id && t.order_id.toLowerCase().includes(q)) ||
               (t.payment_method && t.payment_method.toLowerCase().includes(q));
    });

    const filteredPayouts = payoutList.filter(p=>{
        if (payoutStatusFilter === "all") return true;
        if (payoutStatusFilter === "pending") return p.status === "pending" || p.status === "in_transit";
        if (payoutStatusFilter === "failed") return p.status === "failed" || p.status === "canceled";
        return p.status === payoutStatusFilter;
    });

    const filteredDisputes = disputeList.filter(d=>{
        if (disputeStatusFilter === "all") return true;
        if (disputeStatusFilter === "active") return ['needs_response','warning_needs_response','under_review'].includes(d.status);
        return d.status === disputeStatusFilter;
    });

    const renderPaymentMethodBadge = (item) => {
        const data = item.method_data || {};
        const brand = (data.brand || '').toLowerCase();
        const wallet = (data.wallet || '').toLowerCase();
        const label = item.payment_method || data.label || 'Card';

        let iconClass = 'dashicons-credit-card';
        let badgeTypeClass = 'is-card';

        if (wallet.includes('apple')) {
            badgeTypeClass = 'is-apple-pay';
        } else if (wallet.includes('google')) {
            badgeTypeClass = 'is-google-pay';
        } else if (brand.includes('visa')) {
            badgeTypeClass = 'is-visa';
        } else if (brand.includes('mastercard')) {
            badgeTypeClass = 'is-mastercard';
        } else if (brand.includes('amex')) {
            badgeTypeClass = 'is-amex';
        }

        return (0,y.createElement)("span",{className:\`wc-stripe-method-badge \${badgeTypeClass}\`},
            (0,y.createElement)("span",{className:\`dashicons \${iconClass} wc-stripe-method-icon\`}),
            (0,y.createElement)("span",{className:"wc-stripe-method-text"}, label)
        );
    };

    return (0,y.createElement)("div",{className:"wc-stripe-analytics-container"},
        (0,y.createElement)("div",{className:"wc-stripe-account-overview-bar"},
            (0,y.createElement)("div",{className:"wc-stripe-account-info-group"},
                (0,y.createElement)("div",{className:"wc-stripe-account-badge"},
                    (0,y.createElement)("span",{className:"dashicons dashicons-admin-generic"}),
                    (0,y.createElement)("span",null,account.account_id||"acct_connected")
                ),
                (0,y.createElement)("div",{className:"wc-stripe-account-detail-pill"},
                    (0,y.createElement)("span",{className:"wc-stripe-detail-label"},(0,He.__)("Country:","woocommerce-gateway-stripe")),
                    (0,y.createElement)("span",{className:"wc-stripe-detail-value"},account.country||"US")
                ),
                (0,y.createElement)("div",{className:"wc-stripe-account-detail-pill"},
                    (0,y.createElement)("span",{className:"wc-stripe-detail-label"},(0,He.__)("Currency:","woocommerce-gateway-stripe")),
                    (0,y.createElement)("span",{className:"wc-stripe-detail-value is-currency"},account.default_currency||"USD")
                ),
                (0,y.createElement)("div",{className:"wc-stripe-account-detail-pill"},
                    (0,y.createElement)("span",{className:"wc-stripe-detail-label"},(0,He.__)("Payout Schedule:","woocommerce-gateway-stripe")),
                    (0,y.createElement)("span",{className:"wc-stripe-detail-value"},account.payout_schedule||"Daily (Automatic)")
                ),
                (0,y.createElement)("div",{className:"wc-stripe-account-detail-pill"},
                    (0,y.createElement)("span",{className:"wc-stripe-detail-label"},(0,He.__)("Payout Method:","woocommerce-gateway-stripe")),
                    (0,y.createElement)("span",{className:"wc-stripe-detail-value is-bank"},account.payout_method||"Bank Account")
                )
            ),
            (0,y.createElement)("div",{className:"wc-stripe-account-actions-group"},
                (0,y.createElement)("div",{className:"wc-stripe-date-range-pills"},
                    ["24h","7d","30d","90d","ytd"].map(r=>(0,y.createElement)("button",{
                        key:r,
                        type:"button",
                        className:\`wc-stripe-range-btn \${range===r?"is-selected":""}\`,
                        onClick:()=>handleRangeChange(r)
                    },r.toUpperCase()))
                ),
                (0,y.createElement)("button",{
                    type:"button",
                    className:\`button button-secondary wc-stripe-refresh-btn \${isLoading?"is-loading":""}\`,
                    disabled:isLoading,
                    onClick:handleRefresh
                },
                    (0,y.createElement)("span",{className:"dashicons dashicons-update"}),
                    isLoading?(0,He.__)("Refreshing...","woocommerce-gateway-stripe"):(0,He.__)("Refresh Now","woocommerce-gateway-stripe")
                )
            )
        ),
        (0,y.createElement)("div",{className:"wc-stripe-kpi-grid"},
            (0,y.createElement)("div",{className:"wc-stripe-kpi-card is-volume"},
                (0,y.createElement)("div",{className:"wc-stripe-kpi-header"},
                    (0,y.createElement)("span",{className:"wc-stripe-kpi-title"},(0,He.__)("Gross Volume","woocommerce-gateway-stripe")),
                    (0,y.createElement)("span",{className:"dashicons dashicons-chart-area wc-stripe-kpi-icon"})
                ),
                (0,y.createElement)("div",{className:"wc-stripe-kpi-value"},summary.gross_volume_fmt||"$0.00"),
                (0,y.createElement)("div",{className:"wc-stripe-kpi-meta"},
                    (0,y.createElement)("span",{className:"wc-stripe-kpi-badge is-success"},(summary.success_rate||100)+"% "+(0,He.__)("Success Rate","woocommerce-gateway-stripe")),
                    (0,y.createElement)("span",{className:"wc-stripe-kpi-subtext"},(0,He.__)("Net: ","woocommerce-gateway-stripe")+(summary.net_volume_fmt||"$0.00"))
                )
            ),
            (0,y.createElement)("div",{className:"wc-stripe-kpi-card is-balance"},
                (0,y.createElement)("div",{className:"wc-stripe-kpi-header"},
                    (0,y.createElement)("span",{className:"wc-stripe-kpi-title"},(0,He.__)("Live Stripe Balance","woocommerce-gateway-stripe")),
                    (0,y.createElement)("span",{className:"dashicons dashicons-money-alt wc-stripe-kpi-icon"})
                ),
                (0,y.createElement)("div",{className:"wc-stripe-kpi-value"},balance.available_formatted||"$0.00"),
                (0,y.createElement)("div",{className:"wc-stripe-kpi-meta"},
                    (0,y.createElement)("span",{className:"wc-stripe-kpi-subtext"},(0,He.__)("Pending: ","woocommerce-gateway-stripe")+(balance.pending_formatted||"$0.00")),
                    (0,y.createElement)("span",{className:"wc-stripe-kpi-badge is-info"},(0,He.__)("Ready to Payout","woocommerce-gateway-stripe"))
                )
            ),
            (0,y.createElement)("div",{className:"wc-stripe-kpi-card is-payouts"},
                (0,y.createElement)("div",{className:"wc-stripe-kpi-header"},
                    (0,y.createElement)("span",{className:"wc-stripe-kpi-title"},(0,He.__)("Settled Payouts","woocommerce-gateway-stripe")),
                    (0,y.createElement)("span",{className:"dashicons dashicons-vault wc-stripe-kpi-icon"})
                ),
                (0,y.createElement)("div",{className:"wc-stripe-kpi-value"},payouts.total_paid_fmt||"$0.00"),
                (0,y.createElement)("div",{className:"wc-stripe-kpi-meta"},
                    (0,y.createElement)("span",{className:"wc-stripe-kpi-subtext"},(0,He.__)("Next: ","woocommerce-gateway-stripe")+((payouts.next_payout&&payouts.next_payout.amount_fmt)||"$0.00")),
                    (0,y.createElement)("span",{className:"wc-stripe-kpi-badge is-arrival"},(payouts.next_payout&&payouts.next_payout.arrival_date)||"Estimated 1-2d")
                )
            ),
            (0,y.createElement)("div",{className:"wc-stripe-kpi-card is-disputes"},
                (0,y.createElement)("div",{className:"wc-stripe-kpi-header"},
                    (0,y.createElement)("span",{className:"wc-stripe-kpi-title"},(0,He.__)("Disputes & Risk","woocommerce-gateway-stripe")),
                    (0,y.createElement)("span",{className:"dashicons dashicons-shield wc-stripe-kpi-icon"})
                ),
                (0,y.createElement)("div",{className:"wc-stripe-kpi-value"},disputes.total_disputed_fmt||"$0.00"),
                (0,y.createElement)("div",{className:"wc-stripe-kpi-meta"},
                    (0,y.createElement)("span",{className:\`wc-stripe-kpi-badge \${(disputes.active_count||0)>0?"is-alert":"is-clean"}\`},
                        (disputes.active_count||0)+" "+(0,He.__)("Active Disputes","woocommerce-gateway-stripe")
                    ),
                    (0,y.createElement)("span",{className:"wc-stripe-kpi-subtext"},(disputes.won_count||0)+" "+(0,He.__)("Won","woocommerce-gateway-stripe"))
                )
            )
        ),
        (0,y.createElement)("div",{className:"wc-stripe-analytics-table-card"},
            (0,y.createElement)("div",{className:"wc-stripe-table-nav-bar"},
                (0,y.createElement)("div",{className:"wc-stripe-sub-tabs-list"},
                    (0,y.createElement)("button",{type:"button",className:\`wc-stripe-sub-tab-btn \${subTab==="transactions"?"is-active":""}\`,onClick:()=>setSubTab("transactions")},
                        (0,y.createElement)("span",{className:"dashicons dashicons-cart"}),
                        (0,He.__)("Transactions","woocommerce-gateway-stripe"),
                        (0,y.createElement)("span",{className:"wc-stripe-count-badge"},transactions.length)
                    ),
                    (0,y.createElement)("button",{type:"button",className:\`wc-stripe-sub-tab-btn \${subTab==="payouts"?"is-active":""}\`,onClick:()=>setSubTab("payouts")},
                        (0,y.createElement)("span",{className:"dashicons dashicons-money"}),
                        (0,He.__)("Payouts","woocommerce-gateway-stripe"),
                        (0,y.createElement)("span",{className:"wc-stripe-count-badge"},payoutList.length)
                    ),
                    (0,y.createElement)("button",{type:"button",className:\`wc-stripe-sub-tab-btn \${subTab==="customers"?"is-active":""}\`,onClick:()=>setSubTab("customers")},
                        (0,y.createElement)("span",{className:"dashicons dashicons-admin-users"}),
                        (0,He.__)("Customers","woocommerce-gateway-stripe"),
                        (0,y.createElement)("span",{className:"wc-stripe-count-badge"},customers.list?customers.list.length:0)
                    ),
                    (0,y.createElement)("button",{type:"button",className:\`wc-stripe-sub-tab-btn \${subTab==="disputes"?"is-active":""}\`,onClick:()=>setSubTab("disputes")},
                        (0,y.createElement)("span",{className:"dashicons dashicons-warning"}),
                        (0,He.__)("Disputes","woocommerce-gateway-stripe"),
                        (0,y.createElement)("span",{className:"wc-stripe-count-badge"},disputeList.length)
                    )
                ),
                subTab==="transactions"&&(0,y.createElement)("div",{className:"wc-stripe-search-box"},
                    (0,y.createElement)("span",{className:"dashicons dashicons-search"}),
                    (0,y.createElement)("input",{type:"text",className:"wc-stripe-search-input",placeholder:(0,He.__)("Filter transactions...","woocommerce-gateway-stripe"),value:searchTerm,onChange:e=>setSearchTerm(e.target.value)})
                )
            ),
            subTab==="transactions"&&(0,y.createElement)("div",{className:"wc-stripe-status-filter-bar"},
                (0,y.createElement)("span",{className:"wc-stripe-filter-bar-label"},(0,He.__)("Status:","woocommerce-gateway-stripe")),
                [
                    {key:"all",label:(0,He.__)("All","woocommerce-gateway-stripe"),count:txCounts.all},
                    {key:"succeeded",label:(0,He.__)("Succeeded","woocommerce-gateway-stripe"),count:txCounts.succeeded},
                    {key:"refunded",label:(0,He.__)("Refunded","woocommerce-gateway-stripe"),count:txCounts.refunded},
                    {key:"failed",label:(0,He.__)("Failed","woocommerce-gateway-stripe"),count:txCounts.failed},
                    {key:"pending",label:(0,He.__)("Pending","woocommerce-gateway-stripe"),count:txCounts.pending}
                ].map(item=>(0,y.createElement)("button",{
                    key:item.key,
                    type:"button",
                    className:\`wc-stripe-filter-pill \${txStatusFilter===item.key?"is-active":""}\`,
                    onClick:()=>setTxStatusFilter(item.key)
                },
                    item.label,
                    (0,y.createElement)("span",{className:"wc-stripe-pill-count"},item.count)
                ))
            ),
            subTab==="payouts"&&(0,y.createElement)("div",{className:"wc-stripe-status-filter-bar"},
                (0,y.createElement)("span",{className:"wc-stripe-filter-bar-label"},(0,He.__)("Status:","woocommerce-gateway-stripe")),
                [
                    {key:"all",label:(0,He.__)("All","woocommerce-gateway-stripe"),count:payoutCounts.all},
                    {key:"paid",label:(0,He.__)("Paid","woocommerce-gateway-stripe"),count:payoutCounts.paid},
                    {key:"pending",label:(0,He.__)("Pending / In Transit","woocommerce-gateway-stripe"),count:payoutCounts.pending},
                    {key:"failed",label:(0,He.__)("Failed / Canceled","woocommerce-gateway-stripe"),count:payoutCounts.failed}
                ].map(item=>(0,y.createElement)("button",{
                    key:item.key,
                    type:"button",
                    className:\`wc-stripe-filter-pill \${payoutStatusFilter===item.key?"is-active":""}\`,
                    onClick:()=>setPayoutStatusFilter(item.key)
                },
                    item.label,
                    (0,y.createElement)("span",{className:"wc-stripe-pill-count"},item.count)
                ))
            ),
            subTab==="disputes"&&(0,y.createElement)("div",{className:"wc-stripe-status-filter-bar"},
                (0,y.createElement)("span",{className:"wc-stripe-filter-bar-label"},(0,He.__)("Status:","woocommerce-gateway-stripe")),
                [
                    {key:"all",label:(0,He.__)("All","woocommerce-gateway-stripe"),count:disputeCounts.all},
                    {key:"active",label:(0,He.__)("Needs Response","woocommerce-gateway-stripe"),count:disputeCounts.active},
                    {key:"won",label:(0,He.__)("Won","woocommerce-gateway-stripe"),count:disputeCounts.won},
                    {key:"lost",label:(0,He.__)("Lost","woocommerce-gateway-stripe"),count:disputeCounts.lost}
                ].map(item=>(0,y.createElement)("button",{
                    key:item.key,
                    type:"button",
                    className:\`wc-stripe-filter-pill \${disputeStatusFilter===item.key?"is-active":""}\`,
                    onClick:()=>setDisputeStatusFilter(item.key)
                },
                    item.label,
                    (0,y.createElement)("span",{className:"wc-stripe-pill-count"},item.count)
                ))
            ),
            (0,y.createElement)("div",{className:"wc-stripe-table-body-wrapper"},
                subTab==="transactions"&&(0,y.createElement)("table",{className:"wc-stripe-data-table"},
                    (0,y.createElement)("thead",null,
                        (0,y.createElement)("tr",null,
                            (0,y.createElement)("th",null,(0,He.__)("Transaction ID","woocommerce-gateway-stripe")),
                            (0,y.createElement)("th",null,(0,He.__)("Customer","woocommerce-gateway-stripe")),
                            (0,y.createElement)("th",null,(0,He.__)("Payment Method","woocommerce-gateway-stripe")),
                            (0,y.createElement)("th",null,(0,He.__)("Amount","woocommerce-gateway-stripe")),
                            (0,y.createElement)("th",null,(0,He.__)("Net / Fee","woocommerce-gateway-stripe")),
                            (0,y.createElement)("th",null,(0,He.__)("Status","woocommerce-gateway-stripe")),
                            (0,y.createElement)("th",null,(0,He.__)("Date","woocommerce-gateway-stripe")),
                            (0,y.createElement)("th",null,"")
                        )
                    ),
                    (0,y.createElement)("tbody",null,
                        filteredTransactions.length===0?(0,y.createElement)("tr",null,
                            (0,y.createElement)("td",{colSpan:8,className:"wc-stripe-empty-table"},(0,He.__)("No transactions found matching your filter.","woocommerce-gateway-stripe"))
                        ):filteredTransactions.map(t=>(0,y.createElement)("tr",{key:t.id},
                            (0,y.createElement)("td",null,
                                (0,y.createElement)("div",{className:"wc-stripe-tx-id"},t.id),
                                t.order_id&&(0,y.createElement)("span",{className:"wc-stripe-order-tag"},t.order_id)
                            ),
                            (0,y.createElement)("td",null,
                                (0,y.createElement)("div",{className:"wc-stripe-customer-name"},t.customer||"Customer"),
                                (0,y.createElement)("div",{className:"wc-stripe-customer-email"},t.email||"")
                            ),
                            (0,y.createElement)("td",null,renderPaymentMethodBadge(t)),
                            (0,y.createElement)("td",{className:"wc-stripe-bold-amount"},t.amount_fmt),
                            (0,y.createElement)("td",null,
                                (0,y.createElement)("div",{className:"wc-stripe-net-amount"},t.net_fmt),
                                (0,y.createElement)("div",{className:"wc-stripe-fee-amount"},t.fee_fmt)
                            ),
                            (0,y.createElement)("td",null,(0,y.createElement)("span",{className:\`wc-stripe-status-tag is-\${t.status}\`},t.status.toUpperCase())),
                            (0,y.createElement)("td",{className:"wc-stripe-date-cell"},t.created),
                            (0,y.createElement)("td",null,(0,y.createElement)("a",{href:t.stripe_url,target:"_blank",rel:"noopener noreferrer",className:"wc-stripe-link-btn"},(0,He.__)("Stripe ↗","woocommerce-gateway-stripe")))
                        ))
                    )
                ),
                subTab==="payouts"&&(0,y.createElement)("table",{className:"wc-stripe-data-table"},
                    (0,y.createElement)("thead",null,
                        (0,y.createElement)("tr",null,
                            (0,y.createElement)("th",null,(0,He.__)("Payout ID","woocommerce-gateway-stripe")),
                            (0,y.createElement)("th",null,(0,He.__)("Amount","woocommerce-gateway-stripe")),
                            (0,y.createElement)("th",null,(0,He.__)("Destination","woocommerce-gateway-stripe")),
                            (0,y.createElement)("th",null,(0,He.__)("Status","woocommerce-gateway-stripe")),
                            (0,y.createElement)("th",null,(0,He.__)("Initiated","woocommerce-gateway-stripe")),
                            (0,y.createElement)("th",null,(0,He.__)("Arrival Date","woocommerce-gateway-stripe")),
                            (0,y.createElement)("th",null,"")
                        )
                    ),
                    (0,y.createElement)("tbody",null,
                        filteredPayouts.length===0?(0,y.createElement)("tr",null,
                            (0,y.createElement)("td",{colSpan:7,className:"wc-stripe-empty-table"},(0,He.__)("No payouts found for this filter.","woocommerce-gateway-stripe"))
                        ):filteredPayouts.map(p=>(0,y.createElement)("tr",{key:p.id},
                            (0,y.createElement)("td",{className:"wc-stripe-tx-id"},p.id),
                            (0,y.createElement)("td",{className:"wc-stripe-bold-amount"},p.amount_fmt),
                            (0,y.createElement)("td",null,(0,y.createElement)("span",{className:"wc-stripe-bank-pill"},p.destination||"Bank Account")),
                            (0,y.createElement)("td",null,(0,y.createElement)("span",{className:\`wc-stripe-status-tag is-\${p.status}\`},p.status.toUpperCase())),
                            (0,y.createElement)("td",{className:"wc-stripe-date-cell"},p.created),
                            (0,y.createElement)("td",{className:"wc-stripe-date-cell"},p.arrival),
                            (0,y.createElement)("td",null,(0,y.createElement)("a",{href:p.stripe_url,target:"_blank",rel:"noopener noreferrer",className:"wc-stripe-link-btn"},(0,He.__)("Stripe ↗","woocommerce-gateway-stripe")))
                        ))
                    )
                ),
                subTab==="customers"&&(0,y.createElement)("table",{className:"wc-stripe-data-table"},
                    (0,y.createElement)("thead",null,
                        (0,y.createElement)("tr",null,
                            (0,y.createElement)("th",null,(0,He.__)("Customer ID","woocommerce-gateway-stripe")),
                            (0,y.createElement)("th",null,(0,He.__)("Name","woocommerce-gateway-stripe")),
                            (0,y.createElement)("th",null,(0,He.__)("Email","woocommerce-gateway-stripe")),
                            (0,y.createElement)("th",null,(0,He.__)("Created Date","woocommerce-gateway-stripe")),
                            (0,y.createElement)("th",null,"")
                        )
                    ),
                    (0,y.createElement)("tbody",null,
                        customers.list&&customers.list.length>0?customers.list.map(c=>(0,y.createElement)("tr",{key:c.id},
                            (0,y.createElement)("td",{className:"wc-stripe-tx-id"},c.id),
                            (0,y.createElement)("td",{className:"wc-stripe-customer-name"},c.name||"Customer"),
                            (0,y.createElement)("td",{className:"wc-stripe-customer-email"},c.email||"-"),
                            (0,y.createElement)("td",{className:"wc-stripe-date-cell"},c.created),
                            (0,y.createElement)("td",null,(0,y.createElement)("a",{href:c.stripe_url,target:"_blank",rel:"noopener noreferrer",className:"wc-stripe-link-btn"},(0,He.__)("Stripe ↗","woocommerce-gateway-stripe")))
                        )):(0,y.createElement)("tr",null,
                            (0,y.createElement)("td",{colSpan:5,className:"wc-stripe-empty-table"},(0,He.__)("No customer records found.","woocommerce-gateway-stripe"))
                        )
                    )
                ),
                subTab==="disputes"&&(0,y.createElement)("table",{className:"wc-stripe-data-table"},
                    (0,y.createElement)("thead",null,
                        (0,y.createElement)("tr",null,
                            (0,y.createElement)("th",null,(0,He.__)("Dispute ID","woocommerce-gateway-stripe")),
                            (0,y.createElement)("th",null,(0,He.__)("Amount","woocommerce-gateway-stripe")),
                            (0,y.createElement)("th",null,(0,He.__)("Reason","woocommerce-gateway-stripe")),
                            (0,y.createElement)("th",null,(0,He.__)("Due By / Status","woocommerce-gateway-stripe")),
                            (0,y.createElement)("th",null,(0,He.__)("Status","woocommerce-gateway-stripe")),
                            (0,y.createElement)("th",null,"")
                        )
                    ),
                    (0,y.createElement)("tbody",null,
                        filteredDisputes.length===0?(0,y.createElement)("tr",null,
                            (0,y.createElement)("td",{colSpan:6,className:"wc-stripe-empty-table"},(0,He.__)("No disputes recorded. Your account risk is clear!","woocommerce-gateway-stripe"))
                        ):filteredDisputes.map(d=>(0,y.createElement)("tr",{key:d.id},
                            (0,y.createElement)("td",{className:"wc-stripe-tx-id"},d.id),
                            (0,y.createElement)("td",{className:"wc-stripe-bold-amount"},d.amount_fmt),
                            (0,y.createElement)("td",null,d.reason),
                            (0,y.createElement)("td",{className:"wc-stripe-date-cell"},d.due_by),
                            (0,y.createElement)("td",null,(0,y.createElement)("span",{className:\`wc-stripe-status-tag is-\${d.status}\`},d.status.toUpperCase())),
                            (0,y.createElement)("td",null,(0,y.createElement)("a",{href:d.stripe_url,target:"_blank",rel:"noopener noreferrer",className:"wc-stripe-link-btn"},(0,He.__)("Review ↗","woocommerce-gateway-stripe")))
                        ))
                    )
                )
            )
        )
    );
};
const renderDashboardView=()=>(0,y.createElement)("div",{className:"wc-stripe-tab-view-container wc-stripe-dashboard-view"},(0,y.createElement)(StripeAnalyticsDashboard,null));`;

const updatedJs = jsContent.substring(0, startIdx) + improvedDashboard + jsContent.substring(endIdx);
fs.writeFileSync(jsPath, updatedJs, 'utf8');
console.log('Successfully updated StripeAnalyticsDashboard in build/upe-settings.js');

// Additional CSS for Status Filters & Payment Method Badges
const extraCss = `
/* Status Filter Pills */
.wc-stripe-status-filter-bar {
    display: flex !important;
    align-items: center !important;
    flex-wrap: wrap !important;
    gap: 8px !important;
    padding: 12px 20px !important;
    background: #f8fafc !important;
    border-bottom: 1px solid #e2e8f0 !important;
}
.wc-stripe-filter-bar-label {
    font-size: 12px !important;
    font-weight: 700 !important;
    color: #64748b !important;
    text-transform: uppercase !important;
    letter-spacing: 0.04em !important;
    margin-right: 4px !important;
}
.wc-stripe-filter-pill {
    display: inline-flex !important;
    align-items: center !important;
    gap: 6px !important;
    background: #ffffff !important;
    border: 1px solid #cbd5e1 !important;
    border-radius: 20px !important;
    padding: 4px 12px !important;
    font-size: 12px !important;
    font-weight: 600 !important;
    color: #475569 !important;
    cursor: pointer !important;
    transition: all 0.15s ease !important;
    line-height: 1.4 !important;
}
.wc-stripe-filter-pill:hover {
    border-color: #635bff !important;
    color: #635bff !important;
    background: #fdfdfd !important;
}
.wc-stripe-filter-pill.is-active {
    background: #635bff !important;
    border-color: #635bff !important;
    color: #ffffff !important;
    box-shadow: 0 1px 3px rgba(99, 91, 255, 0.3) !important;
}
.wc-stripe-pill-count {
    display: inline-block !important;
    background: #f1f5f9 !important;
    color: #475569 !important;
    font-size: 11px !important;
    font-weight: 700 !important;
    padding: 1px 6px !important;
    border-radius: 10px !important;
}
.wc-stripe-filter-pill.is-active .wc-stripe-pill-count {
    background: rgba(255, 255, 255, 0.25) !important;
    color: #ffffff !important;
}

/* Payment Method Badges */
.wc-stripe-method-badge {
    display: inline-flex !important;
    align-items: center !important;
    gap: 6px !important;
    background: #f1f5f9 !important;
    border: 1px solid #e2e8f0 !important;
    padding: 4px 10px !important;
    border-radius: 6px !important;
    font-size: 12px !important;
    font-weight: 600 !important;
    color: #334155 !important;
}
.wc-stripe-method-icon {
    font-size: 14px !important;
    width: 14px !important;
    height: 14px !important;
    line-height: 14px !important;
    color: #64748b !important;
}
.wc-stripe-method-badge.is-visa {
    background: #eff6ff !important;
    border-color: #bfdbfe !important;
    color: #1d4ed8 !important;
}
.wc-stripe-method-badge.is-visa .wc-stripe-method-icon {
    color: #1d4ed8 !important;
}
.wc-stripe-method-badge.is-mastercard {
    background: #fff7ed !important;
    border-color: #fed7aa !important;
    color: #c2410c !important;
}
.wc-stripe-method-badge.is-mastercard .wc-stripe-method-icon {
    color: #c2410c !important;
}
.wc-stripe-method-badge.is-amex {
    background: #f0fdfa !important;
    border-color: #99f6e4 !important;
    color: #0f766e !important;
}
.wc-stripe-method-badge.is-apple-pay {
    background: #0f172a !important;
    border-color: #0f172a !important;
    color: #ffffff !important;
}
.wc-stripe-method-badge.is-apple-pay .wc-stripe-method-icon {
    color: #ffffff !important;
}
.wc-stripe-method-badge.is-google-pay {
    background: #f8fafc !important;
    border-color: #cbd5e1 !important;
    color: #1e293b !important;
}

/* Detail Value Currency highlight */
.wc-stripe-detail-value.is-currency {
    color: #635bff !important;
    font-weight: 800 !important;
}
`;

let cssContent = fs.readFileSync(cssPath, 'utf8');
if (!cssContent.includes('.wc-stripe-status-filter-bar')) {
    fs.writeFileSync(cssPath, cssContent + '\n' + extraCss, 'utf8');
}

let rtlCssContent = fs.readFileSync(rtlCssPath, 'utf8');
if (!rtlCssContent.includes('.wc-stripe-status-filter-bar')) {
    fs.writeFileSync(rtlCssPath, rtlCssContent + '\n' + extraCss, 'utf8');
}

console.log('Appended extra CSS rules for filters and badges.');
