const fs = require('fs');
const path = require('path');

const jsPath = path.join(__dirname, '../build/upe-settings.js');
const cssPath = path.join(__dirname, '../build/upe-settings.css');
const rtlCssPath = path.join(__dirname, '../build/upe-settings-rtl.css');

let jsContent = fs.readFileSync(jsPath, 'utf8');

// We want to replace renderAdvanceToolsView inside build/upe-settings.js with our full rich interactive tool component
const searchTarget = 'const renderAdvanceToolsView=()=>(0,y.createElement)("div",{className:"wc-stripe-tab-view-container wc-stripe-advance-tools-view"},';

if (!jsContent.includes(searchTarget)) {
    console.error('Target renderAdvanceToolsView not found in upe-settings.js');
    process.exit(1);
}

// Find the start and end of renderAdvanceToolsView
const startIdx = jsContent.indexOf('const renderAdvanceToolsView=');
const endMarker = 'return(0,y.createElement)("div",{className:"wc-stripe-unified-deck-layout"},(0,y.createElement)("div",{className:"wc-stripe-tab';
const endIdx = jsContent.indexOf(endMarker, startIdx);

if (startIdx === -1 || endIdx === -1) {
    console.error('Could not determine exact boundaries of renderAdvanceToolsView');
    process.exit(1);
}

const replacementComponent = `const MetadataCustomizerTool=()=>{
    const initialMeta=(typeof wc_stripe_settings_params!=="undefined"&&wc_stripe_settings_params.metadata_customizer_settings)||{enabled:"no",site_url:"hidden",store_name:"BEKAPAINT LIMITED",order_description_template:"{store_name} - order {order_number}"};
    const [enabled,setEnabled]=(0,h.useState)(initialMeta.enabled==="yes"||initialMeta.enabled===true);
    const [siteUrl,setSiteUrl]=(0,h.useState)(initialMeta.site_url||"hidden");
    const [storeName,setStoreName]=(0,h.useState)(initialMeta.store_name||"BEKAPAINT LIMITED");
    const [descTemplate,setDescTemplate]=(0,h.useState)(initialMeta.order_description_template||"{store_name} - order {order_number}");
    const [isSaving,setIsSaving]=(0,h.useState)(!1);
    const [saveStatus,setSaveStatus]=(0,h.useState)("");
    const [saveMessage,setSaveMessage]=(0,h.useState)("");

    const insertTag=(tag)=>{
        setDescTemplate(prev=>prev?prev+" "+tag:tag);
    };

    const getFormattedPreviewDesc=()=>{
        let out=descTemplate||"";
        out=out.replace(/{store_name}/g,storeName||"Store Name");
        out=out.replace(/{order_number}/g,"1042");
        out=out.replace(/{customer_name}/g,"Sarah Jenkins");
        out=out.replace(/{order_date}/g,"2026-09-21");
        out=out.replace(/{order_total}/g,"$129.00");
        return out;
    };

    const handleSave=()=>{
        setIsSaving(!0);
        setSaveStatus("");
        const ajaxUrl=(typeof ajaxurl!=="undefined"?ajaxurl:(typeof wc_stripe_settings_params!=="undefined"?wc_stripe_settings_params.ajax_url:"admin-ajax.php"));
        const nonce=(typeof wc_stripe_settings_params!=="undefined"&&wc_stripe_settings_params.metadata_customizer_nonce)||"";
        const formData=new URLSearchParams();
        formData.append("action","wc_stripe_save_metadata_customizer_settings");
        formData.append("security",nonce);
        formData.append("enabled",enabled?"yes":"no");
        formData.append("site_url",siteUrl);
        formData.append("store_name",storeName);
        formData.append("order_description_template",descTemplate);

        fetch(ajaxUrl,{
            method:"POST",
            headers:{"Content-Type":"application/x-www-form-urlencoded"},
            body:formData.toString()
        }).then(r=>r.json()).then(res=>{
            setIsSaving(!1);
            if(res.success){
                setSaveStatus("success");
                setSaveMessage((0,He.__)("Settings saved successfully!","woocommerce-gateway-stripe"));
                setTimeout(()=>setSaveStatus(""),4000);
            }else{
                setSaveStatus("error");
                setSaveMessage((res.data&&res.data.message)||(0,He.__)("Failed to save settings.","woocommerce-gateway-stripe"));
            }
        }).catch(err=>{
            setIsSaving(!1);
            setSaveStatus("error");
            setSaveMessage((0,He.__)("Connection error while saving.","woocommerce-gateway-stripe"));
        });
    };

    return (0,y.createElement)("div",{className:"wc-stripe-customizer-card"},
        (0,y.createElement)("div",{className:"wc-stripe-customizer-header"},
            (0,y.createElement)("div",{className:"wc-stripe-customizer-header-left"},
                (0,y.createElement)("div",{className:"wc-stripe-customizer-icon-wrap"},
                    (0,y.createElement)("span",{className:"dashicons dashicons-shield-alt"})
                ),
                (0,y.createElement)("div",null,
                    (0,y.createElement)("h3",{className:"wc-stripe-customizer-title"},(0,He.__)("Stripe Metadata & Statement Customizer","woocommerce-gateway-stripe")),
                    (0,y.createElement)("p",{className:"wc-stripe-customizer-subtitle"},(0,He.__)("Control identifying metadata (site_url, site_name) and dynamically customize the charge statement description sent to Stripe.","woocommerce-gateway-stripe"))
                )
            ),
            (0,y.createElement)("div",{className:"wc-stripe-customizer-header-right"},
                (0,y.createElement)("label",{className:"wc-stripe-toggle-switch"},
                    (0,y.createElement)("input",{type:"checkbox",checked:enabled,onChange:e=>setEnabled(e.target.checked)}),
                    (0,y.createElement)("span",{className:"wc-stripe-toggle-slider"})
                ),
                (0,y.createElement)("span",{className:\`wc-stripe-status-indicator \${enabled?"is-active":"is-disabled"}\`},enabled?(0,He.__)("Enabled","woocommerce-gateway-stripe"):(0,He.__)("Disabled (Default OFF)","woocommerce-gateway-stripe"))
            )
        ),
        (0,y.createElement)("div",{className:"wc-stripe-customizer-body"},
            (0,y.createElement)("div",{className:"wc-stripe-customizer-form-col"},
                (0,y.createElement)("div",{className:"wc-stripe-field-group"},
                    (0,y.createElement)("label",{className:"wc-stripe-field-label"},(0,He.__)("Site URL Metadata (site_url)","woocommerce-gateway-stripe")),
                    (0,y.createElement)("input",{type:"text",className:"wc-stripe-input",value:siteUrl,placeholder:"hidden",onChange:e=>setSiteUrl(e.target.value)}),
                    (0,y.createElement)("p",{className:"wc-stripe-field-help"},(0,He.__)("Set custom value for site_url sent in Stripe metadata (e.g., 'hidden' or custom domain).","woocommerce-gateway-stripe"))
                ),
                (0,y.createElement)("div",{className:"wc-stripe-field-group"},
                    (0,y.createElement)("label",{className:"wc-stripe-field-label"},(0,He.__)("Store Name Metadata (site_name)","woocommerce-gateway-stripe")),
                    (0,y.createElement)("input",{type:"text",className:"wc-stripe-input",value:storeName,placeholder:"BEKAPAINT LIMITED",onChange:e=>setStoreName(e.target.value)}),
                    (0,y.createElement)("p",{className:"wc-stripe-field-help"},(0,He.__)("The brand or store name sent in Stripe metadata and used for description formatting.","woocommerce-gateway-stripe"))
                ),
                (0,y.createElement)("div",{className:"wc-stripe-field-group"},
                    (0,y.createElement)("label",{className:"wc-stripe-field-label"},(0,He.__)("Order Description Template","woocommerce-gateway-stripe")),
                    (0,y.createElement)("input",{type:"text",className:"wc-stripe-input",value:descTemplate,placeholder:"{store_name} - order {order_number}",onChange:e=>setDescTemplate(e.target.value)}),
                    (0,y.createElement)("div",{className:"wc-stripe-tags-wrapper"},
                        (0,y.createElement)("span",{className:"wc-stripe-tags-label"},(0,He.__)("Insert Dynamic Tags:","woocommerce-gateway-stripe")),
                        (0,y.createElement)("div",{className:"wc-stripe-tags-list"},
                            (0,y.createElement)("button",{type:"button",className:"wc-stripe-tag-chip",onClick:()=>insertTag("{store_name}")},"{store_name}"),
                            (0,y.createElement)("button",{type:"button",className:"wc-stripe-tag-chip",onClick:()=>insertTag("{order_number}")},"{order_number}"),
                            (0,y.createElement)("button",{type:"button",className:"wc-stripe-tag-chip",onClick:()=>insertTag("{customer_name}")},"{customer_name}"),
                            (0,y.createElement)("button",{type:"button",className:"wc-stripe-tag-chip",onClick:()=>insertTag("{order_date}")},"{order_date}"),
                            (0,y.createElement)("button",{type:"button",className:"wc-stripe-tag-chip",onClick:()=>insertTag("{order_total}")},"{order_total}")
                        )
                    ),
                    (0,y.createElement)("p",{className:"wc-stripe-field-help"},(0,He.__)("Template format for transaction description on Stripe charges and PaymentIntents.","woocommerce-gateway-stripe"))
                ),
                (0,y.createElement)("div",{className:"wc-stripe-customizer-actions"},
                    (0,y.createElement)("button",{type:"button",className:\`button button-primary wc-stripe-save-btn \${isSaving?"is-busy":""}\`,disabled:isSaving,onClick:handleSave},
                        isSaving?(0,He.__)("Saving...","woocommerce-gateway-stripe"):(0,He.__)("Save Customizer Settings","woocommerce-gateway-stripe")
                    ),
                    saveStatus==="success"&&(0,y.createElement)("span",{className:"wc-stripe-save-notice is-success"},
                        (0,y.createElement)("span",{className:"dashicons dashicons-yes"}),
                        saveMessage
                    ),
                    saveStatus==="error"&&(0,y.createElement)("span",{className:"wc-stripe-save-notice is-error"},
                        (0,y.createElement)("span",{className:"dashicons dashicons-warning"}),
                        saveMessage
                    )
                )
            ),
            (0,y.createElement)("div",{className:"wc-stripe-customizer-preview-col"},
                (0,y.createElement)("div",{className:"wc-stripe-mock-stripe-card"},
                    (0,y.createElement)("div",{className:"wc-stripe-mock-header"},
                        (0,y.createElement)("div",{className:"wc-stripe-mock-brand"},
                            (0,y.createElement)("span",{className:"wc-stripe-mock-stripe-logo"},"stripe"),
                            (0,y.createElement)("span",{className:"wc-stripe-mock-tag"},(0,He.__)("Dashboard Live Preview","woocommerce-gateway-stripe"))
                        ),
                        (0,y.createElement)("span",{className:\`wc-stripe-mock-status-pill \${enabled?"is-active":"is-off"}\`},
                            enabled?(0,He.__)("Masking Active","woocommerce-gateway-stripe"):(0,He.__)("Default State (Disabled)","woocommerce-gateway-stripe")
                        )
                    ),
                    (0,y.createElement)("div",{className:"wc-stripe-mock-body"},
                        (0,y.createElement)("div",{className:"wc-stripe-mock-row"},
                            (0,y.createElement)("span",{className:"wc-stripe-mock-label"},(0,He.__)("Statement Description:","woocommerce-gateway-stripe")),
                            (0,y.createElement)("span",{className:"wc-stripe-mock-value is-desc"},
                                enabled?getFormattedPreviewDesc():"Your Store Name - Order 1042"
                            )
                        ),
                        (0,y.createElement)("div",{className:"wc-stripe-mock-meta-box"},
                            (0,y.createElement)("div",{className:"wc-stripe-mock-meta-title"},(0,He.__)("Metadata Payload (Stripe API)","woocommerce-gateway-stripe")),
                            (0,y.createElement)("div",{className:"wc-stripe-mock-meta-item"},
                                (0,y.createElement)("span",{className:"wc-stripe-mock-meta-key"},"site_url:"),
                                (0,y.createElement)("span",{className:"wc-stripe-mock-meta-val"},
                                    enabled?(\`"\${siteUrl||"hidden"}"\`):('"https://example.com"')
                                )
                            ),
                            (0,y.createElement)("div",{className:"wc-stripe-mock-meta-item"},
                                (0,y.createElement)("span",{className:"wc-stripe-mock-meta-key"},"site_name:"),
                                (0,y.createElement)("span",{className:"wc-stripe-mock-meta-val"},
                                    enabled?(\`"\${storeName||"BEKAPAINT LIMITED"}"\`):('"My Original WooCommerce Store"')
                                )
                            ),
                            (0,y.createElement)("div",{className:"wc-stripe-mock-meta-item"},
                                (0,y.createElement)("span",{className:"wc-stripe-mock-meta-key"},"order_id:"),
                                (0,y.createElement)("span",{className:"wc-stripe-mock-meta-val"},'"1042"')
                            )
                        )
                    ),
                    (0,y.createElement)("div",{className:"wc-stripe-mock-footer"},
                        enabled?(0,He.__)("Requests to Stripe API will be automatically intercepted and masked.","woocommerce-gateway-stripe"):(0,He.__)("Toggle switch to ON to activate metadata & statement masking.","woocommerce-gateway-stripe")
                    )
                )
            )
        )
    );
};
const renderAdvanceToolsView=()=>(0,y.createElement)("div",{className:"wc-stripe-tab-view-container wc-stripe-advance-tools-view"},
    (0,y.createElement)(MetadataCustomizerTool,null),
    (0,y.createElement)("div",{className:"wc-stripe-scaffold-grid",style:{marginTop:"24px"}},
        (0,y.createElement)("div",{className:"wc-stripe-scaffold-card"},
            (0,y.createElement)("div",{className:"wc-stripe-scaffold-card-icon dashicons dashicons-rest-api"}),
            (0,y.createElement)("h3",null,(0,He.__)("API & Connection Health","woocommerce-gateway-stripe")),
            (0,y.createElement)("p",null,(0,He.__)("Test round-trip API connectivity, verify account capabilities, and check publishable/secret key status.","woocommerce-gateway-stripe")),
            (0,y.createElement)("div",{className:"wc-stripe-scaffold-slot"},(0,He.__)("Tool Slot: API Diagnostics Ready","woocommerce-gateway-stripe"))
        ),
        (0,y.createElement)("div",{className:"wc-stripe-scaffold-card"},
            (0,y.createElement)("div",{className:"wc-stripe-scaffold-card-icon dashicons dashicons-update"}),
            (0,y.createElement)("h3",null,(0,He.__)("Webhook Synchronization","woocommerce-gateway-stripe")),
            (0,y.createElement)("p",null,(0,He.__)("Re-register endpoint secrets, ping Stripe event listener, and review recent delivery logs.","woocommerce-gateway-stripe")),
            (0,y.createElement)("div",{className:"wc-stripe-scaffold-slot"},(0,He.__)("Tool Slot: Webhook Sync Ready","woocommerce-gateway-stripe"))
        ),
        (0,y.createElement)("div",{className:"wc-stripe-scaffold-card"},
            (0,y.createElement)("div",{className:"wc-stripe-scaffold-card-icon dashicons dashicons-trash"}),
            (0,y.createElement)("h3",null,(0,He.__)("Cache & Token Utilities","woocommerce-gateway-stripe")),
            (0,y.createElement)("p",null,(0,He.__)("Flush localized Stripe transient cache, re-index customer payment tokens, and repair legacy mandates.","woocommerce-gateway-stripe")),
            (0,y.createElement)("div",{className:"wc-stripe-scaffold-slot"},(0,He.__)("Tool Slot: Cache Tools Ready","woocommerce-gateway-stripe"))
        )
    )
);`;

const updatedJs = jsContent.substring(0, startIdx) + replacementComponent + jsContent.substring(endIdx);
fs.writeFileSync(jsPath, updatedJs, 'utf8');
console.log('Successfully injected MetadataCustomizerTool into build/upe-settings.js');

// CSS Styles for MetadataCustomizerTool
const customizerCss = [
  '/* Stripe Metadata & Statement Customizer Tool Styling */',
  '.wc-stripe-customizer-card {',
  '    background: #ffffff !important;',
  '    border: 1px solid #e2e8f0 !important;',
  '    border-radius: 12px !important;',
  '    padding: 24px 28px !important;',
  '    box-shadow: 0 1px 3px rgba(15, 23, 42, 0.04) !important;',
  '    margin-bottom: 24px !important;',
  '}',
  '.wc-stripe-customizer-header {',
  '    display: flex !important;',
  '    align-items: center !important;',
  '    justify-content: space-between !important;',
  '    flex-wrap: wrap !important;',
  '    gap: 16px !important;',
  '    padding-bottom: 20px !important;',
  '    border-bottom: 1px solid #f1f5f9 !important;',
  '    margin-bottom: 24px !important;',
  '}',
  '.wc-stripe-customizer-header-left {',
  '    display: flex !important;',
  '    align-items: center !important;',
  '    gap: 14px !important;',
  '}',
  '.wc-stripe-customizer-icon-wrap {',
  '    width: 44px !important;',
  '    height: 44px !important;',
  '    border-radius: 10px !important;',
  '    background: #eef2ff !important;',
  '    color: #635bff !important;',
  '    display: flex !important;',
  '    align-items: center !important;',
  '    justify-content: center !important;',
  '    font-size: 24px !important;',
  '}',
  '.wc-stripe-customizer-title {',
  '    font-size: 18px !important;',
  '    font-weight: 700 !important;',
  '    color: #0f172a !important;',
  '    margin: 0 0 4px 0 !important;',
  '}',
  '.wc-stripe-customizer-subtitle {',
  '    font-size: 13px !important;',
  '    color: #64748b !important;',
  '    margin: 0 !important;',
  '    max-width: 650px !important;',
  '}',
  '.wc-stripe-customizer-header-right {',
  '    display: flex !important;',
  '    align-items: center !important;',
  '    gap: 12px !important;',
  '}',
  '.wc-stripe-toggle-switch {',
  '    position: relative !important;',
  '    display: inline-block !important;',
  '    width: 44px !important;',
  '    height: 24px !important;',
  '    margin: 0 !important;',
  '}',
  '.wc-stripe-toggle-switch input {',
  '    opacity: 0 !important;',
  '    width: 0 !important;',
  '    height: 0 !important;',
  '}',
  '.wc-stripe-toggle-slider {',
  '    position: absolute !important;',
  '    cursor: pointer !important;',
  '    top: 0 !important;',
  '    left: 0 !important;',
  '    right: 0 !important;',
  '    bottom: 0 !important;',
  '    background-color: #cbd5e1 !important;',
  '    transition: 0.3s cubic-bezier(0.4, 0, 0.2, 1) !important;',
  '    border-radius: 24px !important;',
  '}',
  '.wc-stripe-toggle-slider:before {',
  '    position: absolute !important;',
  '    content: "" !important;',
  '    height: 18px !important;',
  '    width: 18px !important;',
  '    left: 3px !important;',
  '    bottom: 3px !important;',
  '    background-color: white !important;',
  '    transition: 0.3s cubic-bezier(0.4, 0, 0.2, 1) !important;',
  '    border-radius: 50% !important;',
  '    box-shadow: 0 1px 3px rgba(0,0,0,0.15) !important;',
  '}',
  '.wc-stripe-toggle-switch input:checked + .wc-stripe-toggle-slider {',
  '    background-color: #635bff !important;',
  '}',
  '.wc-stripe-toggle-switch input:checked + .wc-stripe-toggle-slider:before {',
  '    transform: translateX(20px) !important;',
  '}',
  '.wc-stripe-status-indicator {',
  '    font-size: 12px !important;',
  '    font-weight: 600 !important;',
  '    padding: 4px 10px !important;',
  '    border-radius: 6px !important;',
  '}',
  '.wc-stripe-status-indicator.is-active {',
  '    background: #dcfce7 !important;',
  '    color: #15803d !important;',
  '}',
  '.wc-stripe-status-indicator.is-disabled {',
  '    background: #f1f5f9 !important;',
  '    color: #64748b !important;',
  '}',
  '.wc-stripe-customizer-body {',
  '    display: grid !important;',
  '    grid-template-columns: 1fr 1fr !important;',
  '    gap: 32px !important;',
  '}',
  '@media (max-width: 900px) {',
  '    .wc-stripe-customizer-body {',
  '        grid-template-columns: 1fr !important;',
  '    }',
  '}',
  '.wc-stripe-field-group {',
  '    margin-bottom: 20px !important;',
  '}',
  '.wc-stripe-field-label {',
  '    display: block !important;',
  '    font-size: 13px !important;',
  '    font-weight: 600 !important;',
  '    color: #1e293b !important;',
  '    margin-bottom: 6px !important;',
  '}',
  '.wc-stripe-input {',
  '    width: 100% !important;',
  '    padding: 9px 12px !important;',
  '    font-size: 13.5px !important;',
  '    border: 1px solid #cbd5e1 !important;',
  '    border-radius: 6px !important;',
  '    background: #f8fafc !important;',
  '    color: #0f172a !important;',
  '    transition: border-color 0.2s, box-shadow 0.2s !important;',
  '}',
  '.wc-stripe-input:focus {',
  '    border-color: #635bff !important;',
  '    box-shadow: 0 0 0 3px rgba(99, 91, 255, 0.15) !important;',
  '    background: #ffffff !important;',
  '    outline: none !important;',
  '}',
  '.wc-stripe-field-help {',
  '    font-size: 12px !important;',
  '    color: #64748b !important;',
  '    margin: 6px 0 0 0 !important;',
  '    line-height: 1.45 !important;',
  '}',
  '.wc-stripe-tags-wrapper {',
  '    margin-top: 8px !important;',
  '    padding: 8px 10px !important;',
  '    background: #f1f5f9 !important;',
  '    border-radius: 6px !important;',
  '}',
  '.wc-stripe-tags-label {',
  '    display: block !important;',
  '    font-size: 11px !important;',
  '    font-weight: 600 !important;',
  '    color: #475569 !important;',
  '    text-transform: uppercase !important;',
  '    letter-spacing: 0.04em !important;',
  '    margin-bottom: 6px !important;',
  '}',
  '.wc-stripe-tags-list {',
  '    display: flex !important;',
  '    flex-wrap: wrap !important;',
  '    gap: 6px !important;',
  '}',
  '.wc-stripe-tag-chip {',
  '    background: #ffffff !important;',
  '    border: 1px solid #cbd5e1 !important;',
  '    border-radius: 4px !important;',
  '    font-size: 11.5px !important;',
  '    font-family: monospace !important;',
  '    color: #4338ca !important;',
  '    padding: 3px 8px !important;',
  '    cursor: pointer !important;',
  '    transition: all 0.15s ease !important;',
  '}',
  '.wc-stripe-tag-chip:hover {',
  '    background: #e0e7ff !important;',
  '    border-color: #a5b4fc !important;',
  '}',
  '.wc-stripe-customizer-actions {',
  '    display: flex !important;',
  '    align-items: center !important;',
  '    gap: 14px !important;',
  '    margin-top: 24px !important;',
  '}',
  '.wc-stripe-save-btn {',
  '    background: #635bff !important;',
  '    border-color: #635bff !important;',
  '    color: #ffffff !important;',
  '    font-weight: 600 !important;',
  '    padding: 8px 18px !important;',
  '    height: auto !important;',
  '    border-radius: 6px !important;',
  '    cursor: pointer !important;',
  '    transition: background 0.2s !important;',
  '}',
  '.wc-stripe-save-btn:hover {',
  '    background: #4f46e5 !important;',
  '    border-color: #4f46e5 !important;',
  '}',
  '.wc-stripe-save-notice {',
  '    display: inline-flex !important;',
  '    align-items: center !important;',
  '    gap: 6px !important;',
  '    font-size: 13px !important;',
  '    font-weight: 600 !important;',
  '}',
  '.wc-stripe-save-notice.is-success {',
  '    color: #16a34a !important;',
  '}',
  '.wc-stripe-save-notice.is-error {',
  '    color: #dc2626 !important;',
  '}',
  '',
  '/* Live Stripe Mockup */',
  '.wc-stripe-mock-stripe-card {',
  '    background: #1e293b !important;',
  '    border-radius: 10px !important;',
  '    padding: 20px !important;',
  '    color: #f8fafc !important;',
  '    box-shadow: 0 4px 12px rgba(0,0,0,0.1) !important;',
  '    height: 100% !important;',
  '    display: flex !important;',
  '    flex-direction: column !important;',
  '}',
  '.wc-stripe-mock-header {',
  '    display: flex !important;',
  '    align-items: center !important;',
  '    justify-content: space-between !important;',
  '    padding-bottom: 12px !important;',
  '    border-bottom: 1px solid #334155 !important;',
  '    margin-bottom: 16px !important;',
  '}',
  '.wc-stripe-mock-brand {',
  '    display: flex !important;',
  '    align-items: center !important;',
  '    gap: 10px !important;',
  '}',
  '.wc-stripe-mock-stripe-logo {',
  '    font-weight: 800 !important;',
  '    font-size: 16px !important;',
  '    letter-spacing: -0.03em !important;',
  '    color: #635bff !important;',
  '    background: #ffffff !important;',
  '    padding: 2px 8px !important;',
  '    border-radius: 4px !important;',
  '}',
  '.wc-stripe-mock-tag {',
  '    font-size: 12px !important;',
  '    color: #94a3b8 !important;',
  '    font-weight: 500 !important;',
  '}',
  '.wc-stripe-mock-status-pill {',
  '    font-size: 11px !important;',
  '    font-weight: 600 !important;',
  '    padding: 2px 8px !important;',
  '    border-radius: 9999px !important;',
  '}',
  '.wc-stripe-mock-status-pill.is-active {',
  '    background: rgba(34, 197, 94, 0.2) !important;',
  '    color: #4ade80 !important;',
  '}',
  '.wc-stripe-mock-status-pill.is-off {',
  '    background: rgba(148, 163, 184, 0.2) !important;',
  '    color: #cbd5e1 !important;',
  '}',
  '.wc-stripe-mock-row {',
  '    margin-bottom: 14px !important;',
  '}',
  '.wc-stripe-mock-label {',
  '    display: block !important;',
  '    font-size: 11px !important;',
  '    font-weight: 600 !important;',
  '    text-transform: uppercase !important;',
  '    color: #94a3b8 !important;',
  '    margin-bottom: 4px !important;',
  '}',
  '.wc-stripe-mock-value.is-desc {',
  '    display: block !important;',
  '    font-size: 14px !important;',
  '    font-weight: 600 !important;',
  '    color: #38bdf8 !important;',
  '    background: #0f172a !important;',
  '    padding: 8px 12px !important;',
  '    border-radius: 6px !important;',
  '    border: 1px solid #334155 !important;',
  '}',
  '.wc-stripe-mock-meta-box {',
  '    background: #0f172a !important;',
  '    border: 1px solid #334155 !important;',
  '    border-radius: 8px !important;',
  '    padding: 12px 14px !important;',
  '    margin-top: 14px !important;',
  '    font-family: monospace !important;',
  '}',
  '.wc-stripe-mock-meta-title {',
  '    font-size: 11px !important;',
  '    font-weight: 700 !important;',
  '    color: #cbd5e1 !important;',
  '    margin-bottom: 8px !important;',
  '    text-transform: uppercase !important;',
  '}',
  '.wc-stripe-mock-meta-item {',
  '    display: flex !important;',
  '    align-items: center !important;',
  '    gap: 8px !important;',
  '    font-size: 12.5px !important;',
  '    margin-bottom: 4px !important;',
  '}',
  '.wc-stripe-mock-meta-key {',
  '    color: #94a3b8 !important;',
  '}',
  '.wc-stripe-mock-meta-val {',
  '    color: #4ade80 !important;',
  '}',
  '.wc-stripe-mock-footer {',
  '    margin-top: auto !important;',
  '    padding-top: 14px !important;',
  '    font-size: 11.5px !important;',
  '    color: #64748b !important;',
  '    border-top: 1px solid #334155 !important;',
  '}'
].join('\n');

let cssContent = fs.readFileSync(cssPath, 'utf8');
if (!cssContent.includes('wc-stripe-customizer-card')) {
    fs.writeFileSync(cssPath, cssContent + '\n' + customizerCss, 'utf8');
    console.log('Appended customizer styles to build/upe-settings.css');
}

let rtlCssContent = fs.readFileSync(rtlCssPath, 'utf8');
if (!rtlCssContent.includes('wc-stripe-customizer-card')) {
    fs.writeFileSync(rtlCssPath, rtlCssContent + '\n' + customizerCss, 'utf8');
    console.log('Appended customizer styles to build/upe-settings-rtl.css');
}
