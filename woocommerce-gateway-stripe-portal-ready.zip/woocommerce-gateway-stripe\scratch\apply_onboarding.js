const fs = require('fs');

const file = 'build/upe-settings.js';
let code = fs.readFileSync(file, 'utf8');

// Find the target ej block to replace
const targetStart = 'ej&&(0,I.H)(ej).render(';
const startIdx = code.indexOf(targetStart);
if (startIdx === -1) {
    console.error('Target start not found');
    process.exit(1);
}

// Find the ending for ej.render
const endTarget = ',null))})()})();';
const endIdx = code.lastIndexOf(endTarget);
if (endIdx === -1) {
    console.error('End target not found');
    process.exit(1);
}

console.log('Original block length:', endIdx + endTarget.length - startIdx);

const replacement = `ej&&(0,I.H)(ej).render((0,y.createElement)(()=>{
    const[e,t]=(0,h.useState)(!1),
    [n,i]=(0,h.useState)(null),
    a=(0,h.useCallback)(e=>{t(!!e)},[t]);
    return (0,y.createElement)(y.Fragment,null,
        n&&(0,y.createElement)(Oo,{type:n,onClose:()=>i(null)}),
        (0,y.createElement)("div",{className:"wc-stripe-onboarding-deck-wrapper"},
            (0,y.createElement)("div",{className:"wc-stripe-onboarding-card"},
                (0,y.createElement)("div",{className:"wc-stripe-onboarding-banner"},
                    (0,y.createElement)(Xe,null)
                ),
                (0,y.createElement)("div",{className:"wc-stripe-onboarding-content-grid"},
                    (0,y.createElement)("div",{className:"wc-stripe-onboarding-info-col"},
                        (0,y.createElement)("h1",{className:"wc-stripe-onboarding-title"},(0,He.__)("Get started with Stripe","woocommerce-gateway-stripe")),
                        (0,y.createElement)("p",{className:"wc-stripe-onboarding-description"},(0,He.__)("Connect or create a Stripe account to accept all major debit and credit cards, digital wallets (including Apple Pay and Google Pay), buy now, pay later options (such as Klarna and Affirm), and a wide range of local and international payment methods.","woocommerce-gateway-stripe")),
                        (0,y.createElement)("div",{className:"wc-stripe-onboarding-features-list"},
                            (0,y.createElement)("div",{className:"wc-stripe-feature-item"},
                                (0,y.createElement)("span",{className:"wc-stripe-feature-icon"},"✓"),
                                (0,y.createElement)("div",{className:"wc-stripe-feature-text"},
                                    (0,y.createElement)("strong",null,"Global Cards & Digital Wallets: "),
                                    (0,y.createElement)("span",null,"Accept Visa, Mastercard, Amex, Apple Pay, Google Pay & Link with 1-click checkout.")
                                )
                            ),
                            (0,y.createElement)("div",{className:"wc-stripe-feature-item"},
                                (0,y.createElement)("span",{className:"wc-stripe-feature-icon"},"✓"),
                                (0,y.createElement)("div",{className:"wc-stripe-feature-text"},
                                    (0,y.createElement)("strong",null,"Built-in Radar Fraud Protection: "),
                                    (0,y.createElement)("span",null,"Advanced ML fraud detection, chargeback prevention, and 3D Secure 2.0.")
                                )
                            ),
                            (0,y.createElement)("div",{className:"wc-stripe-feature-item"},
                                (0,y.createElement)("span",{className:"wc-stripe-feature-icon"},"✓"),
                                (0,y.createElement)("div",{className:"wc-stripe-feature-text"},
                                    (0,y.createElement)("strong",null,"135+ Currencies & Buy Now Pay Later: "),
                                    (0,y.createElement)("span",null,"Klarna, Affirm, Afterpay/Clearpay, and dynamic local currency conversions.")
                                )
                            )
                        )
                    ),
                    (0,y.createElement)("div",{className:"wc-stripe-onboarding-actions-col"},
                        (0,y.createElement)("div",{className:"wc-stripe-actions-box"},
                            (0,y.createElement)("h3",{className:"wc-stripe-actions-box-title"},(0,He.__)("Connect Your Account","woocommerce-gateway-stripe")),
                            (0,y.createElement)("p",{className:"wc-stripe-actions-box-sub"},(0,He.__)("Choose your connection mode to start accepting live payments or test sandbox transactions.","woocommerce-gateway-stripe")),
                            e&&(0,y.createElement)(It,null,(0,y.createElement)(ot,null)),
                            (0,y.createElement)("div",{className:"wc-stripe-auth-buttons-stack"},
                                (0,y.createElement)(jt,{testMode:!1,buttonVariant:"primary",onErrorChange:a}),
                                (0,y.createElement)(jt,{testMode:!0,buttonVariant:"secondary",onErrorChange:a}),
                                (0,y.createElement)(_e.Button,{variant:"secondary",onClick:()=>i("api"),"data-testid":"connect-api-keys",className:"wc-stripe-btn-connect-api"},(0,He.__)("Connect with API keys","woocommerce-gateway-stripe"))
                            ),
                            (0,y.createElement)("p",{className:"wc-stripe-auth-help-note"},(0,He.__)("Some payment methods are automatically enabled when you connect your account. Review your Payment Methods settings for details.","woocommerce-gateway-stripe")),
                            (0,y.createElement)(Dt,null,We({mixedString:(0,He.__)('By clicking \"Create or connect an account\", you agree to the {{tosLink}}Terms of service.{{/tosLink}}',\"woocommerce-gateway-stripe\"),components:{tosLink:(0,y.createElement)(\"a\",{target:\"_blank\",rel:\"noreferrer\",href:\"https://wordpress.com/tos\"})}}))
                        )
                    )
                ),
                (0,y.createElement)("div",{className:"wc-stripe-onboarding-footer"},
                    (0,y.createElement)("div",{className:"wc-stripe-footer-brand"},
                        (0,y.createElement)("span",{className:"wc-stripe-developer-tag"},"✨ Developed by Azeem Greater")
                    ),
                    (0,y.createElement)("div",{className:"wc-stripe-footer-security"},
                        (0,y.createElement)("span",{className:"wc-stripe-badge-secure"},"🔒 PCI DSS Level 1 Certified • 256-Bit SSL Encrypted")
                    )
                )
            )
        )
    )
},null))})()})();`;

const newCode = code.substring(0, startIdx) + replacement;
fs.writeFileSync(file, newCode, 'utf8');
console.log('Successfully updated build/upe-settings.js');
