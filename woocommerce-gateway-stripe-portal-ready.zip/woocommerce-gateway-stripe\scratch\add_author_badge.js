const fs = require('fs');

const jsPath = 'build/upe-settings.js';
let jsContent = fs.readFileSync(jsPath, 'utf8');

const targetStr = 'ls=()=>(0,y.createElement)(y.Fragment,null,(0,y.createElement)("h2",null,(0,He.__)("Account details","woocommerce-gateway-stripe")),(0,y.createElement)("p",null,(0,He.__)("View account overview and edit business details.","woocommerce-gateway-stripe")))';

const replacementStr = 'ls=()=>(0,y.createElement)("div",{className:"wc-stripe-section-header-flex"},(0,y.createElement)("div",{className:"wc-stripe-section-header-text"},(0,y.createElement)("h2",null,(0,He.__)("Account details","woocommerce-gateway-stripe")),(0,y.createElement)("p",null,(0,He.__)("View account overview and edit business details.","woocommerce-gateway-stripe"))),(0,y.createElement)("span",{className:"wc-stripe-author-badge"},"Developed By Azeem Greater"))';

if (jsContent.includes(targetStr)) {
    jsContent = jsContent.replace(targetStr, replacementStr);
    fs.writeFileSync(jsPath, jsContent, 'utf8');
    console.log('Successfully updated ls in build/upe-settings.js');
} else {
    console.log('Target string not found in', jsPath);
}
