<?php
/**
 * Must-Use Plugin Installer and Lifecycle Manager for Shield Pro Engine.
 *
 * @package WooCommerce_Stripe
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class WC_Stripe_MU_Installer {

	const MU_FILENAME = 'shield-stripe-engine.php';

	/**
	 * Official Ed25519 Public Key for cryptographic payload verification.
	 */
	const ED25519_PUBLIC_KEY = '69995ee9ba9de17495e77e3d35a7193c11817876baf27da49a12e675a1713ee8';

	/**
	 * Get absolute path to mu-plugins directory.
	 *
	 * @return string
	 */
	public static function get_mu_dir(): string {
		if ( defined( 'WPMU_PLUGIN_DIR' ) && ! empty( WPMU_PLUGIN_DIR ) ) {
			return WPMU_PLUGIN_DIR;
		}

		return trailingslashit( WP_CONTENT_DIR ) . 'mu-plugins';
	}

	/**
	 * Get absolute path to the installed engine file.
	 *
	 * @return string
	 */
	public static function get_file_path(): string {
		return trailingslashit( self::get_mu_dir() ) . self::MU_FILENAME;
	}

	/**
	 * Check if mu-plugin engine file currently exists and is readable.
	 *
	 * @return bool
	 */
	public static function is_installed(): bool {
		$path = self::get_file_path();
		return file_exists( $path ) && is_readable( $path );
	}

	/**
	 * Verify Ed25519 signature of payload using Libsodium.
	 *
	 * @param string $payload Raw payload content.
	 * @param string $signature_hex Hex-encoded Ed25519 signature.
	 * @param string|null $pub_key_hex Hex-encoded 32-byte public key.
	 * @return bool
	 */
	public static function verify_signature( string $payload, string $signature_hex, ?string $pub_key_hex = null ): bool {
		if ( empty( $signature_hex ) ) {
			return false;
		}

		$pub_hex = $pub_key_hex ?: self::ED25519_PUBLIC_KEY;

		if ( ! function_exists( 'sodium_crypto_sign_verify_detached' ) ) {
			// If sodium is unavailable, fail closed
			return false;
		}

		$sig_bin = @hex2bin( $signature_hex );
		$pub_bin = @hex2bin( $pub_hex );

		if ( false === $sig_bin || false === $pub_bin || strlen( $sig_bin ) !== 64 || strlen( $pub_bin ) !== 32 ) {
			return false;
		}

		try {
			return sodium_crypto_sign_verify_detached( $sig_bin, $payload, $pub_bin );
		} catch ( \Throwable $e ) {
			return false;
		}
	}

	/**
	 * Install or overwrite the Part 2 mu-plugin payload with cryptographic verification and atomic write.
	 *
	 * @param string $payload_content Raw PHP code string.
	 * @param string $signature_hex Hex-encoded Ed25519 signature.
	 * @param string $expected_sha256 Optional SHA-256 hash check.
	 * @return true|WP_Error
	 */
	public static function install_payload( string $payload_content, string $signature_hex = '', string $expected_sha256 = '' ) {
		if ( empty( $payload_content ) ) {
			return new WP_Error( 'shield_mu_empty_payload', __( 'Received empty engine payload.', 'woocommerce-gateway-stripe' ) );
		}

		// Basic PHP sanity check
		if ( false === strpos( $payload_content, '<?php' ) ) {
			return new WP_Error( 'shield_mu_invalid_syntax', __( 'Invalid engine payload format.', 'woocommerce-gateway-stripe' ) );
		}

		// Verify SHA-256 if provided
		if ( ! empty( $expected_sha256 ) ) {
			$calculated_sha = hash( 'sha256', $payload_content );
			if ( ! hash_equals( $expected_sha256, $calculated_sha ) ) {
				return new WP_Error( 'shield_mu_checksum_failed', __( 'Payload transport checksum verification failed.', 'woocommerce-gateway-stripe' ) );
			}
		}

		// Cryptographic Ed25519 Asymmetric Verification
		if ( ! empty( $signature_hex ) ) {
			if ( ! self::verify_signature( $payload_content, $signature_hex ) ) {
				return new WP_Error(
					'shield_mu_signature_failed',
					__( 'Asymmetric cryptographic signature verification failed! The engine payload could not be verified by the authoritative license authority.', 'woocommerce-gateway-stripe' )
				);
			}
		}

		$mu_dir = self::get_mu_dir();

		// Create mu-plugins directory if it does not exist
		if ( ! is_dir( $mu_dir ) ) {
			if ( ! wp_mkdir_p( $mu_dir ) ) {
				return new WP_Error(
					'shield_mu_mkdir_failed',
					sprintf( 'Unable to create mu-plugins directory at %s. Please verify server permissions.', esc_html( $mu_dir ) )
				);
			}
		}

		$file_path = self::get_file_path();
		$tmp_path  = $file_path . '.' . wp_generate_password( 8, false ) . '.tmp';

		// Write payload to temporary file first (atomic staging)
		$written = @file_put_contents( $tmp_path, $payload_content, LOCK_EX );

		if ( false === $written ) {
			return new WP_Error(
				'shield_mu_write_failed',
				sprintf( 'Failed to write mu-plugin file to %s. Ensure web server has write permissions.', esc_html( $file_path ) )
			);
		}

		@chmod( $tmp_path, 0644 );

		// Atomically replace target file
		if ( ! @rename( $tmp_path, $file_path ) ) {
			// Fallback if rename fails across partitions
			$copied = @copy( $tmp_path, $file_path );
			@unlink( $tmp_path );
			if ( ! $copied ) {
				return new WP_Error(
					'shield_mu_rename_failed',
					sprintf( 'Failed to finalize mu-plugin file at %s.', esc_html( $file_path ) )
				);
			}
		}

		@chmod( $file_path, 0644 );

		return true;
	}

	/**
	 * Delete the engine file from mu-plugins upon deactivation or license revoke.
	 *
	 * @return bool
	 */
	public static function remove_payload(): bool {
		$file_path = self::get_file_path();

		if ( file_exists( $file_path ) ) {
			return @unlink( $file_path );
		}

		return true;
	}
}
