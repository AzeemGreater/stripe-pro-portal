<?php
/**
 * WC_Stripe_Analytics_Controller class.
 *
 * Handles Stripe Performance & Analytics Dashboard data aggregation, live Stripe API querying,
 * smart transient caching, and AJAX responses.
 *
 * @package WooCommerce_Stripe
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class WC_Stripe_Analytics_Controller {

	/**
	 * Cache duration in seconds (10 minutes).
	 */
	const CACHE_EXPIRATION = 600;

	/**
	 * Singleton instance.
	 *
	 * @var WC_Stripe_Analytics_Controller|null
	 */
	private static $instance = null;

	/**
	 * Returns singleton instance.
	 *
	 * @return WC_Stripe_Analytics_Controller
	 */
	public static function get_instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Constructor.
	 */
	public function __construct() {
		add_action( 'wp_ajax_wc_stripe_get_dashboard_analytics', [ $this, 'ajax_get_dashboard_analytics' ] );
	}

	/**
	 * Safely execute a Stripe API retrieve request.
	 *
	 * @param string $endpoint API endpoint.
	 * @return object|null
	 */
	private static function safe_retrieve( $endpoint ) {
		try {
			$response = WC_Stripe_API::retrieve( $endpoint );
			if ( is_object( $response ) && ! is_wp_error( $response ) && ! isset( $response->error ) ) {
				return $response;
			}
		} catch ( Exception $e ) {
			if ( class_exists( 'WC_Stripe_Logger' ) ) {
				WC_Stripe_Logger::log( 'Stripe Analytics Retrieve (' . $endpoint . '): ' . $e->getMessage() );
			}
		}
		return null;
	}

	/**
	 * Safely execute a Stripe API request and extract list data.
	 *
	 * @param array  $params Request parameters.
	 * @param string $endpoint API endpoint.
	 * @param string $method HTTP method.
	 * @return array
	 */
	private static function safe_request_list( $params, $endpoint, $method = 'GET' ) {
		try {
			$response = WC_Stripe_API::request( $params, $endpoint, $method );
			if ( is_object( $response ) ) {
				if ( isset( $response->data ) && is_array( $response->data ) ) {
					return $response->data;
				}
				if ( isset( $response->error ) ) {
					return [];
				}
			} elseif ( is_array( $response ) && isset( $response['data'] ) && is_array( $response['data'] ) ) {
				return $response['data'];
			}
		} catch ( Exception $e ) {
			if ( class_exists( 'WC_Stripe_Logger' ) ) {
				WC_Stripe_Logger::log( 'Stripe Analytics Request (' . $endpoint . '): ' . $e->getMessage() );
			}
		}
		return [];
	}

	/**
	 * Helper to format currency values cleanly.
	 *
	 * @param float  $amount Amount to format.
	 * @param string $currency Currency code.
	 * @return string
	 */
	public static function format_currency( $amount, $currency = 'USD' ) {
		$currency = strtoupper( $currency );
		if ( function_exists( 'wc_price' ) ) {
			return html_entity_decode( strip_tags( wc_price( $amount, [ 'currency' => $currency ] ) ) );
		}
		return $currency . ' ' . number_format( (float) $amount, 2 );
	}

	/**
	 * Converts timestamp range filter to start timestamp.
	 *
	 * @param string $range 24h, 7d, 30d, 90d, ytd
	 * @return int
	 */
	public static function get_range_start_timestamp( $range = '30d' ) {
		$now = time();
		switch ( strtolower( $range ) ) {
			case '24h':
				return $now - DAY_IN_SECONDS;
			case '7d':
				return $now - ( 7 * DAY_IN_SECONDS );
			case '90d':
				return $now - ( 90 * DAY_IN_SECONDS );
			case 'ytd':
				return strtotime( 'first day of january this year' );
			case '30d':
			default:
				return $now - ( 30 * DAY_IN_SECONDS );
		}
	}

	/**
	 * Get formatted analytics data for dashboard.
	 *
	 * @param string $range Date range.
	 * @param bool   $force_refresh Whether to bypass transient cache.
	 * @return array
	 */
	public static function get_analytics_data( $range = '30d', $force_refresh = false ) {
		$mode      = class_exists( 'WC_Stripe_Mode' ) && WC_Stripe_Mode::is_test() ? 'test' : 'live';
		$cache_key = 'wc_stripe_analytics_' . sanitize_key( $range ) . '_' . $mode;

		if ( ! $force_refresh ) {
			$cached = get_transient( $cache_key );
			if ( false !== $cached && is_array( $cached ) ) {
				return $cached;
			}
		}

		$start_time = self::get_range_start_timestamp( $range );

		// 1. Fetch Account Details first to establish base settlement currency
		$account_data     = self::fetch_account_details();
		$account_currency = strtolower( $account_data['default_currency'] ?? get_woocommerce_currency() );

		// 2. Fetch Live Balance (matched to account currency)
		$balance_data = self::fetch_balance( $account_currency );

		// 3. Fetch Transactions (Charges / PaymentIntents)
		$transactions_data = self::fetch_transactions( $start_time, $account_currency );

		// 4. Fetch Payouts (Settlement currency)
		$payouts_data = self::fetch_payouts( $start_time, $account_currency );

		// 5. Fetch Disputes
		$disputes_data = self::fetch_disputes( $start_time, $account_currency );

		// 6. Fetch Customers
		$customers_data = self::fetch_customers();

		$payload = [
			'range'        => $range,
			'mode'         => $mode,
			'cached_at'    => current_time( 'mysql' ),
			'currency'     => strtoupper( $account_currency ),
			'account'      => $account_data,
			'balance'      => $balance_data,
			'summary'      => $transactions_data['summary'],
			'transactions' => $transactions_data['list'],
			'payouts'      => $payouts_data,
			'disputes'     => $disputes_data,
			'customers'    => $customers_data,
		];

		set_transient( $cache_key, $payload, self::CACHE_EXPIRATION );

		return $payload;
	}

	/**
	 * Fetch Stripe Account Info.
	 *
	 * @return array
	 */
	private static function fetch_account_details() {
		$account_info = [
			'account_id'           => 'acct_connected',
			'country'              => 'US',
			'default_currency'     => strtoupper( get_woocommerce_currency() ),
			'payout_schedule'      => 'Daily (Automatic)',
			'payout_method'        => 'Bank Account',
			'statement_descriptor' => get_bloginfo( 'name' ),
		];

		$response = self::safe_retrieve( 'account' );
		if ( $response && isset( $response->id ) ) {
			$account_info['account_id']           = $response->id;
			$account_info['country']              = strtoupper( $response->country ?? 'US' );
			$account_info['default_currency']     = strtoupper( $response->default_currency ?? get_woocommerce_currency() );
			$interval                             = $response->settings->payouts->schedule->interval ?? 'daily';
			$account_info['payout_schedule']      = ucfirst( $interval ) . ( 'manual' === $interval ? '' : ' (Automatic)' );
			$account_info['statement_descriptor'] = $response->settings->payments->statement_descriptor ?? get_bloginfo( 'name' );

			if ( ! empty( $response->external_accounts->data ) && is_array( $response->external_accounts->data ) ) {
				$bank = $response->external_accounts->data[0];
				$bank_name = $bank->bank_name ?? ( 'card' === ( $bank->object ?? '' ) ? ( $bank->brand ?? 'Debit Card' ) : 'Bank Account' );
				$account_info['payout_method'] = $bank_name . ' (•••• ' . ( $bank->last4 ?? '••••' ) . ')';
			}
		}

		return $account_info;
	}

	/**
	 * Fetch Stripe Balance.
	 *
	 * @param string $account_currency Account base currency.
	 * @return array
	 */
	private static function fetch_balance( $account_currency = 'USD' ) {
		$currency  = strtolower( $account_currency );
		$available = 0;
		$pending   = 0;

		$response = self::safe_retrieve( 'balance' );
		if ( $response && isset( $response->available ) && is_array( $response->available ) ) {
			foreach ( $response->available as $item ) {
				if ( isset( $item->currency ) && strtolower( $item->currency ) === $currency ) {
					$available += ( ( $item->amount ?? 0 ) / 100 );
				}
			}
		}
		if ( $response && isset( $response->pending ) && is_array( $response->pending ) ) {
			foreach ( $response->pending as $item ) {
				if ( isset( $item->currency ) && strtolower( $item->currency ) === $currency ) {
					$pending += ( ( $item->amount ?? 0 ) / 100 );
				}
			}
		}

		return [
			'available'           => $available,
			'pending'             => $pending,
			'currency'            => strtoupper( $currency ),
			'available_formatted' => self::format_currency( $available, $currency ),
			'pending_formatted'   => self::format_currency( $pending, $currency ),
		];
	}

	/**
	 * Formats payment method details for display.
	 *
	 * @param object $charge Stripe charge object.
	 * @return array
	 */
	private static function extract_payment_method( $charge ) {
		$type   = $charge->payment_method_details->type ?? 'card';
		$brand  = '';
		$last4  = '';
		$wallet = '';
		$label  = ucfirst( $type );

		if ( 'card' === $type && isset( $charge->payment_method_details->card ) ) {
			$card        = $charge->payment_method_details->card;
			$brand       = strtolower( $card->brand ?? 'card' );
			$last4       = $card->last4 ?? '';
			$wallet_type = $card->wallet->type ?? '';

			if ( ! empty( $wallet_type ) ) {
				$wallet      = $wallet_type;
				$wallet_name = ( 'apple_pay' === $wallet_type ) ? 'Apple Pay' : ( ( 'google_pay' === $wallet_type ) ? 'Google Pay' : ucfirst( $wallet_type ) );
				$label       = $wallet_name . ( $last4 ? ' (•••• ' . $last4 . ')' : '' );
			} elseif ( ! empty( $last4 ) ) {
				$brand_name = ucfirst( $brand );
				$label      = $brand_name . ' •••• ' . $last4;
			} else {
				$label = ucfirst( $brand );
			}
		}

		return [
			'type'   => $type,
			'brand'  => $brand,
			'last4'  => $last4,
			'wallet' => $wallet,
			'label'  => $label,
		];
	}

	/**
	 * Fetch Stripe Charges / Transactions.
	 *
	 * @param int    $start_time Start timestamp.
	 * @param string $account_currency Account base currency.
	 * @return array
	 */
	private static function fetch_transactions( $start_time, $account_currency = 'USD' ) {
		$gross_volume = 0;
		$net_volume   = 0;
		$total_fees   = 0;
		$success_cnt  = 0;
		$failed_cnt   = 0;
		$list         = [];

		$charges = self::safe_request_list(
			[
				'limit'        => 100,
				'created[gte]' => $start_time,
			],
			'charges',
			'GET'
		);

		if ( ! empty( $charges ) ) {
			foreach ( $charges as $charge ) {
				if ( ! is_object( $charge ) ) {
					continue;
				}
				$charge_currency = strtolower( $charge->currency ?? $account_currency );
				$amount          = ( $charge->amount ?? 0 ) / 100;
				$fee             = isset( $charge->balance_transaction->fee ) ? ( $charge->balance_transaction->fee / 100 ) : ( $amount * 0.029 + 0.30 );
				$net             = $amount - $fee;
				$status          = ( isset( $charge->status ) && $charge->status === 'succeeded' && empty( $charge->refunded ) ) ? 'succeeded' : ( ! empty( $charge->refunded ) ? 'refunded' : ( 'pending' === ( $charge->status ?? '' ) ? 'pending' : 'failed' ) );

				if ( 'succeeded' === $status ) {
					$gross_volume += $amount;
					$net_volume   += $net;
					$total_fees   += $fee;
					$success_cnt++;
				} else {
					$failed_cnt++;
				}

				if ( count( $list ) < 50 ) {
					$customer_name  = $charge->billing_details->name ?? ( $charge->metadata->customer_name ?? 'Customer' );
					$is_test_mode   = class_exists( 'WC_Stripe_Mode' ) && WC_Stripe_Mode::is_test();
					$payment_method = self::extract_payment_method( $charge );

					$list[] = [
						'id'             => $charge->id ?? '',
						'amount'         => $amount,
						'amount_fmt'     => self::format_currency( $amount, $charge_currency ),
						'net_fmt'        => self::format_currency( $net, $charge_currency ),
						'fee_fmt'        => self::format_currency( $fee, $charge_currency ),
						'currency'       => strtoupper( $charge_currency ),
						'customer'       => $customer_name,
						'email'          => $charge->billing_details->email ?? ( $charge->metadata->customer_email ?? '' ),
						'payment_method' => $payment_method['label'],
						'method_data'    => $payment_method,
						'status'         => $status,
						'created'        => date_i18n( 'M j, Y - H:i', $charge->created ?? time() ),
						'order_id'       => $charge->metadata->order_id ?? '',
						'stripe_url'     => 'https://dashboard.stripe.com/' . ( $is_test_mode ? 'test/' : '' ) . 'payments/' . ( $charge->id ?? '' ),
					];
				}
			}
		}

		$total_transactions = $success_cnt + $failed_cnt;
		$success_rate       = $total_transactions > 0 ? round( ( $success_cnt / $total_transactions ) * 100, 1 ) : 100;

		return [
			'summary' => [
				'gross_volume'     => $gross_volume,
				'gross_volume_fmt' => self::format_currency( $gross_volume, $account_currency ),
				'net_volume'       => $net_volume,
				'net_volume_fmt'   => self::format_currency( $net_volume, $account_currency ),
				'total_fees_fmt'   => self::format_currency( $total_fees, $account_currency ),
				'success_count'    => $success_cnt,
				'failed_count'     => $failed_cnt,
				'total_count'      => $total_transactions,
				'success_rate'     => $success_rate,
				'currency'         => strtoupper( $account_currency ),
			],
			'list'    => $list,
		];
	}

	/**
	 * Fetch Stripe Payouts.
	 *
	 * @param int    $start_time Start timestamp.
	 * @param string $account_currency Account base currency.
	 * @return array
	 */
	private static function fetch_payouts( $start_time, $account_currency = 'USD' ) {
		$total_paid  = 0;
		$next_payout = [ 'amount' => 0, 'arrival_date' => 'Estimated in 1-2 days' ];
		$list        = [];

		$payouts = self::safe_request_list(
			[
				'limit'        => 50,
				'created[gte]' => $start_time,
			],
			'payouts',
			'GET'
		);

		if ( ! empty( $payouts ) ) {
			foreach ( $payouts as $payout ) {
				if ( ! is_object( $payout ) ) {
					continue;
				}
				$payout_currency = strtolower( $payout->currency ?? $account_currency );
				$amount          = ( $payout->amount ?? 0 ) / 100;
				$payout_status   = $payout->status ?? 'paid';

				if ( 'paid' === $payout_status ) {
					$total_paid += $amount;
				} elseif ( 'pending' === $payout_status || 'in_transit' === $payout_status ) {
					$next_payout = [
						'amount'       => $amount,
						'amount_fmt'   => self::format_currency( $amount, $payout_currency ),
						'arrival_date' => date_i18n( 'M j, Y', $payout->arrival_date ?? time() ),
					];
				}

				$is_test_mode = class_exists( 'WC_Stripe_Mode' ) && WC_Stripe_Mode::is_test();
				$destination  = $payout->destination ?? 'Bank Account';
				if ( is_object( $destination ) ) {
					$destination = ( $destination->bank_name ?? 'Bank Account' ) . ' (•••• ' . ( $destination->last4 ?? '••••' ) . ')';
				}

				$list[] = [
					'id'          => $payout->id ?? '',
					'amount'      => $amount,
					'amount_fmt'  => self::format_currency( $amount, $payout_currency ),
					'currency'    => strtoupper( $payout_currency ),
					'status'      => $payout_status,
					'destination' => (string) $destination,
					'arrival'     => date_i18n( 'M j, Y', $payout->arrival_date ?? ( $payout->created ?? time() ) ),
					'created'     => date_i18n( 'M j, Y', $payout->created ?? time() ),
					'stripe_url'  => 'https://dashboard.stripe.com/' . ( $is_test_mode ? 'test/' : '' ) . 'payouts/' . ( $payout->id ?? '' ),
				];
			}
		}

		return [
			'total_paid'     => $total_paid,
			'total_paid_fmt' => self::format_currency( $total_paid, $account_currency ),
			'next_payout'    => $next_payout,
			'list'           => $list,
		];
	}

	/**
	 * Fetch Stripe Disputes.
	 *
	 * @param int    $start_time Start timestamp.
	 * @param string $account_currency Account base currency.
	 * @return array
	 */
	private static function fetch_disputes( $start_time, $account_currency = 'USD' ) {
		$total_disputed = 0;
		$active_count   = 0;
		$won_count      = 0;
		$lost_count     = 0;
		$list           = [];

		$disputes = self::safe_request_list(
			[
				'limit'        => 50,
				'created[gte]' => $start_time,
			],
			'disputes',
			'GET'
		);

		if ( ! empty( $disputes ) ) {
			foreach ( $disputes as $dispute ) {
				if ( ! is_object( $dispute ) ) {
					continue;
				}
				$dispute_currency = strtolower( $dispute->currency ?? $account_currency );
				$amount           = ( $dispute->amount ?? 0 ) / 100;
				$total_disputed  += $amount;
				$status           = $dispute->status ?? 'needs_response';

				if ( in_array( $status, [ 'needs_response', 'warning_needs_response', 'under_review' ], true ) ) {
					$active_count++;
				} elseif ( 'won' === $status ) {
					$won_count++;
				} elseif ( 'lost' === $status ) {
					$lost_count++;
				}

				$due_by       = ! empty( $dispute->evidence_details->due_by ) ? date_i18n( 'M j, Y', $dispute->evidence_details->due_by ) : 'Resolved';
				$is_test_mode = class_exists( 'WC_Stripe_Mode' ) && WC_Stripe_Mode::is_test();

				$list[] = [
					'id'         => $dispute->id ?? '',
					'charge_id'  => $dispute->charge ?? '',
					'amount'     => $amount,
					'amount_fmt' => self::format_currency( $amount, $dispute_currency ),
					'currency'   => strtoupper( $dispute_currency ),
					'status'     => $status,
					'reason'     => ucfirst( str_replace( '_', ' ', $dispute->reason ?? 'general' ) ),
					'due_by'     => $due_by,
					'created'    => date_i18n( 'M j, Y', $dispute->created ?? time() ),
					'stripe_url' => 'https://dashboard.stripe.com/' . ( $is_test_mode ? 'test/' : '' ) . 'disputes/' . ( $dispute->id ?? '' ),
				];
			}
		}

		return [
			'total_disputed'     => $total_disputed,
			'total_disputed_fmt' => self::format_currency( $total_disputed, $account_currency ),
			'active_count'       => $active_count,
			'won_count'          => $won_count,
			'lost_count'         => $lost_count,
			'list'               => $list,
		];
	}

	/**
	 * Fetch Stripe Customers.
	 *
	 * @return array
	 */
	private static function fetch_customers() {
		$list = [];

		$customers = self::safe_request_list(
			[
				'limit' => 50,
			],
			'customers',
			'GET'
		);

		if ( ! empty( $customers ) ) {
			foreach ( $customers as $customer ) {
				if ( ! is_object( $customer ) ) {
					continue;
				}
				$is_test_mode = class_exists( 'WC_Stripe_Mode' ) && WC_Stripe_Mode::is_test();
				$list[] = [
					'id'         => $customer->id ?? '',
					'name'       => $customer->name ?? ( $customer->metadata->customer_name ?? 'Guest Customer' ),
					'email'      => $customer->email ?? ( $customer->metadata->customer_email ?? 'No email' ),
					'created'    => date_i18n( 'M j, Y', $customer->created ?? time() ),
					'stripe_url' => 'https://dashboard.stripe.com/' . ( $is_test_mode ? 'test/' : '' ) . 'customers/' . ( $customer->id ?? '' ),
				];
			}
		}

		return [
			'total_count' => count( $list ),
			'list'        => $list,
		];
	}

	/**
	 * AJAX endpoint to fetch analytics data.
	 */
	public function ajax_get_dashboard_analytics() {
		check_ajax_referer( 'wc_stripe_analytics_nonce', 'security' );

		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_send_json_error( [ 'message' => __( 'Permission denied.', 'woocommerce-gateway-stripe' ) ] );
		}

		$range         = isset( $_POST['range'] ) ? sanitize_key( wp_unslash( $_POST['range'] ) ) : '30d';
		$force_refresh = isset( $_POST['force_refresh'] ) && '1' === $_POST['force_refresh'];

		$data = self::get_analytics_data( $range, $force_refresh );

		wp_send_json_success( $data );
	}
}
